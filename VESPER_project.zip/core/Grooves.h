// VESPER grooves: 50 drum grooves for every genre. Each groove is a full kit (kick, snare, clap,
// hats, open hat, percussion) written on a 16th grid, one or two bars long. The band's drum tracks
// (the full kit, or KICK / SNARE / HATS ... on their own tracks) all play the same groove, so they
// always lock together.
//
// Pattern letters:  .  rest     x  hit      X  accent     g  ghost     f  flam
//                   r  roll (3 quick hits)   R  32nds (2 hits)   t  16th triplets (3 hits over two steps)
//                   o  open hat              1 2 3  the genre's percussion sounds
#pragma once

#include "Theory.h"

#include <string>
#include <vector>

namespace vesper
{
enum DrumPiece { PieceKick = 0, PieceSnare, PieceClap, PieceHats, PieceOpenHat, PiecePerc, PieceCymbal, PieceTom, numDrumPieces };
const char* drumPieceName (int piece);    // "KICK"

struct GrooveHit
{
    int step = 0;          // 0 .. bars * 16 - 1
    float off = 0.0f;      // in 16ths after the step
    float len = 0.5f;
    int note = 36;
    int vel = 92;
    int piece = PieceKick;
};

struct Groove
{
    std::string name;      // "KNOCK 2"
    int bars = 1;
    std::vector<GrooveHit> hits;
    int busy = 0;          // how much is going on (the list runs from simple to busy)
};

static constexpr int groovesPerGenre = 50;
const Groove& groove (int genre, int index);
std::string grooveLabel (int genre, int index);   // "07 KNOCK 2"

// standard (General MIDI) drum notes VESPER plays
namespace gm
{
    enum : int { Kick = 36, Rim = 37, Snare = 38, Clap = 39, ClosedHat = 42, LowTom = 45, PedalHat = 44, OpenHat = 46,
                 MidTom = 47, Crash = 49, HighTom = 50, Ride = 51, Tambourine = 54, Cowbell = 56, HiBongo = 60, LoBongo = 61,
                 HiConga = 63, LoConga = 64, Shaker = 70, Claves = 75 };
}
} // namespace vesper
