#include "Theory.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>

namespace vesper
{
//==============================================================================
void Notes::sort() { std::sort (v.begin(), v.begin() + n); }

void Notes::unique()
{
    sort();
    int w = 0;
    for (int i = 0; i < n; ++i)
        if (w == 0 || v[(size_t) (w - 1)] != v[(size_t) i])
            v[(size_t) w++] = v[(size_t) i];
    n = w;
}

bool Notes::contains (int x) const
{
    for (int i = 0; i < n; ++i)
        if (v[(size_t) i] == x)
            return true;
    return false;
}

int Notes::lowest() const
{
    int m = 1 << 20;
    for (int i = 0; i < n; ++i) m = std::min (m, v[(size_t) i]);
    return n > 0 ? m : 0;
}

int Notes::highest() const
{
    int m = -(1 << 20);
    for (int i = 0; i < n; ++i) m = std::max (m, v[(size_t) i]);
    return n > 0 ? m : 0;
}

void Notes::removeAt (int i)
{
    if (i < 0 || i >= n) return;
    for (int k = i; k < n - 1; ++k) v[(size_t) k] = v[(size_t) (k + 1)];
    --n;
}

double Notes::mean() const
{
    if (n == 0) return 0.0;
    double s = 0;
    for (int i = 0; i < n; ++i) s += v[(size_t) i];
    return s / n;
}

bool Notes::sameAs (const Notes& o) const
{
    if (n != o.n) return false;
    Notes a = *this, b = o;
    a.sort(); b.sort();
    for (int i = 0; i < n; ++i)
        if (a[i] != b[i]) return false;
    return true;
}

//==============================================================================
const std::vector<Quality>& qualities()
{
    static const std::vector<Quality> q {
        { "",           "Major",                 "Triads",      { 0, 4, 7 } },
        { "m",          "Minor",                 "Triads",      { 0, 3, 7 } },
        { "dim",        "Diminished",            "Triads",      { 0, 3, 6 } },
        { "aug",        "Augmented",             "Triads",      { 0, 4, 8 } },
        { "(b5)",       "Major flat 5",          "Triads",      { 0, 4, 6 } },
        { "5",          "Power chord",           "Power",       { 0, 7 } },
        { "sus2",       "Sus 2",                 "Sus",         { 0, 2, 7 } },
        { "sus4",       "Sus 4",                 "Sus",         { 0, 5, 7 } },
        { "sus4(add9)", "Sus 4 add 9",           "Sus",         { 0, 5, 7, 14 } },
        { "7sus2",      "7 sus 2",               "Sus",         { 0, 2, 7, 10 } },
        { "7sus4",      "7 sus 4",               "Sus",         { 0, 5, 7, 10 } },
        { "9sus4",      "9 sus 4",               "Sus",         { 0, 5, 7, 10, 14 } },
        { "13sus4",     "13 sus 4",              "Sus",         { 0, 5, 7, 10, 14, 21 } },
        { "maj7sus2",   "Major 7 sus 2",         "Sus",         { 0, 2, 7, 11 } },
        { "maj7sus4",   "Major 7 sus 4",         "Sus",         { 0, 5, 7, 11 } },
        { "7sus4b9",    "7 sus 4 flat 9",        "Sus",         { 0, 5, 7, 10, 13 } },
        { "6",          "Major 6",               "Sixths",      { 0, 4, 7, 9 } },
        { "m6",         "Minor 6",               "Sixths",      { 0, 3, 7, 9 } },
        { "6/9",        "6/9",                   "Sixths",      { 0, 4, 7, 9, 14 } },
        { "m6/9",       "Minor 6/9",             "Sixths",      { 0, 3, 7, 9, 14 } },
        { "m(b6)",      "Minor flat 6",          "Sixths",      { 0, 3, 7, 8 } },
        { "6/9#11",     "6/9 sharp 11",          "Sixths",      { 0, 4, 7, 9, 14, 18 } },
        { "maj7",       "Major 7",               "Sevenths",    { 0, 4, 7, 11 } },
        { "7",          "Dominant 7",            "Sevenths",    { 0, 4, 7, 10 } },
        { "m7",         "Minor 7",               "Sevenths",    { 0, 3, 7, 10 } },
        { "m(maj7)",    "Minor major 7",         "Sevenths",    { 0, 3, 7, 11 } },
        { "m7b5",       "Half-diminished",       "Sevenths",    { 0, 3, 6, 10 } },
        { "dim7",       "Diminished 7",          "Sevenths",    { 0, 3, 6, 9 } },
        { "dim(maj7)",  "Diminished major 7",    "Sevenths",    { 0, 3, 6, 11 } },
        { "maj7#5",     "Major 7 sharp 5",       "Sevenths",    { 0, 4, 8, 11 } },
        { "maj7b5",     "Major 7 flat 5",        "Sevenths",    { 0, 4, 6, 11 } },
        { "7#5",        "7 sharp 5",             "Sevenths",    { 0, 4, 8, 10 } },
        { "7b5",        "7 flat 5",              "Sevenths",    { 0, 4, 6, 10 } },
        { "m7#5",       "Minor 7 sharp 5",       "Sevenths",    { 0, 3, 8, 10 } },
        { "add9",       "Add 9",                 "Add",         { 0, 4, 7, 14 } },
        { "m(add9)",    "Minor add 9",           "Add",         { 0, 3, 7, 14 } },
        { "add11",      "Add 11",                "Add",         { 0, 4, 7, 17 } },
        { "m(add11)",   "Minor add 11",          "Add",         { 0, 3, 7, 17 } },
        { "add#11",     "Add sharp 11",          "Add",         { 0, 4, 7, 18 } },
        { "aug(add9)",  "Augmented add 9",       "Add",         { 0, 4, 8, 14 } },
        { "7(add13)",   "7 add 13",              "Add",         { 0, 4, 7, 10, 21 } },
        { "m7(add11)",  "Minor 7 add 11",        "Add",         { 0, 3, 7, 10, 17 } },
        { "maj9",       "Major 9",               "Ninths",      { 0, 4, 7, 11, 14 } },
        { "9",          "Dominant 9",            "Ninths",      { 0, 4, 7, 10, 14 } },
        { "m9",         "Minor 9",               "Ninths",      { 0, 3, 7, 10, 14 } },
        { "m(maj9)",    "Minor major 9",         "Ninths",      { 0, 3, 7, 11, 14 } },
        { "m9b5",       "Minor 9 flat 5",        "Ninths",      { 0, 3, 6, 10, 14 } },
        { "maj9#5",     "Major 9 sharp 5",       "Ninths",      { 0, 4, 8, 11, 14 } },
        { "9#5",        "9 sharp 5",             "Ninths",      { 0, 4, 8, 10, 14 } },
        { "9b5",        "9 flat 5",              "Ninths",      { 0, 4, 6, 10, 14 } },
        { "7b9",        "7 flat 9",              "Ninths",      { 0, 4, 7, 10, 13 } },
        { "7#9",        "7 sharp 9",             "Ninths",      { 0, 4, 7, 10, 15 } },
        { "m7b9",       "Minor 7 flat 9",        "Ninths",      { 0, 3, 7, 10, 13 } },
        { "11",         "Dominant 11",           "Elevenths",   { 0, 7, 10, 14, 17 } },
        { "m11",        "Minor 11",              "Elevenths",   { 0, 3, 7, 10, 14, 17 } },
        { "maj11",      "Major 11",              "Elevenths",   { 0, 4, 7, 11, 14, 17 } },
        { "maj7#11",    "Major 7 sharp 11",      "Elevenths",   { 0, 4, 7, 11, 18 } },
        { "maj9#11",    "Major 9 sharp 11",      "Elevenths",   { 0, 4, 7, 11, 14, 18 } },
        { "7#11",       "7 sharp 11",            "Elevenths",   { 0, 4, 7, 10, 18 } },
        { "9#11",       "9 sharp 11",            "Elevenths",   { 0, 4, 7, 10, 14, 18 } },
        { "m11b5",      "Minor 11 flat 5",       "Elevenths",   { 0, 3, 6, 10, 17 } },
        { "13",         "Dominant 13",           "Thirteenths", { 0, 4, 7, 10, 14, 21 } },
        { "maj13",      "Major 13",              "Thirteenths", { 0, 4, 7, 11, 14, 21 } },
        { "m13",        "Minor 13",              "Thirteenths", { 0, 3, 7, 10, 14, 21 } },
        { "13#11",      "13 sharp 11",           "Thirteenths", { 0, 4, 7, 10, 14, 18, 21 } },
        { "maj13#11",   "Major 13 sharp 11",     "Thirteenths", { 0, 4, 7, 11, 14, 18, 21 } },
        { "13b9",       "13 flat 9",             "Thirteenths", { 0, 4, 7, 10, 13, 21 } },
        { "13#9",       "13 sharp 9",            "Thirteenths", { 0, 4, 7, 10, 15, 21 } },
        { "7b13",       "7 flat 13",             "Thirteenths", { 0, 4, 7, 10, 20 } },
        { "m7b13",      "Minor 7 flat 13",       "Thirteenths", { 0, 3, 7, 10, 20 } },
        { "7alt",       "Altered",               "Altered",     { 0, 4, 10, 15, 20 } },
        { "7b9#11",     "7 flat 9 sharp 11",     "Altered",     { 0, 4, 7, 10, 13, 18 } },
        { "7#9#11",     "7 sharp 9 sharp 11",    "Altered",     { 0, 4, 7, 10, 15, 18 } },
        { "7b9b13",     "7 flat 9 flat 13",      "Altered",     { 0, 4, 7, 10, 13, 20 } },
        { "7#9b13",     "7 sharp 9 flat 13",     "Altered",     { 0, 4, 7, 10, 15, 20 } },
        { "7#5#9",      "7 sharp 5 sharp 9",     "Altered",     { 0, 4, 8, 10, 15 } },
        { "7#5b9",      "7 sharp 5 flat 9",      "Altered",     { 0, 4, 8, 10, 13 } },
        { "7b5b9",      "7 flat 5 flat 9",       "Altered",     { 0, 4, 6, 10, 13 } },
        { "7b5#9",      "7 flat 5 sharp 9",      "Altered",     { 0, 4, 6, 10, 15 } },
    };
    return q;
}

int numQualities() { return (int) qualities().size(); }

int findQuality (const std::string& suffix)
{
    const auto& q = qualities();
    for (size_t i = 0; i < q.size(); ++i)
        if (q[i].suffix == suffix)
            return (int) i;
    return -1;
}

const std::vector<std::string>& qualityGroups()
{
    static const std::vector<std::string> g { "Triads", "Power", "Sus", "Sixths", "Sevenths", "Add",
                                              "Ninths", "Elevenths", "Thirteenths", "Altered" };
    return g;
}

const std::vector<Scale>& scales()
{
    static const std::vector<Scale> s {
        { "Major",              { 0, 2, 4, 5, 7, 9, 11 },     -1 },
        { "Natural Minor",      { 0, 2, 3, 5, 7, 8, 10 },     -1 },
        { "Dorian",             { 0, 2, 3, 5, 7, 9, 10 },     -1 },
        { "Phrygian",           { 0, 1, 3, 5, 7, 8, 10 },     -1 },
        { "Lydian",             { 0, 2, 4, 6, 7, 9, 11 },     -1 },
        { "Mixolydian",         { 0, 2, 4, 5, 7, 9, 10 },     -1 },
        { "Locrian",            { 0, 1, 3, 5, 6, 8, 10 },     -1 },
        { "Harmonic Minor",     { 0, 2, 3, 5, 7, 8, 11 },     -1 },
        { "Melodic Minor",      { 0, 2, 3, 5, 7, 9, 11 },     -1 },
        { "Phrygian Dominant",  { 0, 1, 4, 5, 7, 8, 10 },     -1 },
        { "Harmonic Major",     { 0, 2, 4, 5, 7, 8, 11 },     -1 },
        { "Lydian Dominant",    { 0, 2, 4, 6, 7, 9, 10 },     -1 },
        { "Hungarian Minor",    { 0, 2, 3, 6, 7, 8, 11 },     -1 },
        { "Double Harmonic",    { 0, 1, 4, 5, 7, 8, 11 },     -1 },
        { "Major Pentatonic",   { 0, 2, 4, 7, 9 },            0 },
        { "Minor Pentatonic",   { 0, 3, 5, 7, 10 },           1 },
        { "Blues",              { 0, 3, 5, 6, 7, 10 },        2 },
        { "Major Blues",        { 0, 2, 3, 4, 7, 9 },         5 },
        { "Whole Tone",         { 0, 2, 4, 6, 8, 10 },        -1 },
        { "Diminished (H-W)",   { 0, 1, 3, 4, 6, 7, 9, 10 },  -1 },
        { "Diminished (W-H)",   { 0, 2, 3, 5, 6, 8, 9, 11 },  -1 },
        { "Bebop Dominant",     { 0, 2, 4, 5, 7, 9, 10, 11 }, -1 },
        { "Japanese (In)",      { 0, 1, 5, 7, 8 },            3 },
    };
    return s;
}

int numScales() { return (int) scales().size(); }

static const char* const genreNames[numGenres] = {
    "R&B / SOUL", "JAZZ", "GOSPEL", "ROCK / INDIE", "POP", "HIP-HOP / RAP", "TRAP", "DRILL", "NEO-SOUL",
    "LO-FI", "FUNK / DISCO", "HOUSE / EDM", "AFROBEATS", "LATIN / BOSSA / SALSA", "REGGAETON", "REGGAE",
    "COUNTRY", "BLUES", "CINEMATIC / ORCHESTRAL" };
static const char* const genreShorts[numGenres] = {
    "R&B / SOUL", "JAZZ", "GOSPEL", "ROCK / INDIE", "POP", "HIP-HOP", "TRAP", "DRILL", "NEO-SOUL",
    "LO-FI", "FUNK / DISCO", "HOUSE / EDM", "AFROBEATS", "LATIN", "REGGAETON", "REGGAE",
    "COUNTRY", "BLUES", "CINEMATIC" };

const char* genreName (int g)  { return (g >= 0 && g < numGenres) ? genreNames[g] : ""; }
const char* genreShort (int g) { return (g >= 0 && g < numGenres) ? genreShorts[g] : ""; }

int genreFamily (int g)
{
    switch (g)
    {
        case Soul: case HipHop: case NeoSoul: case LoFi: case Funk: case Afro: return Soul;
        case Jazz: case Latin:                                                  return Jazz;
        case Gospel: case Blues:                                                return Gospel;
        default:                                                                return Rock;
    }
}

//==============================================================================
static inline int pcOf (int x) { return ((x % 12) + 12) % 12; }

Chord makeChord (int root, const std::string& suffix, int bass)
{
    Chord c;
    c.root = pcOf (root);
    c.quality = findQuality (suffix);
    c.bass = bass < 0 ? -1 : pcOf (bass);
    if (c.bass == c.root) c.bass = -1;
    return c;
}

Notes chordIntervals (const Chord& c)
{
    Notes out;
    if (! c.valid()) return out;
    for (int x : qualities()[(size_t) c.quality].iv) out.add (x);
    return out;
}

int tonesMask (const Chord& c)
{
    int m = 0;
    if (! c.valid()) return 0;
    for (int x : qualities()[(size_t) c.quality].iv) m |= 1 << pcOf (x);
    return m;
}

int pcMask (const Chord& c)
{
    if (! c.valid()) return 0;
    int m = 0;
    for (int x : qualities()[(size_t) c.quality].iv) m |= 1 << pcOf (x + c.root);
    if (c.bass >= 0) m |= 1 << c.bass;
    return m;
}

std::string noteName (int pc, bool flats)
{
    static const char* sharp[] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    static const char* flat[]  = { "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B" };
    return flats ? flat[pcOf (pc)] : sharp[pcOf (pc)];
}

std::string midiName (int midiNote, bool flats)
{
    return noteName (midiNote, flats) + std::to_string (midiNote / 12);
}

bool scaleIsMajorType (int scale)
{
    if (scale < 0 || scale >= numScales()) return true;
    for (int x : scales()[(size_t) scale].iv)
        if (x == 4) return true;
    return false;
}

bool keyPrefersFlats (int keyRoot, int scale)
{
    const int relMajor = scaleIsMajorType (scale) ? pcOf (keyRoot) : pcOf (keyRoot + 3);
    // flat keys, plus C major / A minor where borrowed chords are usually spelled with flats (Bb, Eb, Ab)
    return relMajor == 0 || relMajor == 5 || relMajor == 10 || relMajor == 3 || relMajor == 8 || relMajor == 1 || relMajor == 6;
}

std::string chordName (const Chord& c, bool flats)
{
    if (! c.valid()) return "";
    std::string s = noteName (c.root, flats) + qualities()[(size_t) c.quality].suffix;
    if (c.bass >= 0 && c.bass != c.root)
        s += "/" + noteName (c.bass, flats);
    return s;
}

std::string romanNumeral (const Chord& c, int keyRoot)
{
    if (! c.valid()) return "";
    static const char* base[] = { "I", "bII", "II", "bIII", "III", "IV", "#IV", "V", "bVI", "VI", "bVII", "VII" };
    const int off = pcOf (c.root - keyRoot);
    std::string s = base[off];
    const int m = tonesMask (c);
    auto has = [m] (int i) { return (m >> i) & 1; };

    const bool minor3 = has (3) && ! has (4);
    if (minor3)
        for (auto& ch : s)
            if (ch == 'I' || ch == 'V') ch = (char) (ch == 'I' ? 'i' : 'v');

    if (minor3 && has (6) && ! has (7))
        s += has (10) ? "ø" : "°";
    else if (has (4) && has (8) && ! has (7))
        s += "+";
    return s;
}

int scaleMask (int keyRoot, int scale)
{
    if (scale < 0 || scale >= numScales()) scale = 0;
    int m = 0;
    for (int x : scales()[(size_t) scale].iv) m |= 1 << pcOf (x + keyRoot);
    return m;
}

int poolMask (int keyRoot, int scale)
{
    if (scale < 0 || scale >= numScales()) scale = 0;
    int m = scaleMask (keyRoot, scale);
    const int parent = scales()[(size_t) scale].poolScale;
    if (parent >= 0) m |= scaleMask (keyRoot, parent);
    return m;
}

bool fitsScale (const Chord& c, int keyRoot, int scale)
{
    if (! c.valid()) return false;
    const int pm = pcMask (c);
    const int pool = poolMask (keyRoot, scale);
    return (pm & ~pool) == 0;
}

Role chordRole (const Chord& c, int keyRoot, int scale)
{
    if (! c.valid()) return Role::Move;
    if (! fitsScale (c, keyRoot, scale)) return Role::Color;
    const int off = pcOf (c.root - keyRoot);
    const int m = tonesMask (c);
    auto has = [m] (int i) { return (m >> i) & 1; };
    const bool dom = has (4) && has (10);
    const bool dimish = has (3) && has (6) && ! has (7);
    if (off == 0 && ! dom) return Role::Home;
    if (dom || dimish || (off == 7 && has (4))) return Role::Pull;
    return Role::Move;
}

const char* roleWord (Role r)
{
    switch (r)
    {
        case Role::Home:  return "home";
        case Role::Move:  return "move";
        case Role::Pull:  return "pull";
        case Role::Color: return "color";
    }
    return "";
}

//==============================================================================
const char* rowName (int row)
{
    static const char* names[] = { "POWER", "SUS 2", "SUS 4", "ADD", "TRIADS", "7THS",
                                   "9THS", "6THS", "7 SUS", "11THS", "13THS" };
    return (row >= 0 && row < numRows) ? names[row] : "";
}

struct RowSpec
{
    std::vector<std::string> main;   // white keys and black-key alternates
    std::vector<std::string> rare;   // only used when nothing in `main` fits a degree
};

static const std::vector<RowSpec>& rowSpecs()
{
    static const std::vector<RowSpec> r {
        { { "5" }, {} },
        { { "sus2", "7sus2", "maj7sus2" }, {} },
        { { "sus4", "sus4(add9)" }, {} },
        { { "add9", "m(add9)", "add11", "m(add11)" }, { "add#11", "aug(add9)" } },
        { { "", "m", "dim", "aug" }, { "(b5)" } },
        { { "maj7", "7", "m7", "m7b5", "m(maj7)", "dim7", "maj7#5" }, { "7#5", "7b5", "maj7b5", "m7#5", "dim(maj7)" } },
        { { "maj9", "9", "m9", "m(maj9)", "7b9", "7#9", "m7b9", "m9b5" }, { "maj9#5", "9#5", "9b5" } },
        { { "6", "m6", "6/9", "m6/9" }, { "m(b6)", "6/9#11" } },
        { { "7sus4", "9sus4", "13sus4", "maj7sus4" }, { "7sus4b9" } },
        { { "maj7#11", "m11", "11", "maj9#11", "9#11", "m11b5", "m7(add11)" }, { "7#11", "maj11" } },
        { { "maj13", "m13", "13", "13#11", "maj13#11", "13b9", "13#9", "7b13", "7alt", "7b9#11", "7#9#11", "7b9b13", "7#9b13" },
          { "m7b13", "7(add13)", "7#5#9", "7#5b9", "7b5b9", "7b5#9" } },
    };
    return r;
}

struct ColorSpec { int offset; char kind; };

static std::vector<ColorSpec> colorSpecs (int genre, bool majorType)
{
    genre = genreFamily (genre);
    if (majorType)
    {
        switch (genre)
        {
            case Soul:   return { { 5, 'm' }, { 10, 'D' }, { 2, 'D' }, { 4, 'D' }, { 8, 'M' } };
            case Jazz:   return { { 2, 'D' }, { 9, 'D' }, { 4, 'D' }, { 1, 'D' }, { 6, 'd' } };
            case Gospel: return { { 4, 'D' }, { 9, 'D' }, { 0, 'D' }, { 6, 'd' }, { 5, 'm' } };
            default:     return { { 10, 'M' }, { 8, 'M' }, { 3, 'M' }, { 2, 'M' }, { 5, 'm' } };
        }
    }
    switch (genre)
    {
        case Soul:   return { { 7, 'D' }, { 5, 'D' }, { 1, 'M' }, { 11, 'd' }, { 2, 'm' } };
        case Jazz:   return { { 7, 'D' }, { 1, 'D' }, { 5, 'D' }, { 11, 'd' }, { 9, 'd' } };
        case Gospel: return { { 7, 'D' }, { 0, 'D' }, { 5, 'D' }, { 11, 'd' }, { 6, 'd' } };
        default:     return { { 7, 'M' }, { 5, 'M' }, { 2, 'M' }, { 1, 'M' }, { 9, 'M' } };
    }
}

static std::string colorSuffix (int row, char kind, int genre)
{
    genre = genreFamily (genre);
    const bool M = kind == 'M', D = kind == 'D', m = kind == 'm';
    switch (row)
    {
        case 0:  return "5";
        case 1:  return "sus2";
        case 2:  return "sus4";
        case 3:  return (M || D) ? "add9" : m ? "m(add9)" : "dim";
        case 4:  return (M || D) ? "" : m ? "m" : "dim";
        case 5:  return M ? "maj7" : D ? "7" : m ? "m7" : "dim7";
        case 6:  return M ? "maj9" : D ? (genre == Jazz ? "7b9" : "9") : m ? "m9" : "dim7";
        case 7:  return (M || D) ? "6" : m ? "m6" : "dim7";
        case 8:  return kind == 'd' ? "7sus4b9" : "7sus4";
        case 9:  return M ? "maj7#11" : D ? "9#11" : m ? "m11" : "m11b5";
        case 10: return M ? "maj13" : D ? ((genre == Jazz || genre == Gospel) ? "13b9" : "13") : m ? "m13" : "m11b5";
        default: return "";
    }
}

ScaleMap buildScaleMap (int keyRoot, int scale, int genre)
{
    ScaleMap map;
    if (scale < 0 || scale >= numScales()) scale = 0;
    keyRoot = pcOf (keyRoot);

    const auto& sc = scales()[(size_t) scale].iv;
    const int n = (int) sc.size();
    const auto& specs = rowSpecs();
    static const int whitePos[] = { 0, 2, 4, 5, 7, 9, 11 };
    static const int blackPos[] = { 1, 3, 6, 8, 10 };
    const bool majorType = scaleIsMajorType (scale);

    auto fitsFrom = [&] (const std::vector<std::string>& list, int degree)
    {
        std::vector<Chord> out;
        const int root = keyRoot + sc[(size_t) degree];
        for (const auto& suf : list)
        {
            const Chord c = makeChord (root, suf);
            if (c.valid() && fitsScale (c, keyRoot, scale))
                out.push_back (c);
        }
        return out;
    };
    auto fitsList = [&] (int row, int degree)
    {
        auto out = fitsFrom (specs[(size_t) row].main, degree);
        if (out.empty())
        {
            auto rare = fitsFrom (specs[(size_t) row].rare, degree);
            if (! rare.empty()) out.push_back (rare[0]);
        }
        return out;
    };

    auto addInKey = [&map] (const Chord& c)
    {
        for (const auto& x : map.allInKey)
            if (x == c) return;
        map.allInKey.push_back (c);
    };

    for (int row = 0; row < numRows; ++row)
    {
        const int base = rowBaseNote (row);
        std::vector<int> whites, blacks;
        for (int p : whitePos) if (base + p <= 127) whites.push_back (base + p);
        for (int p : blackPos) if (base + p <= 127) blacks.push_back (base + p);

        std::vector<Chord> extras;      // degrees that didn't get a white key
        std::vector<Chord> alternates;  // second choices in this family
        std::vector<Chord> rowChords;   // everything placed in this row

        for (int d = 0; d < n; ++d)
        {
            for (const auto& c : fitsFrom (specs[(size_t) row].main, d)) addInKey (c);
            for (const auto& c : fitsFrom (specs[(size_t) row].rare, d)) addInKey (c);
        }

        const int whiteCount = (int) whites.size();
        for (int w = 0; w < whiteCount; ++w)
        {
            const int degree = w % n;
            const bool repeat = w >= n;     // scales with fewer than 7 notes wrap around
            auto fits = fitsList (row, degree);

            KeySlot slot;
            slot.degree = degree;
            if (! fits.empty())
            {
                slot.chord = fits[0];
                if (! repeat)
                    for (size_t i = 1; i < fits.size(); ++i) alternates.push_back (fits[i]);
            }
            else
            {
                // nothing from this family fits here: fall back to the simplest in-key chord on this degree
                const int fallbackRow = row <= 4 ? 4 : 5;
                auto fb = fitsList (fallbackRow, degree);
                if (fb.empty()) fb = fitsList (4, degree);
                if (! fb.empty()) slot.chord = fb[0];
                else
                {
                    // exotic scales: take any chord type at all that lives on this degree
                    const int root = keyRoot + sc[(size_t) degree];
                    for (int q = 0; q < numQualities() && ! slot.chord.valid(); ++q)
                    {
                        Chord c;
                        c.root = pcOf (root);
                        c.quality = q;
                        if (fitsScale (c, keyRoot, scale)) slot.chord = c;
                    }
                }
            }
            map.keys[(size_t) whites[(size_t) w]] = slot;
            if (slot.chord.valid()) rowChords.push_back (slot.chord);
        }

        // degrees beyond the white keys (8-note scales, or the short top row)
        for (int d = whiteCount; d < n; ++d)
        {
            auto fits = fitsList (row, d);
            if (! fits.empty())
            {
                extras.push_back (fits[0]);
                for (size_t i = 1; i < fits.size(); ++i) alternates.push_back (fits[i]);
            }
        }

        std::vector<std::pair<Chord, bool>> queue;   // chord, outside
        for (auto& c : extras) queue.push_back ({ c, false });
        for (auto& c : alternates) queue.push_back ({ c, false });

        size_t bi = 0;
        size_t qi = 0;
        for (; bi < blacks.size() && qi < queue.size(); ++bi, ++qi)
        {
            KeySlot s;
            s.chord = queue[qi].first;
            s.outside = false;
            map.keys[(size_t) blacks[bi]] = s;
            rowChords.push_back (s.chord);
        }
        for (; qi < queue.size(); ++qi)
            map.overflow[(size_t) row].push_back (queue[qi].first);

        // fill what's left with the genre's favourite outside chords
        for (const auto& spec : colorSpecs (genre, majorType))
        {
            if (bi >= blacks.size()) break;
            const Chord c = makeChord (keyRoot + spec.offset, colorSuffix (row, spec.kind, genre));
            if (! c.valid()) continue;
            bool dup = false;
            for (const auto& x : rowChords) if (x == c) dup = true;
            if (dup) continue;
            KeySlot s;
            s.chord = c;
            s.outside = ! fitsScale (c, keyRoot, scale);
            map.keys[(size_t) blacks[bi++]] = s;
            rowChords.push_back (c);
        }
    }
    return map;
}

//==============================================================================
// Palettes. Each slot: "offset:suffix@bassOffset" with alternatives separated by '|'.
static const char* const soulMajor[paletteSize] = {
    "0:maj9|0:maj7|0:6/9", "2:m9|2:m7|2:m11", "4:m7|4:m7(add11)", "5:maj9|5:maj7#11|5:maj13",
    "7:9sus4|7:13sus4|7:9", "9:m9|9:m7|9:m11", "11:m7b5|11:m11b5", "0:maj7@4|0:add9@4",
    "5:maj7@7|5:6/9@7", "2:m7@7|2:m9@7", "0:6/9|0:maj13", "7:13|7:9|7:7#9",
    "5:m9|5:m7|5:m6", "10:9|10:13|10:maj7", "8:maj7|8:maj9", "2:9|2:7|2:13",
    "4:7#9|4:7|4:7b9", "9:7b9|9:7|9:9", "3:maj7|3:maj9", "1:maj7|1:7",
    "6:m7b5|6:dim7", "0:7|0:9", "11:7#9|11:7", "0:maj7#11|0:maj9" };

static const char* const soulMinor[paletteSize] = {
    "0:m9|0:m7|0:m11", "2:m7b5|2:m11b5", "3:maj9|3:maj7|3:6/9", "5:m9|5:m7|5:m11",
    "7:m9|7:m7|7:m11", "8:maj9|8:maj7#11|8:maj7", "10:9|10:13sus4|10:7", "7:7#9|7:7b9|7:9",
    "0:m(maj9)|0:m(maj7)", "5:9|5:13|5:7", "1:maj7|1:maj9", "0:m6/9|0:m6",
    "8:maj7@10|8:6/9@10", "5:m7@10|5:m9@10", "2:m7|2:m9", "9:m7b5|9:m11b5",
    "11:dim7", "0:m7@10|0:m9@10", "10:maj7|10:maj9", "8:7|8:9",
    "1:7|1:9", "7:7sus4|7:9sus4|7:13sus4", "4:maj7|4:maj9", "0:7|0:7#9" };

static const char* const jazzMajor[paletteSize] = {
    "0:maj7|0:6/9|0:maj9", "2:m7|2:m9|2:m11", "4:m7|4:m7(add11)", "5:maj7|5:maj9|5:maj7#11",
    "7:7|7:9|7:13", "9:m7|9:m9|9:m11", "11:m7b5|11:m11b5", "0:6|0:6/9",
    "7:7alt|7:7b9|7:7#9", "9:7b9|9:7#9|9:7alt", "2:7|2:9|2:13", "4:7b9|4:7#9",
    "1:7|1:9|1:7#11", "5:m6|5:m7|5:m9", "10:7|10:9|10:13", "6:m7b5",
    "1:dim7", "8:7|8:9|8:7#11", "3:dim7", "0:maj7#11|0:maj9#11",
    "11:7|11:7b9", "3:maj7|3:7", "7:13sus4|7:9sus4|7:7sus4", "0:maj7#5|0:6/9" };

static const char* const jazzMinor[paletteSize] = {
    "0:m7|0:m9|0:m6", "2:m7b5|2:m11b5", "3:maj7|3:maj9|3:maj7#5", "5:m7|5:m9|5:m6",
    "7:7b9|7:7alt|7:7#9", "8:maj7|8:maj7#11|8:maj9", "11:dim7", "0:m(maj7)|0:m(maj9)|0:m6/9",
    "10:7|10:9|10:13", "1:7|1:7#11|1:9", "5:7|5:9|5:13", "8:7|8:9",
    "2:m7|2:m9", "9:m7b5", "0:m11|0:m9", "3:7|3:9",
    "7:7sus4b9|7:9sus4", "6:m7b5", "1:maj7", "7:m7|7:m9",
    "10:maj7|10:6/9", "0:7b9", "2:7|2:9", "0:m6/9" };

static const char* const gospelMajor[paletteSize] = {
    "0:add9|0:maj9|0:6/9", "0:maj7@4|0:add9@4", "5:add9|5:maj9|5:6/9", "5:maj7@7|5:6/9@7|5:add9@7",
    "7:13sus4|7:9sus4|7:7sus4", "7:13|7:7#9|7:13b9", "9:m9|9:m7|9:m11", "2:m9|2:m7|2:m11",
    "4:m7|4:m7(add11)", "4:7#9|4:7b9|4:13b9", "9:7#9|9:13b9|9:7b9", "2:9|2:13|2:7",
    "0:7|0:9|0:13", "6:dim7|6:m7b5", "5:m9|5:m6|5:m7", "1:dim7",
    "11:m7b5|11:7#9", "10:9|10:13", "8:maj7|8:9", "3:dim7|3:7",
    "0:maj13|0:maj9#11", "2:m7@7|2:m9@7", "5:maj9#11|5:maj7#11", "7:7alt|7:7b9b13" };

static const char* const gospelMinor[paletteSize] = {
    "0:m9|0:m11|0:m7", "5:m9|5:m7|5:m11", "5:9|5:13|5:7", "7:7#9|7:7b9|7:13b9",
    "8:maj9|8:maj7|8:6/9", "10:13|10:9|10:13sus4", "3:maj9|3:add9", "2:m7b5|2:m11b5",
    "11:dim7", "0:7#9|0:9", "6:dim7", "1:maj7|1:maj9",
    "7:13sus4|7:9sus4", "0:m7@10|0:m9@10", "8:maj7@10|8:6/9@10", "5:m7@7|5:m9@7",
    "2:7#9|2:9", "9:m7b5", "10:maj7|10:6/9", "1:7|1:9",
    "3:7|3:9", "0:m(maj9)|0:m(maj7)", "8:7|8:9", "0:m6/9|0:m6" };

static const char* const rockMajor[paletteSize] = {
    "0:|0:add9|0:5", "7:|7:sus4|7:5", "9:m|9:m7|9:5", "5:|5:add9|5:sus2",
    "2:m|2:m7|2:sus2", "4:m|4:m7|4:sus4", "0:sus2|0:sus4", "7:sus4|7:7sus4",
    "5:maj7|5:6", "9:m7|9:m(add9)", "0:@4|0:add9@4", "7:@11|7:sus4@11",
    "10:|10:add9|10:5", "8:|8:add9|8:5", "3:|3:add9|3:5", "5:m|5:m6",
    "2:|2:7|2:sus4", "4:|4:7", "9:7|9:", "0:5|0:",
    "7:5|7:", "5:5|5:", "9:5|9:m", "0:6|0:maj7" };

static const char* const rockMinor[paletteSize] = {
    "0:m|0:m(add9)|0:5", "8:|8:add9|8:5", "10:|10:add9|10:5", "3:|3:add9|3:5",
    "5:m|5:m7|5:5", "7:m|7:m7|7:5", "7:|7:7|7:sus4", "0:sus2|0:sus4",
    "5:|5:sus2", "1:|1:5", "0:m7|0:m9", "8:maj7|8:6",
    "3:@7|3:add9@7", "0:m@7|0:m7@7", "10:@2|10:add9@2", "8:@0|8:maj7@0",
    "2:|2:7", "9:m|9:5", "0:5|0:m", "8:5|8:",
    "10:5|10:", "3:5|3:", "5:5|5:m", "7:5|7:" };

static const char* const popMajor[paletteSize] = {
    "0:add9|0:|0:maj7", "7:|7:add9|7:sus4", "9:m7|9:m|9:m(add9)", "5:add9|5:|5:maj7",
    "2:m7|2:m|2:m9", "4:m7|4:m", "0:@4|0:add9@4", "7:@11|7:add9@11",
    "5:@9|5:add9@9", "2:m7@7|2:m9@7", "0:sus2|0:sus4", "7:sus4|7:7sus4",
    "5:maj7#11|5:maj9", "9:m9|9:m11", "10:|10:add9", "8:|8:add9",
    "5:m|5:m6", "2:|2:7|2:add9", "4:|4:7", "3:|3:add9",
    "0:6/9|0:maj9", "11:m7b5", "7:7|7:9", "0:7|0:9" };

static const char* const popMinor[paletteSize] = {
    "0:m|0:m(add9)|0:m7", "8:|8:add9|8:maj7", "3:|3:add9|3:maj7", "10:|10:add9|10:sus4",
    "5:m|5:m7|5:m9", "7:m|7:m7", "7:|7:7|7:sus4", "0:m@3|0:m7@3",
    "8:@0|8:maj7@0", "10:@2|10:add9@2", "3:@7|3:add9@7", "5:m@8|5:m7@8",
    "0:sus2|0:sus4", "8:maj7#11|8:maj9", "3:sus2|3:6", "10:sus4|10:7sus4",
    "2:m7b5|2:dim", "5:|5:add9", "1:|1:maj7", "0:m9|0:m11",
    "7:7sus4|7:9sus4", "3:6/9|3:maj9", "0:|0:add9", "11:dim7" };

static const char* const hiphopMajor[paletteSize] = {
    "0:maj7|0:maj9", "2:m7|2:m9", "4:m7|4:m9", "5:maj7|5:maj9",
    "7:7|7:9|7:13", "9:m7|9:m9|9:m11", "11:m7b5", "5:m7|5:m9|5:m6",
    "10:7|10:9", "8:maj7|8:maj9", "3:maj7|3:6/9", "2:7|2:9",
    "4:7#9|4:7", "9:7#9|9:7b9", "1:maj7|1:7", "0:7|0:9",
    "6:m7b5|6:dim7", "0:6/9|0:maj13", "7:9sus4|7:7sus4", "5:maj7#11|5:maj9#11",
    "2:m7@7|2:m9@7", "0:maj7@4|0:maj9@4", "10:maj7|10:6", "8:7|8:9" };

static const char* const hiphopMinor[paletteSize] = {
    "0:m7|0:m9|0:m11", "3:maj7|3:maj9", "5:m7|5:m9", "7:m7|7:m9",
    "8:maj7|8:maj9", "10:7|10:9", "2:m7b5|2:m11b5", "7:7#9|7:7b9",
    "1:maj7|1:maj9", "0:m6|0:m6/9", "5:7|5:9", "8:7|8:9",
    "10:m7|10:m9", "3:7|3:9", "0:m(maj7)|0:m(maj9)", "6:7|6:9",
    "9:m7b5", "11:dim7", "2:m7|2:m9", "5:m9@10|5:m7@10",
    "8:maj7@10|8:6/9@10", "0:m7@10|0:m9@10", "1:7|1:9", "0:m11|0:m9" };

static const char* const trapMajor[paletteSize] = {
    "0:|0:add9", "9:m|9:m(add9)", "5:|5:add9", "7:|7:sus4",
    "4:m|4:m7", "2:m|2:m7", "0:maj7|0:maj9", "5:maj7|5:maj7#11",
    "9:m7|9:m9", "8:|8:add9", "10:|10:add9", "5:m|5:m(add9)",
    "3:|3:maj7", "4:|4:7", "1:|1:maj7", "0:sus2|0:sus4",
    "7:sus4|7:sus2", "11:dim", "9:m@0|9:m7@0", "2:m(add9)|2:m9",
    "6:dim|6:m7b5", "0:@7|0:add9@7", "4:m@7|4:m7@7", "7:7|7:7sus4" };

static const char* const trapMinor[paletteSize] = {
    "0:m|0:m(add9)|0:5", "8:|8:add9|8:maj7", "1:|1:maj7|1:add9", "7:|7:7|7:7b9",
    "5:m|5:m(add9)", "3:|3:add9", "10:|10:sus2", "2:dim|2:m7b5",
    "11:dim|11:dim7", "0:m(maj7)|0:m(maj9)", "7:m|7:m(add9)", "0:sus2|0:sus4",
    "8:maj7#11|8:maj7", "1:maj7#11|1:maj7", "5:m7|5:m9", "0:m7|0:m9",
    "3:@7|3:add9@7", "8:@0|8:add9@0", "6:|6:add9", "4:|4:aug",
    "7:sus4|7:7sus4", "0:5|0:m", "1:@5|1:maj7@5", "10:m|10:m7" };

static const char* const neoMajor[paletteSize] = {
    "0:maj9|0:maj13|0:6/9", "2:m11|2:m9", "4:m9|4:m7(add11)", "5:maj9#11|5:maj7#11|5:maj13",
    "7:13sus4|7:9sus4", "9:m11|9:m9", "11:m11b5|11:m7b5", "1:maj7#11|1:maj9",
    "8:maj9|8:maj7#11", "10:13|10:9", "3:maj9|3:6/9", "6:m11b5|6:m7b5",
    "4:7#9|4:7b9", "9:7#9|9:13b9", "2:9|2:13", "5:m9|5:m6/9",
    "0:maj9@4|0:6/9@4", "5:maj7@7|5:maj9@7", "2:m9@7|2:m11@7", "7:13|7:13#11",
    "10:maj9|10:6/9", "0:7#9|0:9", "11:7#9|11:7alt", "0:maj7#11|0:maj9#11" };

static const char* const neoMinor[paletteSize] = {
    "0:m11|0:m9", "3:maj9|3:maj7#11", "5:m11|5:m9", "7:m9|7:m11",
    "8:maj9#11|8:maj7#11", "10:13sus4|10:9sus4", "2:m11b5|2:m7b5", "7:7#9|7:7b9b13",
    "1:maj9|1:maj7#11", "0:m6/9|0:m(maj9)", "5:9|5:13", "6:7#11|6:9",
    "10:maj9|10:6/9", "8:13|8:9#11", "2:m9|2:m11", "9:m11b5",
    "4:maj9|4:maj7#11", "11:7#9|11:7b9", "0:m9@10|0:m11@10", "8:maj9@10|8:6/9@10",
    "5:m9@8|5:m11@8", "3:m9|3:m11", "1:13|1:9", "0:9|0:7#9" };

static const char* const lofiMajor[paletteSize] = {
    "0:maj7|0:maj9", "2:m9|2:m7", "4:m7|4:m9", "5:maj7|5:maj9",
    "7:9|7:13", "9:m9|9:m7", "11:m7b5", "5:m7|5:m6",
    "10:9|10:7", "8:maj7|8:maj9", "3:maj7|3:maj9", "2:9|2:7",
    "4:7b9|4:7", "9:7|9:7b9", "1:maj7|1:maj9", "0:6/9|0:6",
    "6:m7b5", "7:9sus4|7:13sus4", "5:maj7#11|5:maj9", "0:maj7@4|0:maj9@4",
    "2:m9@7|2:m7@7", "10:maj7|10:6/9", "8:7|8:9", "0:7|0:9" };

static const char* const lofiMinor[paletteSize] = {
    "0:m9|0:m7", "3:maj7|3:maj9", "5:m9|5:m7", "7:m7|7:m9",
    "8:maj7|8:maj9", "10:9|10:13", "2:m7b5", "7:7b9|7:7#9",
    "1:maj7|1:maj9", "0:m6/9|0:m6", "5:9|5:7", "8:7|8:9",
    "10:maj7|10:6/9", "3:6/9|3:maj7#11", "0:m(maj9)|0:m(maj7)", "2:m9|2:m7",
    "9:m7b5", "11:dim7", "0:m9@10|0:m7@10", "8:maj7@10|8:maj9@10",
    "5:m9@10|5:m7@10", "1:9|1:7", "4:maj7|4:maj9", "0:m11|0:m9" };

static const char* const funkMajor[paletteSize] = {
    "0:9|0:7|0:13", "5:9|5:13|5:7", "7:9|7:13|7:7", "2:m7|2:m9",
    "9:m7|9:m9", "4:m7|4:7#9", "0:7#9|0:7", "10:9|10:7",
    "5:m7|5:m9", "0:6/9|0:maj7", "5:maj7|5:maj9", "7:7sus4|7:9sus4",
    "3:9|3:7", "8:9|8:7", "2:9|2:13", "9:7#9|9:7",
    "4:7|4:9", "11:m7b5", "0:13|0:9", "1:9|1:7",
    "6:m7b5", "10:13|10:9", "2:m11|2:m9", "0:maj9|0:maj7" };

static const char* const funkMinor[paletteSize] = {
    "0:m7|0:m9|0:m11", "5:9|5:7|5:13", "10:9|10:7", "3:maj7|3:maj9",
    "8:maj7|8:9", "7:m7|7:m9", "7:7#9|7:9", "0:m9@10|0:m7@10",
    "5:m7|5:m9", "2:m7b5|2:m7", "0:7#9|0:9", "10:m7|10:m9",
    "3:9|3:7", "1:9|1:maj7", "8:9|8:13", "0:m6|0:m6/9",
    "2:m9|2:m7", "5:m9|5:m11", "11:dim7", "9:m7b5",
    "6:9|6:7", "0:m11|0:m9", "7:7sus4|7:9sus4", "3:6/9|3:maj9" };

static const char* const houseMajor[paletteSize] = {
    "0:maj7|0:add9|0:maj9", "9:m7|9:m9|9:m", "5:maj7|5:add9", "7:sus4|7:|7:add9",
    "2:m7|2:m9", "4:m7|4:m", "0:@4|0:add9@4", "5:@9|5:add9@9",
    "7:@11|7:sus4@11", "2:m7@7|2:m9@7", "0:sus2|0:sus4", "9:m11|9:m9",
    "5:maj9|5:maj7#11", "4:7|4:", "10:|10:add9", "8:|8:maj7",
    "3:maj7|3:", "5:m|5:m7", "7:7sus4|7:9sus4", "2:|2:7",
    "11:m7b5", "0:6/9|0:6", "9:m(add9)|9:m", "0:maj7#11|0:maj9#11" };

static const char* const houseMinor[paletteSize] = {
    "0:m7|0:m9|0:m11", "8:maj7|8:add9", "3:maj7|3:add9", "10:sus4|10:|10:add9",
    "5:m7|5:m9", "7:m7|7:m", "7:|7:7sus4", "0:m(add9)|0:m",
    "8:@0|8:maj7@0", "3:@7|3:add9@7", "10:@2|10:add9@2", "5:m9@8|5:m7@8",
    "0:sus2|0:sus4", "5:m11|5:m9", "8:maj9|8:maj7#11", "2:m7b5",
    "1:maj7|1:", "10:m7|10:m9", "3:6/9|3:6", "7:7|7:7b9",
    "5:|5:add9", "0:m9@10|0:m7@10", "11:dim7", "2:m7|2:m9" };

static const char* const afroMajor[paletteSize] = {
    "0:|0:maj7|0:add9", "5:|5:maj7|5:add9", "7:|7:sus4|7:7", "9:m|9:m7",
    "2:m7|2:m9", "4:m7|4:m", "0:maj7|0:maj9", "5:maj9|5:6/9",
    "7:9sus4|7:7sus4", "9:m9|9:m11", "2:m9|2:m11", "0:6/9|0:6",
    "4:7|4:7#9", "10:|10:9", "2:7|2:9", "0:@4|0:maj7@4",
    "5:@9|5:maj7@9", "7:@11|7:sus4@11", "11:m7b5", "3:maj7|3:",
    "8:maj7|8:", "5:m6|5:m7", "9:7|9:", "0:7|0:9" };

static const char* const afroMinor[paletteSize] = {
    "0:m7|0:m9", "5:m7|5:m9", "3:maj7|3:", "10:|10:sus4",
    "8:maj7|8:", "7:m7|7:m", "2:m7b5", "7:7|7:7sus4",
    "0:m|0:m(add9)", "5:9|5:7", "10:maj7|10:9", "3:6/9|3:maj9",
    "8:maj9|8:maj7#11", "0:m11|0:m9", "5:m11|5:m9", "2:m7|2:m9",
    "7:9sus4|7:7sus4", "1:maj7|1:", "0:m7@10|0:m9@10", "3:@7|3:maj7@7",
    "10:@2|10:add9@2", "5:m@8|5:m7@8", "11:dim7", "0:7|0:9" };

static const char* const latinMajor[paletteSize] = {
    "0:maj7|0:6/9|0:6", "2:m7|2:m9", "7:7|7:9|7:13", "5:maj7|5:6/9",
    "9:m7|9:m9", "4:m7|4:m7b5", "9:7b9|9:7", "2:7|2:9",
    "7:7b9|7:13b9", "0:|0:6", "5:|5:6", "7:|7:7",
    "5:m6|5:m7", "10:7|10:9", "1:7|1:9", "11:m7b5",
    "4:7b9|4:7", "6:m7b5", "3:dim7", "0:maj9|0:6/9",
    "2:m7@7|2:m9@7", "8:7|8:9", "0:7|0:9", "7:9sus4|7:7sus4" };

static const char* const latinMinor[paletteSize] = {
    "0:m|0:m7|0:m6", "8:|8:maj7", "3:|3:maj7", "10:|10:7",
    "5:m|5:m7", "7:|7:7|7:7b9", "7:m|7:m7", "2:m7b5|2:dim",
    "0:m6|0:m6/9", "5:m6|5:m9", "8:maj7|8:6", "1:|1:maj7",
    "11:dim7", "0:m9|0:m7", "3:maj7|3:6/9", "10:9|10:13",
    "2:7|2:7b9", "5:7|5:9", "9:m7b5", "0:7|0:7b9",
    "7:sus4|7:7sus4", "0:m(maj7)|0:m(maj9)", "6:7|6:9", "8:7|8:9" };

static const char* const reggaetonMajor[paletteSize] = {
    "0:|0:add9", "9:m|9:m7", "5:|5:maj7", "7:|7:sus4",
    "4:m|4:m7", "2:m|2:m7", "0:maj7|0:add9", "9:m7|9:m9",
    "5:add9|5:maj7#11", "7:add9|7:sus2", "4:|4:7", "10:|10:add9",
    "8:|8:maj7", "2:|2:7", "0:sus2|0:sus4", "5:m|5:m6",
    "11:dim", "9:m@0|9:m7@0", "0:@4|0:add9@4", "7:@11|7:sus4@11",
    "3:|3:maj7", "2:m9|2:m(add9)", "0:6/9|0:6", "7:7|7:7sus4" };

static const char* const reggaetonMinor[paletteSize] = {
    "0:m|0:m7|0:m(add9)", "8:|8:maj7", "3:|3:maj7", "10:|10:sus4",
    "5:m|5:m7", "7:m|7:m7", "7:|7:7", "1:|1:maj7",
    "0:m7|0:m9", "8:maj7|8:add9", "3:add9|3:6", "10:add9|10:sus2",
    "5:m7|5:m9", "2:m7b5|2:dim", "11:dim7", "0:sus2|0:sus4",
    "8:@0|8:maj7@0", "3:@7|3:add9@7", "10:@2|10:add9@2", "5:m@8|5:m7@8",
    "0:m@3|0:m7@3", "7:sus4|7:7sus4", "5:|5:add9", "0:5|0:m" };

static const char* const reggaeMajor[paletteSize] = {
    "0:|0:maj7|0:6", "5:|5:maj7", "7:|7:7", "9:m|9:m7",
    "2:m|2:m7", "4:m|4:m7", "10:|10:maj7", "0:sus4|0:sus2",
    "5:m|5:m6", "7:sus4|7:7sus4", "2:m7|2:m9", "9:m7|9:m9",
    "0:6/9|0:6", "4:7|4:", "2:7|2:", "3:|3:maj7",
    "8:|8:maj7", "0:@4|0:maj7@4", "5:@9|5:maj7@9", "7:@11|7:7@11",
    "11:m7b5", "0:7|0:9", "9:7|9:", "5:6|5:6/9" };

static const char* const reggaeMinor[paletteSize] = {
    "0:m|0:m7", "5:m|5:m7", "10:|10:7", "8:|8:maj7",
    "3:|3:maj7", "7:m|7:m7", "7:|7:7", "0:m7|0:m9",
    "5:m7|5:m9", "2:m7b5", "0:m6|0:m6/9", "3:6|3:6/9",
    "8:maj7|8:maj9", "10:sus4|10:7sus4", "5:7|5:9", "2:m7|2:m9",
    "0:sus2|0:sus4", "1:|1:maj7", "11:dim", "0:m7@10|0:m@10",
    "3:@7|3:maj7@7", "8:@0|8:maj7@0", "10:@2|10:7@2", "0:m(add9)|0:m9" };

static const char* const countryMajor[paletteSize] = {
    "0:|0:add9|0:6", "5:|5:add9|5:maj7", "7:|7:7|7:sus4", "9:m|9:m7",
    "2:m|2:m7", "4:m|4:m7", "2:|2:7", "4:|4:7",
    "9:|9:7", "0:7|0:", "0:@4|0:add9@4", "7:@11|7:7@11",
    "5:@9|5:add9@9", "0:@7|0:add9@7", "7:sus4|7:sus2", "0:sus2|0:sus4",
    "5:m|5:m6", "10:|10:add9", "5:6|5:6/9", "0:6|0:6/9",
    "7:add9|7:6", "2:m7@7|2:m9@7", "8:|8:add9", "6:dim7" };

static const char* const countryMinor[paletteSize] = {
    "0:m|0:m7", "8:|8:add9", "3:|3:add9", "10:|10:add9",
    "5:m|5:m7", "7:|7:7", "7:m|7:m7", "0:m(add9)|0:m9",
    "3:@7|3:add9@7", "8:@0|8:add9@0", "10:@2|10:add9@2", "0:m7@10|0:m@10",
    "5:|5:add9", "0:sus2|0:sus4", "10:sus4|10:sus2", "7:sus4|7:7sus4",
    "2:m7b5|2:dim", "11:dim7", "1:|1:add9", "3:6|3:6/9",
    "8:maj7|8:6", "0:|0:add9", "5:m6|5:m9", "2:m7|2:m" };

static const char* const bluesMajor[paletteSize] = {
    "0:7|0:9|0:13", "5:7|5:9|5:13", "7:7|7:9|7:13", "0:7#9|0:7",
    "5:9|5:13", "7:7#9|7:7b9", "2:m7|2:m9", "9:7|9:7b9",
    "6:dim7", "4:7|4:9", "2:7|2:9", "0:6|0:6/9",
    "5:m6|5:m7", "10:7|10:9", "8:7|8:9", "1:7|1:9",
    "11:dim7", "3:dim7", "0:7@4|0:9@4", "7:7sus4|7:9sus4",
    "11:7|11:7#9", "0:13|0:9", "5:7@0|5:9@0", "3:7|3:9" };

static const char* const bluesMinor[paletteSize] = {
    "0:m7|0:m9|0:m", "5:m7|5:m9", "7:7#9|7:7|7:7b9", "8:7|8:9",
    "0:m6|0:m6/9", "5:m6|5:m(add9)", "2:m7b5", "10:7|10:9",
    "3:maj7|3:7", "1:7|1:9", "11:dim7", "7:7b9b13|7:7alt",
    "0:m(maj7)|0:m(maj9)", "6:dim7", "9:m7b5", "5:9|5:7",
    "0:7#9|0:9", "8:maj7|8:maj9", "0:m11|0:m9", "2:7|2:9",
    "4:dim7", "3:6|3:6/9", "10:13|10:9", "5:m9|5:m11" };

static const char* const cineMajor[paletteSize] = {
    "0:add9|0:|0:maj7", "5:add9|5:maj7#11", "9:m|9:m(add9)", "7:sus4|7:sus2|7:",
    "4:m|4:m(add9)", "2:m|2:m(add9)", "8:|8:add9", "10:|10:add9",
    "4:|4:add9", "3:|3:add9", "9:|9:sus2", "5:m|5:m(add9)",
    "2:|2:add9", "0:sus2|0:sus4", "0:@4|0:add9@4", "5:@9|5:add9@9",
    "7:@11|7:sus4@11", "0:maj7#11|0:maj9#11", "1:|1:maj7", "11:m|11:sus4",
    "6:|6:add9", "0:5|0:", "7:5|7:", "9:m7|9:m9" };

static const char* const cineMinor[paletteSize] = {
    "0:m(add9)|0:m|0:5", "8:add9|8:|8:maj7", "3:add9|3:", "10:add9|10:|10:sus2",
    "5:m|5:m(add9)", "7:|7:sus4|7:7", "7:m|7:m(add9)", "1:|1:add9",
    "4:|4:add9", "11:dim|11:dim7", "8:maj7#11|8:maj9#11", "0:sus2|0:sus4",
    "9:|9:sus2", "6:|6:add9", "2:dim|2:m7b5", "3:@7|3:add9@7",
    "8:@0|8:add9@0", "10:@2|10:add9@2", "0:m@3|0:m(add9)@3", "5:m@8|5:m(add9)@8",
    "0:m(maj7)|0:m(maj9)", "0:5|0:m", "8:5|8:", "3:5|3:" };

static Card parseSlot (const std::string& text, int keyRoot)
{
    Card card;
    const auto colon = text.find (':');
    if (colon == std::string::npos) return card;
    const int off = std::atoi (text.substr (0, colon).c_str());
    std::string rest = text.substr (colon + 1);
    int bass = -1;
    const auto at = rest.find ('@');
    if (at != std::string::npos)
    {
        bass = keyRoot + std::atoi (rest.substr (at + 1).c_str());
        rest = rest.substr (0, at);
    }
    card.chord = makeChord (keyRoot + off, rest, bass);
    return card;
}

Palette buildPalette (int keyRoot, int scale, int genre, uint32_t diceSeed)
{
    const bool major = scaleIsMajorType (scale);
    const char* const* table = nullptr;
    switch (genre)
    {
        case Soul:      table = major ? soulMajor : soulMinor; break;
        case Jazz:      table = major ? jazzMajor : jazzMinor; break;
        case Gospel:    table = major ? gospelMajor : gospelMinor; break;
        case Pop:       table = major ? popMajor : popMinor; break;
        case HipHop:    table = major ? hiphopMajor : hiphopMinor; break;
        case Trap:
        case Drill:     table = major ? trapMajor : trapMinor; break;
        case NeoSoul:   table = major ? neoMajor : neoMinor; break;
        case LoFi:      table = major ? lofiMajor : lofiMinor; break;
        case Funk:      table = major ? funkMajor : funkMinor; break;
        case House:     table = major ? houseMajor : houseMinor; break;
        case Afro:      table = major ? afroMajor : afroMinor; break;
        case Latin:     table = major ? latinMajor : latinMinor; break;
        case Reggaeton: table = major ? reggaetonMajor : reggaetonMinor; break;
        case Reggae:    table = major ? reggaeMajor : reggaeMinor; break;
        case Country:   table = major ? countryMajor : countryMinor; break;
        case Blues:     table = major ? bluesMajor : bluesMinor; break;
        case Cinematic: table = major ? cineMajor : cineMinor; break;
        default:        table = major ? rockMajor : rockMinor; break;
    }

    Rng rng;
    rng.s = diceSeed * 2654435761u + 12345u;
    Palette p;
    for (int i = 0; i < paletteSize; ++i)
    {
        std::vector<std::string> alts;
        std::string s = table[i];
        size_t start = 0;
        while (true)
        {
            const auto bar = s.find ('|', start);
            alts.push_back (s.substr (start, bar == std::string::npos ? std::string::npos : bar - start));
            if (bar == std::string::npos) break;
            start = bar + 1;
        }
        const int pick = diceSeed == 0 ? 0 : rng.below ((int) alts.size());
        p[(size_t) i] = parseSlot (alts[(size_t) pick], keyRoot);
    }
    return p;
}

//==============================================================================
std::vector<TriadInfo> triadsIn (const Chord& c, bool flats)
{
    std::vector<TriadInfo> out;
    if (! c.valid()) return out;
    const int mask = pcMask (c);
    static const int shapes[6][3] = { { 0, 4, 7 }, { 0, 3, 7 }, { 0, 3, 6 }, { 0, 4, 8 }, { 0, 2, 7 }, { 0, 5, 7 } };
    static const char* suffix[6] = { "", "m", "dim", "aug", "sus2", "sus4" };

    std::vector<int> seen;
    for (int k = 0; k < 12; ++k)
    {
        const int r = pcOf (c.root + k);
        if (! ((mask >> r) & 1)) continue;
        for (int t = 0; t < 6; ++t)
        {
            int m = 0;
            bool ok = true;
            for (int j = 0; j < 3; ++j)
            {
                const int pc = pcOf (r + shapes[t][j]);
                if (! ((mask >> pc) & 1)) ok = false;
                m |= 1 << pc;
            }
            if (! ok) continue;
            if (std::find (seen.begin(), seen.end(), m) != seen.end()) continue;
            seen.push_back (m);
            TriadInfo ti;
            ti.root = r;
            ti.type = t;
            ti.iv = { shapes[t][0], shapes[t][1], shapes[t][2] };
            ti.name = noteName (r, flats) + suffix[t];
            out.push_back (ti);
        }
    }
    return out;
}

Notes triadNotes (const TriadInfo& t, int inversion, int octave)
{
    const int a = t.iv[1], b = t.iv[2];
    int rel[3];
    switch (((inversion % 3) + 3) % 3)
    {
        case 1:  rel[0] = a; rel[1] = b; rel[2] = 12; break;
        case 2:  rel[0] = b; rel[1] = 12; rel[2] = 12 + a; break;
        default: rel[0] = 0; rel[1] = a; rel[2] = b; break;
    }
    const int bottom = 12 * octave + pcOf (t.root + rel[0]);
    Notes n;
    for (int i = 0; i < 3; ++i) n.add (bottom + rel[i] - rel[0]);
    return n;
}

//==============================================================================
std::vector<Suggestion> suggestNext (const Chord& cur, int keyRoot, int scale,
                                     const std::vector<Chord>& available)
{
    std::vector<Suggestion> out;
    if (! cur.valid()) return out;

    const int off = pcOf (cur.root - keyRoot);
    const int cm = tonesMask (cur);
    auto has = [cm] (int i) { return (cm >> i) & 1; };
    const bool dominant = has (4) && has (10);
    const bool curHas7 = has (10) || has (11) || (has (9) && has (3) && has (6));
    const bool major = scaleIsMajorType (scale);

    std::vector<std::pair<int, std::string>> targets;
    if (dominant)
    {
        targets.push_back ({ pcOf (off + 5), "resolves" });
        targets.push_back ({ pcOf (off + 2), "surprise turn" });
    }
    if (has (3) && has (6) && ! has (7))
        targets.push_back ({ pcOf (off + 1), "resolves up" });

    if (major)
    {
        switch (off)
        {
            case 0:  targets.insert (targets.end(), { { 5, "lifts" }, { 9, "gets moody" }, { 2, "moves on" }, { 7, "builds tension" } }); break;
            case 2:  targets.insert (targets.end(), { { 7, "sets up home" }, { 5, "lifts" }, { 4, "keeps moving" } }); break;
            case 4:  targets.insert (targets.end(), { { 9, "flows" }, { 5, "lifts" }, { 2, "moves on" } }); break;
            case 5:  targets.insert (targets.end(), { { 7, "builds tension" }, { 0, "goes home" }, { 2, "moves on" }, { 4, "steps down" } }); break;
            case 7:  targets.insert (targets.end(), { { 0, "goes home" }, { 9, "surprise turn" }, { 5, "softens" } }); break;
            case 9:  targets.insert (targets.end(), { { 5, "lifts" }, { 2, "moves on" }, { 7, "builds tension" } }); break;
            case 11: targets.insert (targets.end(), { { 0, "goes home" }, { 4, "flows" } }); break;
            case 10: targets.insert (targets.end(), { { 0, "goes home" }, { 5, "lifts" } }); break;
            case 8:  targets.insert (targets.end(), { { 10, "climbs" }, { 7, "builds tension" }, { 0, "goes home" } }); break;
            case 3:  targets.insert (targets.end(), { { 8, "drifts" }, { 5, "lifts" } }); break;
            default: targets.insert (targets.end(), { { 0, "goes home" }, { 7, "builds tension" } }); break;
        }
    }
    else
    {
        switch (off)
        {
            case 0:  targets.insert (targets.end(), { { 5, "sinks" }, { 8, "opens up" }, { 10, "climbs" }, { 7, "builds tension" } }); break;
            case 2:  targets.insert (targets.end(), { { 7, "sets up home" }, { 3, "brightens" } }); break;
            case 3:  targets.insert (targets.end(), { { 8, "drifts" }, { 5, "sinks" } }); break;
            case 5:  targets.insert (targets.end(), { { 7, "builds tension" }, { 0, "goes home" }, { 10, "climbs" } }); break;
            case 7:  targets.insert (targets.end(), { { 0, "goes home" }, { 8, "surprise turn" } }); break;
            case 8:  targets.insert (targets.end(), { { 10, "climbs" }, { 7, "builds tension" }, { 5, "sinks" } }); break;
            case 10: targets.insert (targets.end(), { { 3, "brightens" }, { 0, "goes home" } }); break;
            default: targets.insert (targets.end(), { { 0, "goes home" }, { 7, "builds tension" } }); break;
        }
    }

    auto similarity = [&] (const Chord& c)
    {
        const int m = tonesMask (c);
        const bool c7 = ((m >> 10) & 1) || ((m >> 11) & 1);
        static const char* common[] = { "", "m", "maj7", "m7", "7", "m7b5", "maj9", "m9", "9", "6", "m6", "add9", "dim", "dim7", "13", "m11" };
        int score = (c7 == curHas7) ? 10 : 0;
        for (auto* q : common) if (qualities()[(size_t) c.quality].suffix == q) { score += 8; break; }
        if (((m >> 3) & 1) || ((m >> 4) & 1)) score += 4;
        if (fitsScale (c, keyRoot, scale)) score += 6;
        // common tones with the current chord
        const int shared = pcMask (c) & pcMask (cur);
        for (int i = 0; i < 12; ++i) score += (shared >> i) & 1;
        score -= std::abs ((int) chordIntervals (c).size() - (int) chordIntervals (cur).size());
        return score;
    };

    for (const auto& t : targets)
    {
        if ((int) out.size() >= 4) break;
        const int root = pcOf (keyRoot + t.first);
        bool already = false;
        for (const auto& s : out) if (s.chord.root == root) already = true;
        if (already) continue;

        Chord best;
        int bestScore = -1000;
        for (const auto& c : available)
        {
            if (! c.valid() || c.root != root || c == cur) continue;
            const int sc = similarity (c);
            if (sc > bestScore) { bestScore = sc; best = c; }
        }
        if (! best.valid())
        {
            static const char* withSeventh[] = { "maj7", "m7", "7", "m7b5" };
            static const char* triads[] = { "", "m", "dim" };
            for (auto* s : withSeventh)
            {
                if (! curHas7) break;
                const Chord c = makeChord (root, s);
                if (fitsScale (c, keyRoot, scale)) { best = c; break; }
            }
            if (! best.valid())
                for (auto* s : triads)
                {
                    const Chord c = makeChord (root, s);
                    if (fitsScale (c, keyRoot, scale)) { best = c; break; }
                }
            if (! best.valid()) best = makeChord (root, curHas7 ? "7" : "");
        }
        out.push_back ({ best, t.second });
    }
    return out;
}
} // namespace vesper
