#include "Voicing.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>

namespace vesper
{
static inline int pcOf (int x) { return ((x % 12) + 12) % 12; }

const char* styleName (int s)
{
    static const char* names[] = { "Close", "Open", "Drop 2", "Drop 3", "Drop 2 & 4", "Shell",
                                   "Rootless A", "Rootless B", "Quartal", "Lush", "Fat",
                                   "Wide", "Cluster", "Upper Structure", "Guitar", "Power / Rock" };
    return (s >= 0 && s < numStyles) ? names[s] : "";
}

const char* styleBlurb (int s)
{
    static const char* blurbs[] = {
        "All notes packed tight, like a beginner piano shape",
        "Spread out across two octaves, airy",
        "The classic jazz piano / guitar spread",
        "Wider spread, rich low middle",
        "Very open, string-section feel",
        "Just root, 3rd and 7th: clean, leaves room for the band",
        "Jazz piano, no root (let the bass take it), 3rd on the bottom",
        "Jazz piano, no root, 7th on the bottom",
        "Stacked fourths: modern, floaty, ambiguous",
        "Neo-soul: root and 7th low, rich cluster on top",
        "Gospel: octave bass, thick top, doubled melody note",
        "Wide 10ths, big and cinematic",
        "Notes rubbed together in seconds, dreamy tension",
        "A bright triad floating over a 3rd/7th shell",
        "Exactly what a guitar would play",
        "Root-fifth-octave with the color on top" };
    return (s >= 0 && s < numStyles) ? blurbs[s] : "";
}

int genreDefaultStyle (int genre)
{
    switch (genre)
    {
        case Soul:      return Lush;
        case Jazz:      return Drop2;
        case Gospel:    return Fat;
        case Pop:       return Open;
        case HipHop:    return Lush;
        case Trap:      return Open;
        case Drill:     return Wide;
        case NeoSoul:   return Cluster;
        case LoFi:      return Drop2;
        case Funk:      return Close;
        case House:     return Close;
        case Afro:      return Open;
        case Latin:     return Drop2;
        case Reggaeton: return Close;
        case Reggae:    return Close;
        case Country:   return GuitarStyle;
        case Blues:     return Shell;
        case Cinematic: return Wide;
        default:        return GuitarStyle;
    }
}

int genreVaryStyles (int genre, int* out)
{
    int n = 0;
    auto add = [&] (std::initializer_list<int> l) { for (int s : l) out[n++] = s; };
    switch (genre)
    {
        case Soul:      add ({ Lush, Drop2, Open, Cluster, RootlessA, Close }); break;
        case Jazz:      add ({ RootlessA, RootlessB, Drop2, Drop3, Shell, Quartal, UpperStructure }); break;
        case Gospel:    add ({ Fat, Lush, Drop2, UpperStructure, Open, Cluster }); break;
        case Pop:       add ({ Open, Close, Lush, Wide, GuitarStyle }); break;
        case HipHop:    add ({ Lush, Drop2, Close, Cluster, RootlessA }); break;
        case Trap:      add ({ Open, Close, Wide, Lush }); break;
        case Drill:     add ({ Wide, Open, Close, Lush }); break;
        case NeoSoul:   add ({ Cluster, Lush, Quartal, RootlessA, UpperStructure, Drop2 }); break;
        case LoFi:      add ({ Drop2, RootlessA, Lush, Cluster, Close }); break;
        case Funk:      add ({ Close, Drop2, Shell, RootlessA }); break;
        case House:     add ({ Close, Open, Lush, Wide }); break;
        case Afro:      add ({ Open, Close, Lush, GuitarStyle }); break;
        case Latin:     add ({ Drop2, Close, Open, RootlessA }); break;
        case Reggaeton: add ({ Close, Open, Wide }); break;
        case Reggae:    add ({ Close, Open, GuitarStyle }); break;
        case Country:   add ({ GuitarStyle, Open, Close }); break;
        case Blues:     add ({ Shell, Drop2, Close, RootlessA }); break;
        case Cinematic: add ({ Wide, Open, Lush, Fat }); break;
        default:        add ({ GuitarStyle, PowerRock, Open, Close, Wide }); break;
    }
    return n;
}

bool styleHasRootBass (int s)
{
    return s == Shell || s == Lush || s == Fat || s == Wide || s == Cluster
        || s == UpperStructure || s == PowerRock || s == Quartal;
}

//==============================================================================
static Notes relPcs (const Chord& c)
{
    Notes iv = chordIntervals (c);
    Notes out;
    for (int i = 0; i < iv.size(); ++i) out.add (pcOf (iv[i]));
    out.unique();
    return out;
}

static int importance (int pc, int mask)
{
    auto has = [mask] (int i) { return (mask >> i) & 1; };
    if (pc == 4 || (pc == 3 && ! has (4))) return 100;
    if ((pc == 5 || pc == 2) && ! has (3) && ! has (4)) return 99;
    if (pc == 10 || pc == 11) return 95;
    if (pc == 9 && ! has (10) && ! has (11)) return 94;
    if (pc == 6 || pc == 8) return 90;
    if (pc == 1 || (pc == 3 && has (4))) return 88;
    if (pc == 9) return 85;
    if (pc == 5) return 84;
    if (pc == 2) return 80;
    if (pc == 0) return 70;
    if (pc == 7) return 50;
    return 40;
}

static Notes reducePcs (const Chord& c, int maxN, bool withRoot)
{
    const int mask = tonesMask (c);
    Notes p = relPcs (c);
    Notes pool;
    for (int i = 0; i < p.size(); ++i)
        if (withRoot || p[i] != 0) pool.add (p[i]);

    while (pool.size() > maxN)
    {
        int worst = 0;
        for (int i = 1; i < pool.size(); ++i)
            if (importance (pool[i], mask) < importance (pool[worst], mask)) worst = i;
        pool.removeAt (worst);
    }
    pool.sort();
    return pool;
}

static Notes rotateUp (Notes s, int k)
{
    s.sort();
    if (s.size() == 0) return s;
    k = ((k % s.size()) + s.size()) % s.size();
    for (int i = 0; i < k; ++i)
    {
        int lo = 0;
        for (int j = 1; j < s.size(); ++j) if (s[j] < s[lo]) lo = j;
        s[lo] += 12;
    }
    s.sort();
    return s;
}

static Notes placeAbove (Notes s, int floorNote)
{
    if (s.empty()) return s;
    const int lo = s.lowest();
    if (lo < floorNote)
        s.transpose (((floorNote - lo + 11) / 12) * 12);
    s.sort();
    return s;
}

static int thirdOf (int mask)
{
    for (int x : { 4, 3, 5, 2 }) if ((mask >> x) & 1) return x;
    return -1;
}

static int seventhOf (int mask)
{
    for (int x : { 10, 11, 9 }) if ((mask >> x) & 1) return x;
    return -1;
}

static Notes rotateToLowest (Notes s, int pc)
{
    s.sort();
    for (int i = 0; i < s.size(); ++i)
        if (pcOf (s[i]) == pc) return rotateUp (s, i);
    return s;
}

static Notes styleRel (const Chord& c, int style, int k, const Shape* shapes, int numShapes);

static Notes closeRel (const Chord& c, int k) { return rotateUp (relPcs (c), k); }

static Notes openRel (const Chord& c, int k)
{
    Notes b = closeRel (c, k);
    Notes out;
    if (b.size() < 3)
    {
        out.add (b[0]);
        for (int i = 1; i < b.size(); ++i) out.add (b[i] + 12);
    }
    else
    {
        out.add (b[0]);
        out.add (b[2]);
        out.add (b[1] + 12);
        for (int i = 3; i < b.size(); ++i) out.add (b[i] + 12);
    }
    out.sort();
    return out;
}

static Notes dropRel (const Chord& c, int k, int which)   // 2, 3 or 24
{
    Notes s = rotateUp (reducePcs (c, 4, true), k);
    const int n = s.size();
    if (n >= 2 && (which == 2 || which == 24)) s[n - 2] -= 12;
    if (n >= 3 && which == 3) s[n - 3] -= 12;
    if (n >= 4 && which == 24) s[n - 4] -= 12;
    s.sort();
    return s;
}

static Notes shellRel (const Chord& c, int k)
{
    const int m = tonesMask (c);
    const int t3 = thirdOf (m);
    int t7 = seventhOf (m);
    int t5 = -1;
    for (int x : { 7, 6, 8 }) if ((m >> x) & 1) { t5 = x; break; }
    if (t7 < 0) t7 = t5;
    Notes out;
    out.add (0);
    if (t3 < 0) { if (t5 >= 0) out.add (t5); out.add (12); out.sort(); return out; }
    if (t7 < 0) { out.add (t3 + 12); out.add (24); out.sort(); return out; }
    if (k % 2 == 0) { out.add (t3 + 12); out.add (t7 + 12); }
    else            { out.add (t7); out.add (t3 + 12); }
    out.sort();
    return out;
}

static Notes rootlessRel (const Chord& c, int k, bool formB)
{
    const int m = tonesMask (c);
    Notes u = reducePcs (c, 4, false);
    for (int x : { 7, 6, 8 })
        if (u.size() < 3 && ((m >> x) & 1) && ! u.contains (x)) { u.add (x); u.sort(); }
    if (u.size() < 3 && ! u.contains (0)) { u.add (0); u.sort(); }
    int lowPc = formB ? seventhOf (m) : thirdOf (m);
    if (lowPc < 0) lowPc = thirdOf (m);
    Notes s = lowPc >= 0 ? rotateToLowest (u, lowPc) : u;
    s = rotateUp (s, k);
    // keep the form's lowest note at the bottom for k == 0, other k rotate the top
    return placeAbove (s, 2);
}

static Notes quartalRel (const Chord& c, int k)
{
    const Notes p = relPcs (c);
    if (p.size() == 0) return p;
    const int start = p[k % p.size()];
    int pmask = 0;
    for (int i = 0; i < p.size(); ++i) pmask |= 1 << p[i];

    Notes st;
    st.add (start);
    int used = 1 << start, cur = start;
    for (int added = 0; added < 3; ++added)
    {
        bool ok = false;
        for (int step : { 5, 6, 4, 3, 7 })
        {
            const int cand = cur + step;
            const int pc = pcOf (cand);
            if (((pmask >> pc) & 1) && ! ((used >> pc) & 1))
            {
                st.add (cand);
                used |= 1 << pc;
                cur = cand;
                ok = true;
                break;
            }
        }
        if (! ok) break;
    }
    if (st.size() < 3) return dropRel (c, k, 2);
    st = placeAbove (st, 5);
    if (start != 0)
    {
        const int lo = st.lowest() - 3;
        const int b = lo - pcOf (lo);   // nearest C-class (root) at or below
        st.add (b);
    }
    st.sort();
    return st;
}

static Notes lushRel (const Chord& c, int k)
{
    const int m = tonesMask (c);
    int x = seventhOf (m);
    if (x < 0 && ((m >> 7) & 1)) x = 7;
    Notes p = relPcs (c);
    Notes rh;
    for (int i = 0; i < p.size(); ++i)
        if (p[i] != 0 && p[i] != x) rh.add (p[i]);
    if (rh.size() >= 4 && rh.contains (7)) { for (int i = 0; i < rh.size(); ++i) if (rh[i] == 7) { rh.removeAt (i); break; } }
    while (rh.size() > 4)
    {
        int worst = 0;
        for (int i = 1; i < rh.size(); ++i) if (importance (rh[i], m) < importance (rh[worst], m)) worst = i;
        rh.removeAt (worst);
    }
    Notes out;
    out.add (0);
    if (x >= 0) out.add (x);
    if (rh.size() > 0)
    {
        rh = placeAbove (rotateUp (rh, k), (x >= 0 ? x : 7) + 1);
        for (int i = 0; i < rh.size(); ++i) out.add (rh[i]);
    }
    out.sort();
    return out;
}

static Notes fatRel (const Chord& c, int k)
{
    Notes rh = reducePcs (c, 4, false);
    Notes out;
    out.add (0);
    out.add (12);
    if (rh.size() == 0) { out.add (19); return out; }
    rh = placeAbove (rotateUp (rh, k), 15);
    for (int i = 0; i < rh.size(); ++i) out.add (rh[i]);
    if (rh.size() >= 2 && rh.size() <= 3)
    {
        const int dbl = rh.highest() - 12;
        if (dbl > 14 && ! out.contains (dbl)) out.add (dbl);
    }
    out.unique();
    return out;
}

static Notes wideRel (const Chord& c, int k)
{
    const Notes p = relPcs (c);
    Notes up;
    for (int i = 0; i < p.size(); ++i) if (p[i] != 0 && p[i] != 7) up.add (p[i]);
    Notes out;
    out.add (0);
    if (p.contains (7)) out.add (7);
    if (up.size() > 0)
    {
        up = placeAbove (rotateUp (up, k), 14);
        for (int i = 0; i < up.size(); ++i) out.add (up[i]);
    }
    else out.add (12);
    out.unique();
    return out;
}

static Notes clusterRel (const Chord& c, int k)
{
    const Notes p = relPcs (c);
    Notes up;
    for (int i = 0; i < p.size(); ++i) if (p[i] != 0) up.add (p[i]);
    Notes out;
    out.add (0);
    if (up.size() == 0) { out.add (12); return out; }

    // order rotations by how tight they are
    int order[Notes::cap];
    int spans[Notes::cap];
    const int m = up.size();
    for (int r = 0; r < m; ++r)
    {
        const Notes rr = rotateUp (up, r);
        order[r] = r;
        spans[r] = rr.highest() - rr.lowest();
    }
    std::stable_sort (order, order + m, [&spans] (int a, int b) { return spans[a] < spans[b]; });
    Notes best = placeAbove (rotateUp (up, order[k % m]), 12);
    for (int i = 0; i < best.size(); ++i) out.add (best[i]);
    out.sort();
    return out;
}

static Notes upperStructureRel (const Chord& c, int k)
{
    const int m = tonesMask (c);
    const int t3 = thirdOf (m);
    int t7 = seventhOf (m);
    if (t7 < 0 && ((m >> 7) & 1)) t7 = 7;
    if (t3 < 0 || t7 < 0) return dropRel (c, k, 2);

    auto isTension = [m] (int pc)
    {
        return pc == 1 || pc == 2 || (pc == 3 && ((m >> 4) & 1)) || pc == 5 || pc == 6 || pc == 8 || pc == 9;
    };
    static const int tri[2][3] = { { 0, 4, 7 }, { 0, 3, 7 } };
    int topExt = -1;
    {
        const Notes iv = chordIntervals (c);
        int mx = 0;
        for (int i = 0; i < iv.size(); ++i) mx = std::max (mx, iv[i]);
        if (mx > 12) topExt = pcOf (mx);
    }
    int bestScore = 0, bestR = -1, bestT = 0;
    for (int r = 0; r < 12; ++r)
        for (int t = 0; t < 2; ++t)
        {
            int score = 0;
            bool ok = true;
            for (int j = 0; j < 3; ++j)
            {
                const int pc = pcOf (r + tri[t][j]);
                if (! ((m >> pc) & 1)) { ok = false; break; }
                if (isTension (pc)) score += 10;
                if (pc == topExt) score += 30;
                if (pc == 0) score -= 5;
            }
            if (ok && score > bestScore) { bestScore = score; bestR = r; bestT = t; }
        }
    if (bestR < 0) return dropRel (c, k, 2);

    Notes out;
    out.add (0);
    out.add (t7 < t3 ? t7 + 12 : t7);
    out.add (t3 + 12);
    out.sort();
    Notes rh;
    for (int j = 0; j < 3; ++j) rh.add (bestR + tri[bestT][j]);
    rh = placeAbove (rotateUp (rh, k), out.highest() + 1);
    for (int i = 0; i < rh.size(); ++i) out.add (rh[i]);
    out.unique();
    return out;
}

static Notes powerRel (const Chord& c, int k)
{
    const int m = tonesMask (c);
    int f = -1;
    for (int x : { 7, 6, 8 }) if ((m >> x) & 1) { f = x; break; }
    Notes out;
    out.add (0);
    if (f >= 0) out.add (f);
    out.add (12);
    if (k % 3 == 0) { out.sort(); return out; }

    Notes ext;
    const Notes p = reducePcs (c, 4, false);
    for (int i = 0; i < p.size(); ++i) if (p[i] != f) ext.add (p[i]);
    if (k % 3 == 2 && f >= 0) out.add (f + 12);
    if (ext.size() > 0)
    {
        ext = placeAbove (ext, out.highest() + 1);
        for (int i = 0; i < ext.size(); ++i) out.add (ext[i]);
    }
    out.unique();
    return out;
}

static Notes styleRel (const Chord& c, int style, int k, const Shape*, int)
{
    switch (style)
    {
        case Close:          return closeRel (c, k);
        case Open:           return openRel (c, k);
        case Drop2:          return dropRel (c, k, 2);
        case Drop3:          return dropRel (c, k, 3);
        case Drop24:         return dropRel (c, k, 24);
        case Shell:          return shellRel (c, k);
        case RootlessA:      return rootlessRel (c, k, false);
        case RootlessB:      return rootlessRel (c, k, true);
        case Quartal:        return quartalRel (c, k);
        case Lush:           return lushRel (c, k);
        case Fat:            return fatRel (c, k);
        case Wide:           return wideRel (c, k);
        case Cluster:        return clusterRel (c, k);
        case UpperStructure: return upperStructureRel (c, k);
        case PowerRock:      return powerRel (c, k);
        default:             return openRel (c, k);
    }
}

//==============================================================================
int numVariants (const Chord& c, int style)
{
    if (! c.valid()) return 1;
    switch (style)
    {
        case Close: case Open: case Quartal:            return std::max (1, relPcs (c).size());
        case Drop2: case Drop3: case Drop24:            return std::max (1, reducePcs (c, 4, true).size());
        case Shell:                                     return 2;
        case RootlessA: case RootlessB:
        {
            Notes u = reducePcs (c, 4, false);
            return std::max (3, u.size());
        }
        case Lush: case Fat: case Wide: case Cluster:   return std::max (1, std::min (4, relPcs (c).size() - 1));
        case UpperStructure: case PowerRock:            return 3;
        case GuitarStyle:
        {
            Shape s[maxShapes];
            return std::max (1, findShapes (c, s, maxShapes));
        }
        default: return 1;
    }
}

Notes buildVoicing (const Chord& c, int style, int variant, const Shape* shapes, int numShapes)
{
    Notes out;
    if (! c.valid()) return out;
    variant = std::max (0, variant);

    if (style == GuitarStyle)
    {
        Shape local[maxShapes];
        int n = numShapes;
        const Shape* s = shapes;
        if (s == nullptr || n < 0)
        {
            n = findShapes (c, local, maxShapes);
            s = local;
        }
        if (n > 0) { out = shapeNotes (s[variant % n]); out.unique(); return out; }
        style = Open;
    }

    out = styleRel (c, style, variant, shapes, numShapes);
    out.transpose (48 + c.root);
    out.unique();
    return out;
}

Notes fitToCenter (Notes v, int center)
{
    if (v.empty()) return v;
    const int shift = (int) std::lround ((center - v.mean()) / 12.0) * 12;
    v.transpose (shift);
    int guard = 0;
    while (v.lowest() < 24 && guard++ < 8) v.transpose (12);
    while (v.highest() > 108 && v.lowest() >= 36 && guard++ < 16) v.transpose (-12);
    v.sort();
    return v;
}

static float movement (const Notes& a, const Notes& b)
{
    float cost = 0;
    for (int i = 0; i < a.size(); ++i)
    {
        int best = 1000;
        for (int j = 0; j < b.size(); ++j) best = std::min (best, std::abs (a[i] - b[j]));
        cost += (float) best;
    }
    for (int j = 0; j < b.size(); ++j)
    {
        int best = 1000;
        for (int i = 0; i < a.size(); ++i) best = std::min (best, std::abs (a[i] - b[j]));
        cost += (float) best;
    }
    return cost;
}

VoicingPick chooseVoicing (const Chord& chord, int style, int variant, int center,
                           bool smooth, const Notes& previous,
                           bool vary, const Notes& avoid, int genre, Rng& rng)
{
    VoicingPick pick;
    if (! chord.valid()) return pick;
    style = std::clamp (style, 0, numStyles - 1);

    Shape shapes[maxShapes];
    int ns = -1;

    struct Cand { Notes notes; int style; int variant; float cost; };
    static constexpr int maxC = 160;
    Cand cands[maxC];
    int nc = 0;

    const bool doVary = vary && ! avoid.empty();
    const bool doSmooth = smooth && ! previous.empty();

    int styles[numStyles + 1];
    int nStyles = 0;
    if (doVary)
    {
        nStyles = genreVaryStyles (genre, styles);
        bool present = false;
        for (int i = 0; i < nStyles; ++i) if (styles[i] == style) present = true;
        if (! present) styles[nStyles++] = style;
    }
    else styles[nStyles++] = style;

    for (int si = 0; si < nStyles; ++si)
    {
        const int s = styles[si];
        int nv;
        if (s == GuitarStyle)
        {
            if (ns < 0) ns = findShapes (chord, shapes, maxShapes);
            nv = std::max (1, ns);
        }
        else nv = numVariants (chord, s);

        for (int v = 0; v < nv; ++v)
        {
            if (! doVary)
            {
                if (variant >= 0 && v != variant % nv) continue;
                if (variant < 0 && ! doSmooth && v != 0) continue;
            }
            const Notes base = fitToCenter (buildVoicing (chord, s, v, ns >= 0 ? shapes : nullptr, ns), center);
            const int shifts[3] = { 0, -12, 12 };
            const int nsh = (doSmooth && ! doVary) ? 3 : 1;
            for (int sh = 0; sh < nsh; ++sh)
            {
                if (nc >= maxC) break;
                Notes n = base;
                n.transpose (shifts[sh]);
                if (sh > 0 && (n.lowest() < 24 || n.highest() > 108)) continue;
                const float drift = std::abs ((float) n.mean() - (float) center);
                const float cost = doSmooth ? movement (n, previous) + 0.35f * drift : 0.1f * drift;
                cands[nc++] = { n, s, v, cost };
            }
        }
    }

    if (nc == 0)
    {
        pick.notes = fitToCenter (buildVoicing (chord, Open, 0), center);
        pick.style = Open;
        return pick;
    }

    if (doVary)
    {
        int keep[maxC];
        int nk = 0;
        for (int i = 0; i < nc; ++i)
            if (! cands[i].notes.sameAs (avoid)) keep[nk++] = i;
        if (nk == 0) for (int i = 0; i < nc; ++i) keep[nk++] = i;

        if (doSmooth)
        {
            std::stable_sort (keep, keep + nk, [&cands] (int a, int b) { return cands[a].cost < cands[b].cost; });
            nk = std::min (nk, 6);
        }
        const auto& c = cands[keep[rng.below (nk)]];
        pick.notes = c.notes;
        pick.style = c.style;
        pick.variant = c.variant;
        return pick;
    }

    int best = 0;
    for (int i = 1; i < nc; ++i) if (cands[i].cost < cands[best].cost) best = i;
    pick.notes = cands[best].notes;
    pick.style = cands[best].style;
    pick.variant = cands[best].variant;
    return pick;
}

int bassNoteFor (const Chord& c, const Notes& voicing, int lowest)
{
    const int pc = c.bass >= 0 ? c.bass : c.root;
    if (voicing.empty()) return 36 + pc;
    int b = voicing.lowest() - 1;
    b -= pcOf (b - pc);
    while (b > 52) b -= 12;
    while (b < lowest) b += 12;
    return b;
}

std::string variantName (const Chord& c, int style, int variant, bool flats)
{
    if (! c.valid()) return "";
    static const char* word[] = { "root", "b9", "9th", "b3rd", "3rd", "4th", "b5", "5th", "#5", "6th", "b7", "7th" };
    if (style == GuitarStyle)
    {
        Shape s[maxShapes];
        const int n = findShapes (c, s, maxShapes);
        if (n == 0) return "Shape 1";
        const auto& sh = s[variant % n];
        const int lf = sh.lowestFret();
        return "Shape " + std::to_string (variant % n + 1) + (lf <= 3 && sh.highestFret() <= 4 ? " (open position)" : " (fret " + std::to_string (lf) + ")");
    }
    const Notes v = buildVoicing (c, style, variant);
    if (v.empty()) return "";
    if (style == Close || style == Open || style == Drop2 || style == Drop3 || style == Drop24)
    {
        const int lo = v.lowest();
        const int rel = pcOf (lo - c.root);
        return noteName (lo, flats) + " on bottom (" + word[rel] + ")";
    }
    const int hi = v.highest();
    return "Top note " + noteName (hi, flats) + " (" + word[pcOf (hi - c.root)] + ")";
}
//==============================================================================
// STACK
const char* stackName (int mode)
{
    static const char* n[numStackModes] = { "CHORD", "SINGLE NOTE", "OCTAVES", "STACKED 3RDS", "STACKED 4THS",
                                            "STACKED 5THS", "STACKED 6THS", "POWER" };
    return n[std::clamp (mode, 0, numStackModes - 1)];
}

const char* stackBlurb (int mode)
{
    static const char* n[numStackModes] = {
        "Each key plays the whole chord",
        "Each key plays one note: the chord's root, in the octave of the key you press. Great for melodies",
        "The root in octaves",
        "Notes a 3rd apart, in your key (2 notes = a 3rd, 3 = a triad, 4 = a 7th chord)",
        "Notes a 4th apart, in your key (open, modern, quartal)",
        "Notes a 5th apart, in your key (wide and open)",
        "Notes a 6th apart, in your key (sweet, like horn lines)",
        "Root, 5th and octave (rock / power chord)" };
    return n[std::clamp (mode, 0, numStackModes - 1)];
}

Notes stackVoicing (const Chord& c, int mode, int count, int ref, int keyMask)
{
    Notes out;
    if (! c.valid() || mode <= StackChord) return out;
    count = std::clamp (count, 2, 4);
    // the root at or just under the key you pressed (within a tritone), so keys left to right go up
    int root = ref - (((ref - c.root) % 12) + 12) % 12;
    if (ref - root > 6) root += 12;
    // a chord from outside the key: count steps in the key plus the chord's own notes
    const int mask = (keyMask & 0xfff) | pcMask (c);
    auto stepUp = [mask] (int from, int steps)
    {
        int n = from, moved = 0, guard = 0;
        while (moved < steps && guard++ < 60)
        {
            ++n;
            if ((mask >> (((n % 12) + 12) % 12)) & 1) ++moved;
        }
        return n;
    };
    switch (mode)
    {
        case StackSingle: out.add (root); break;
        case StackOctaves: for (int i = 0; i < count; ++i) out.add (root + 12 * i); break;
        case StackPower:
        {
            const int tm = tonesMask (c);
            const int fifth = (tm >> 7) & 1 ? 7 : ((tm >> 6) & 1 ? 6 : ((tm >> 8) & 1 ? 8 : 7));
            out.add (root); out.add (root + fifth); out.add (root + 12);
            break;
        }
        default:
        {
            const int steps = mode == Stack3rds ? 2 : (mode == Stack4ths ? 3 : (mode == Stack5ths ? 4 : 5));
            int n = root;
            out.add (n);
            for (int i = 1; i < count; ++i) { n = stepUp (n, steps); out.add (n); }
            break;
        }
    }
    Notes clean;
    for (int i = 0; i < out.size(); ++i)
    {
        int n = out[i];
        while (n > 120) n -= 12;
        while (n < 12) n += 12;
        clean.add (n);
    }
    clean.unique();
    return clean;
}
} // namespace vesper
