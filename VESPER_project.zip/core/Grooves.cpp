#include "Grooves.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <set>

namespace vesper
{
const char* drumPieceName (int piece)
{
    static const char* n[numDrumPieces] = { "KICK", "SNARE", "CLAP", "HATS", "OPEN HAT", "PERC", "CYMBALS", "TOMS" };
    return n[std::clamp (piece, 0, numDrumPieces - 1)];
}

namespace
{
// Every genre: a few hand-written choices for each part of the kit. The 50 grooves are different
// combinations of them, from the simplest to the busiest. "" = that part sits out.
struct Pools
{
    std::vector<const char*> kicks, snares, claps, hats, opens, percs;
    std::array<int, 3> perc { gm::Tambourine, gm::Shaker, gm::Rim };
    int hatNote = gm::ClosedHat, openNote = gm::OpenHat, snareNote = gm::Snare;
    int percPiece = PiecePerc;
    std::vector<const char*> words;
};

Pools poolsFor (int genre)
{
    Pools p;
    switch (genre)
    {
        case Soul:
            p.kicks  = { "x.........x.....", "x......x..x.....", "x.....x...x.....", "x..x......x.....", "x......x.x......",
                         "x.........x..x..", "x.....x.x.......", "x..x...x..x.....", "x.........x.....x......x..x....." };
            p.snares = { "....X.......X...", "....X.......X..g", "....X..g....X...", "....X.......X.g.", "..g.X.......X..." };
            p.claps  = { "", "....X.......X...", "............X..." };
            p.hats   = { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx", "x.x.x.x.x.x.x.xx", "x.x.x.xgx.x.x.xg", "xgxgxgxgxgxgxgxg" };
            p.opens  = { "", "..............o.", "......o.......o." };
            p.percs  = { "", "....1.......1...", "..2...2...2...2.", "2.2.2.2.2.2.2.2." };
            p.words  = { "SILK", "VELVET", "SLOW JAM", "AFTER HOURS", "CANDLE", "MIDNIGHT", "SMOOTH", "LATE NIGHT", "SUNDAY", "HONEY", "GLOW", "CRUISE" };
            break;
        case Jazz:
            p.hatNote = gm::Ride; p.openNote = gm::PedalHat;
            p.perc = { gm::Rim, gm::Cowbell, gm::Tambourine };
            p.kicks  = { "g...g...g...g...", "g.......g.......", "................", "g...g...g...g..x", "g.....x.g......." };
            p.snares = { "......g.....g...", "...g......g.....", "..g.......g..g..", ".......g.....g..", "......x.......g." };
            p.claps  = { "" };
            p.hats   = { "x...x.x.x...x.x.", "x...x.x.x.x.x.x.", "x...x.xxx...x.x.", "x.x.x.x.x.x.x.x.", "x...x...x...x..." };
            p.opens  = { "....x.......x...", "x...x...x...x...", "................" };
            p.percs  = { "", "..........1.....", "......1.......1." };
            p.words  = { "SMOKY", "BLUE NOTE", "BRUSHES", "LATE SET", "UPTOWN", "BEBOP", "COOL", "BASEMENT", "VILLAGE", "CLUB" };
            break;
        case Gospel:
            p.kicks  = { "x.....x.x.......", "x.....x...x.x...", "x..x..x...x.....", "x.......x.x.....", "x.....x.x..x....", "x..x....x.x..x.." };
            p.snares = { "....X.......X...", "..g.X..g..g.X...", "....X..g....X.g.", "..g.X.....g.X..g" };
            p.claps  = { "", "....X.......X..." };
            p.hats   = { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx", "xgx.xgx.xgx.xgx." };
            p.opens  = { "", "......o.......o.", "..o...o...o...o." };
            p.percs  = { "", "....1.......1...", "1.1.1.1.1.1.1.1." };
            p.words  = { "SUNDAY", "PRAISE", "REVIVAL", "SHOUT", "AMEN", "CHOIR", "ALTAR", "GLORY", "SANCTIFIED", "HALLELUJAH" };
            break;
        case Rock:
            p.perc = { gm::Tambourine, gm::Cowbell, gm::Rim };
            p.kicks  = { "x.......x.x.....", "x......xx.......", "x.x.....x.......", "x.......x.......", "x.x.....x.x.....", "x......x..x.x..." };
            p.snares = { "....X.......X...", "....X.......X..x", "....X..x....X...", "....X.......X.x." };
            p.claps  = { "" };
            p.hats   = { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "X.x.X.x.X.x.X.x.", "x...x...x...x..." };
            p.opens  = { "", "..............o.", "o..............." };
            p.percs  = { "", "....1.......1...", "2...2...2...2..." };
            p.words  = { "GARAGE", "AMP", "ARENA", "FUZZ", "INDIE", "TOUR VAN", "DIVE BAR", "STADIUM", "RIFF", "FEEDBACK" };
            break;
        case Pop:
            p.perc = { gm::Tambourine, gm::Shaker, gm::Claves };
            p.kicks  = { "x.......x.x.....", "x..x....x.......", "x.......x.......", "x..x....x.x.....", "x...x...x...x...", "x......x..x....." };
            p.snares = { "....X.......X...", "....X.......X..x" };
            p.claps  = { "", "....X.......X...", "....X.......X.X." };
            p.hats   = { "x.x.x.x.x.x.x.x.", "..x...x...x...x.", "x.xxx.xxx.xxx.xx", "xxxxxxxxxxxxxxxx" };
            p.opens  = { "", "..o...o...o...o.", "..............o." };
            p.percs  = { "", "2.2.2.2.2.2.2.2.", "....1.......1..." };
            p.words  = { "RADIO", "NEON", "SUMMER", "CHART", "SPARKLE", "HOOK", "CRUSH", "SUNSET", "GLITTER", "HEADLINER" };
            break;
        case HipHop:
            p.perc = { gm::Rim, gm::Tambourine, gm::Shaker };
            p.kicks  = { "x.....x...x.....", "x......x..x.....", "x.....x.x..x....", "x.x.......x.....", "x......x.x......", "x.....x.....x...",
                         "x..x......x..x..", "x.....xx..x.....", "x.....x...x.....x......x.x......" };
            p.snares = { "....X.......X...", "....X.......X..g", "....X..g....X...", "...gX.......X.g." };
            p.claps  = { "", "....X.......X..." };
            p.hats   = { "x.x.x.x.x.x.x.x.", "x...x...x...x...", "xxxxxxxxxxxxxxxx", "x.xgx.xgx.xgx.xg", "x.x.x.xxx.x.x.x." };
            p.opens  = { "", "..............o.", "......o........." };
            p.percs  = { "", "........1.......", "...1.......1...." };
            p.words  = { "BOOM BAP", "CYPHER", "CRATES", "BLOCK", "BASEMENT", "DUSTY", "STREET", "CORNER", "SAMPLE", "KNOCK" };
            break;
        case Trap:
            p.perc = { gm::Rim, gm::Claves, gm::Cowbell };
            p.kicks  = { "x......x..x.....", "x.....x....x..x.", "x..x......x.x...", "x.........x.....", "x......x.x......", "x.....x..x....x.",
                         "x...........x...", "x..x....x.....x.", "x......x..x.....x.....x...x..x.." };
            p.snares = { "", "........X.......", "........X......g" };
            p.claps  = { "........X.......", "........X.....x.", "........X..x...." };
            p.hats   = { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "x.x.x.x.x.x.t.x.", "xxxxxxrxxxxxxxrr", "x.x.t.x.x.x.t.t.", "x.xRx.xRx.x.x.xr", "t.t.x.x.t.t.x.x." };
            p.opens  = { "", "......o.........", "..............o." };
            p.percs  = { "", "...1.......1....", "....2.......2..." };
            p.words  = { "SLIDE", "KNOCK", "BOUNCE", "ROLLER", "DRIP", "ICE", "PLUG", "SMOKE", "FLEX", "WAVE", "SAUCE", "GLIDE" };
            break;
        case Drill:
            p.perc = { gm::Rim, gm::Claves, gm::Cowbell };
            p.kicks  = { "x......x..x.....", "x.....x..x...x..", "x..x......x..x..", "x.......x..x....", "x.....x.....x...", "x..x.....x...x.." };
            p.snares = { "........X.....x.", "........X..x....", "........X.......", "........X...x..." };
            p.claps  = { "", "........X......." };
            p.hats   = { "x..x..x.x..x..x.", "x..x..xRx..x..x.", "x.x..x..x.x..x..", "x..x.x..x..x.x..", "x.rx..x.x..xr.x." };
            p.opens  = { "", "..........o....." };
            p.percs  = { "", "...1.......1....", "...........1...." };
            p.words  = { "GLIDE", "SPIN", "DARK", "PRESSURE", "MURK", "COLD", "SHADOW", "TENSION", "NIGHT SHIFT", "STEP" };
            break;
        case NeoSoul:
            p.kicks  = { "x......x..x.x...", "x....x....x.....", "x.......x..x....", "x..x.....x......", "x......x.x...x..", "x.....x..x......" };
            p.snares = { "....X.......X...", "....X..g....X..g", "..g.X.....g.X...", "....X.g.....X.g." };
            p.claps  = { "", "....x.......x..." };
            p.hats   = { "x.x.x.x.x.x.x.x.", "xgxgxgxgxgxgxgxg", "xgxxxgxxxgxxxgxx", "x.xgx.x.x.xgx.x.", "x..xx.x.x..xx.x." };
            p.opens  = { "", "..............o.", "......o........." };
            p.percs  = { "", "2.2.2.2.2.2.2.2.", "....1.......1..." };
            p.words  = { "VELVET", "WARM", "LAID BACK", "HAZE", "VINYL", "TAPE", "COFFEE", "INCENSE", "MELLOW", "LAZY", "WOBBLE" };
            break;
        case LoFi:
            p.perc = { gm::Shaker, gm::Tambourine, gm::Rim };
            p.kicks  = { "x.....x...x.....", "x......x.x......", "x.........x.....", "x.....x.x.......", "x..x......x....." };
            p.snares = { "....x.......x...", "....x.......x..g", "....x..g....x..." };
            p.claps  = { "" };
            p.hats   = { "x...x...x...x...", "x.x.x.x.x.x.x.x.", "xgxgxgxgxgxgxgxg", "x.xgx.x.x.xgx.x." };
            p.opens  = { "", "..............o." };
            p.percs  = { "", "1.1.1.1.1.1.1.1.", "..1...1...1...1." };
            p.words  = { "RAINY", "TAPE", "DUST", "STUDY", "CASSETTE", "WINDOW", "SLEEPY", "CLOUD", "COZY", "ROOFTOP" };
            break;
        case Funk:
            p.perc = { gm::Tambourine, gm::HiConga, gm::Cowbell };
            p.kicks  = { "x..x..x...x.x...", "x.x...x..x..x...", "x...x.x...x..x..", "x...x...x...x...", "x..x....x.x.....", "x.....x.x...x..." };
            p.snares = { "....X.......X...", "....X..g.g..X..g", "..g.X..g...gX..g", "....X.......X.g." };
            p.claps  = { "", "....X.......X..." };
            p.hats   = { "x.x.x.x.x.x.x.x.", "xXxxxXxxxXxxxXxx", "xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx" };
            p.opens  = { "", "..o...o...o...o.", "......o.......o." };
            p.percs  = { "", "1.1.1.1.1.1.1.1.", "..2...2...2...2." };
            p.words  = { "STRUT", "BOOGIE", "DISCO BALL", "PLATFORM", "SLAP", "GREASE", "ROLLER RINK", "HUSTLE", "GROOVE", "FUNKY" };
            break;
        case House:
            p.perc = { gm::Rim, gm::Shaker, gm::HiConga };
            p.kicks  = { "x...x...x...x...", "x...x...x...x..x", "x...x...x...x.x." };
            p.snares = { "", "....x.......x..." };
            p.claps  = { "....X.......X...", "....X.......X..x", "....X..x....X..." };
            p.hats   = { "..x...x...x...x.", "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx", "xgxxxgxxxgxxxgxx" };
            p.opens  = { "", "..o...o...o...o.", "..o.......o....." };
            p.percs  = { "", "2222222222222222", "...1..1....1..1." };
            p.words  = { "WAREHOUSE", "PEAK TIME", "DEEP", "GARAGE", "JACKIN", "SUNRISE", "CLUB", "AFTER PARTY", "ACID", "STROBE" };
            break;
        case Afro:
            p.perc = { gm::Rim, gm::HiConga, gm::Shaker };
            p.kicks  = { "x.....x...x.....", "x..x..x...x.....", "x.....x.x...x...", "x..x......x..x..", "x.....x..x..x..." };
            p.snares = { "", "....x.......x...", "........X......." };
            p.claps  = { "........X.......", "....X.......X...", "" };
            p.hats   = { "x.xxx.xxx.xxx.xx", "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx" };
            p.opens  = { "", "......o.......o." };
            p.percs  = { "1..1..1...1..1..", "1..1...1..1..1..", "..2...2...22..2.", "1.21..1.2.1..12.", "3.33.3.33.3.3.33" };
            p.words  = { "LAGOS", "ACCRA", "SUNSHINE", "WINE", "VIBES", "PALM", "BEACH", "SHAKU", "GOLD", "OWAMBE" };
            break;
        case Latin:
            p.perc = { gm::Claves, gm::HiConga, gm::Cowbell };
            p.kicks  = { "x..x....x..x....", "x..xx..xx..xx..x", "x.......x.......", "x..x...x..x....." };
            p.snares = { "", "....x.......x..." };
            p.claps  = { "" };
            p.hats   = { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx" };
            p.opens  = { "" };
            p.percs  = { "1..1..1...1.1...", "1..1...1..1..1..", "..2.2..2..2.2..2", "3...3...3...3...", "1..1.21..21.1.2." };
            p.words  = { "HAVANA", "SALSA", "BOSSA", "SAMBA", "CALLE", "CLAVE", "TROPICAL", "MAMBO", "CUMBIA", "BARRIO" };
            break;
        case Reggaeton:
            p.perc = { gm::Rim, gm::Shaker, gm::Claves };
            p.kicks  = { "x...x...x...x...", "x...x...x...x..x" };
            p.snares = { "...x..x....x..x.", "...x..x.x..x..x.", "...x..x....x..xx" };
            p.claps  = { "", "...x..x....x..x." };
            p.hats   = { "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx", "x.xxx.xxx.xxx.xx" };
            p.opens  = { "", "..o.......o....." };
            p.percs  = { "", "..1.......1.....", "..2...2...2...2." };
            p.words  = { "PERREO", "DEMBOW", "CALLE", "NOCHE", "FUEGO", "PLAYA", "DURO", "CANDELA", "MOVIMIENTO", "PISTA" };
            break;
        case Reggae:
            p.perc = { gm::Rim, gm::Tambourine, gm::Shaker };
            p.kicks  = { "........X.......", "x...x...x...x...", "x.......X.......", "........X.....x." };
            p.snares = { "", "........X.......", "....X.......X..." };
            p.claps  = { "" };
            p.hats   = { "..x...x...x...x.", "x.x.x.x.x.x.x.x.", "x.xxx.xxx.xxx.xx", "x.x.x.x.x.x.x.xx" };
            p.opens  = { "", "......o.......o." };
            p.percs  = { "........1.......", "....1.......1...", "........1...3.3." };
            p.words  = { "ONE DROP", "STEPPERS", "ROCKERS", "DUB", "KINGSTON", "YARD", "IRIE", "ROOTS", "RIDDIM", "SKANK" };
            break;
        case Country:
            p.perc = { gm::Shaker, gm::Tambourine, gm::Rim };
            p.kicks  = { "x.......x.......", "x...x...x...x...", "x.....x.x.......", "x.......x.x....." };
            p.snares = { "gggXgggggggXgggg", "g.gXg.g.g.gXg.g.", "....X.......X...", "....X.......X..x" };
            p.claps  = { "" };
            p.hats   = { "..x...x...x...x.", "x.x.x.x.x.x.x.x.", "x...x...x...x..." };
            p.opens  = { "" };
            p.percs  = { "", "1.1.1.1.1.1.1.1.", "....2.......2..." };
            p.words  = { "TRAIN", "TWO-STEP", "HONKY TONK", "DIRT ROAD", "PORCH", "HIGHWAY", "BARN", "RODEO", "BACK ROAD", "TAILGATE" };
            break;
        case Blues:
            p.perc = { gm::Ride, gm::Tambourine, gm::Rim };
            p.kicks  = { "x.......x.......", "x.....x.x.......", "x...x...x...x...", "x.......x.x....." };
            p.snares = { "....X.......X...", "....X.g.....X.g.", "..g.X.g...g.X.g." };
            p.claps  = { "" };
            p.hats   = { "x.x.x.x.x.x.x.x.", "x...x.x.x...x.x.", "x.xxx.xxx.xxx.xx" };
            p.opens  = { "", "..............o." };
            p.percs  = { "", "1.1.1.1.1.1.1.1.", "....2.......2..." };
            p.words  = { "DELTA", "JUKE JOINT", "SLOW BURN", "CROSSROADS", "BAYOU", "SHUFFLE", "MOJO", "WHISKEY", "BACK PORCH", "MIDNIGHT" };
            break;
        default:   // Cinematic
            p.perc = { gm::LowTom, gm::MidTom, gm::HighTom };
            p.percPiece = PieceTom;
            p.kicks  = { "x.........x.....", "x.......x.......", "x.....x...x.....", "x...............", "x.......x.....x." };
            p.snares = { "", "........X.......", "....X.......X..." };
            p.claps  = { "" };
            p.hats   = { "", "x.x.x.x.x.x.x.x.", "xxxxxxxxxxxxxxxx" };
            p.opens  = { "" };
            p.percs  = { "1..1..1.1..1..1.", "1..1..1...1.....", "..2.......2.....", "1.21..1.1.21..1." };
            p.words  = { "EPIC", "TRAILER", "BATTLE", "RISING", "STORM", "HORIZON", "TITAN", "CHASE", "ODYSSEY", "SIEGE" };
            break;
    }
    return p;
}

void addLane (Groove& g, const char* pat, int piece, int note, const Pools& p)
{
    if (pat == nullptr) return;
    const std::string s (pat);
    const int len = (int) s.size();
    if (len != 16 && len != 32) return;   // (the self-test checks every lane)
    for (int i = 0; i < len; ++i)
    {
        const char c = s[(size_t) i];
        auto hit = [&] (float off, int vel, float hitLen = 0.5f, int n = -1, int pc = -1)
        {
            GrooveHit h;
            h.step = i;
            h.off = off;
            h.vel = std::clamp (vel, 1, 127);
            h.len = hitLen;
            h.note = n >= 0 ? n : note;
            h.piece = pc >= 0 ? pc : piece;
            g.hits.push_back (h);
        };
        switch (c)
        {
            case 'x': hit (0.0f, 92); break;
            case 'X': hit (0.0f, 116); break;
            case 'g': hit (0.0f, 40); break;
            case 'f': hit (0.0f, 50, 0.1f); hit (0.1f, 104); break;
            case 'r': for (int k = 0; k < 3; ++k) hit ((float) k / 3.0f, 62 + k * 10, 0.3f); break;
            case 'R': hit (0.0f, 72, 0.4f); hit (0.5f, 84, 0.4f); break;
            case 't': for (int k = 0; k < 3; ++k) hit ((float) k * 2.0f / 3.0f, k == 1 ? 70 : 86, 0.6f); break;
            case 'o': hit (0.0f, 88, 1.5f, p.openNote, PieceOpenHat); break;
            case '1': case '2': case '3': hit (0.0f, 88, 0.5f, p.perc[(size_t) (c - '1')], p.percPiece); break;
            default: break;
        }
    }
    g.bars = std::max (g.bars, len / 16);
}

uint32_t hashMix (uint32_t a, uint32_t b)
{
    a ^= b + 0x9e3779b9u + (a << 6) + (a >> 2);
    a ^= a >> 16; a *= 0x7feb352du;
    a ^= a >> 15; a *= 0x846ca68bu;
    a ^= a >> 16;
    return a;
}

std::vector<Groove> buildGenre (int genre)
{
    const Pools p = poolsFor (genre);
    const int K = (int) p.kicks.size(), S = (int) p.snares.size(), C = (int) p.claps.size();
    const int H = (int) p.hats.size(), O = (int) p.opens.size(), P = (int) p.percs.size();

    // 50 different combinations: every kick pattern gets used, the rest is mixed in
    std::set<uint64_t> seen;
    struct Pick { int k, s, c, h, o, pc; };
    std::vector<Pick> picks;
    for (int i = 0; (int) picks.size() < groovesPerGenre && i < 5000; ++i)
    {
        const uint32_t base = hashMix ((uint32_t) (genre * 7919 + 17), (uint32_t) i);
        Pick pk;
        pk.k = i % K;
        pk.s = (int) (hashMix (base, 1) % (uint32_t) S);
        pk.c = (int) (hashMix (base, 2) % (uint32_t) C);
        pk.h = (int) (hashMix (base, 3) % (uint32_t) H);
        pk.o = (int) (hashMix (base, 4) % (uint32_t) O);
        pk.pc = (int) (hashMix (base, 5) % (uint32_t) P);
        // something has to carry the backbeat when the genre has one
        const bool noBack = p.snares[(size_t) pk.s][0] == '\0' && p.claps[(size_t) pk.c][0] == '\0';
        if (noBack && genre != Jazz && genre != Latin && genre != Cinematic && genre != Reggae) continue;
        const uint64_t key = (uint64_t) pk.k | ((uint64_t) pk.s << 8) | ((uint64_t) pk.c << 16) | ((uint64_t) pk.h << 24)
                           | ((uint64_t) pk.o << 32) | ((uint64_t) pk.pc << 40);
        if (! seen.insert (key).second) continue;
        picks.push_back (pk);
    }

    std::vector<Groove> out;
    for (const auto& pk : picks)
    {
        Groove g;
        addLane (g, p.kicks[(size_t) pk.k], PieceKick, gm::Kick, p);
        addLane (g, p.snares[(size_t) pk.s], PieceSnare, p.snareNote, p);
        addLane (g, p.claps[(size_t) pk.c], PieceClap, gm::Clap, p);
        addLane (g, p.hats[(size_t) pk.h], PieceHats, p.hatNote, p);
        addLane (g, p.opens[(size_t) pk.o], PieceOpenHat, p.openNote, p);
        addLane (g, p.percs[(size_t) pk.pc], p.percPiece, p.perc[0], p);
        // two-bar grooves: one-bar lanes repeat in bar 2
        if (g.bars == 2)
        {
            std::vector<GrooveHit> extra;
            for (const auto& h : g.hits)
                if (h.step < 16)
                {
                    // was this lane only one bar long? (two-bar lanes already have bar-2 hits of their own)
                    bool lane2 = false;
                    for (const auto& o : g.hits) if (o.piece == h.piece && o.note == h.note && o.step >= 16) { lane2 = true; break; }
                    if (! lane2) { GrooveHit c = h; c.step += 16; extra.push_back (c); }
                }
            g.hits.insert (g.hits.end(), extra.begin(), extra.end());
        }
        int busy = 0;
        for (const auto& h : g.hits) busy += h.vel >= 60 ? 2 : 1;
        g.busy = busy / std::max (1, g.bars);
        out.push_back (g);
    }
    std::stable_sort (out.begin(), out.end(), [] (const Groove& a, const Groove& b) { return a.busy < b.busy; });
    for (size_t i = 0; i < out.size(); ++i)
    {
        const size_t w = p.words.size();
        std::string name = p.words[i % w];
        if (i >= w) name += " " + std::to_string (i / w + 1);
        out[i].name = name;
        std::sort (out[i].hits.begin(), out[i].hits.end(), [] (const GrooveHit& a, const GrooveHit& b) { return a.step < b.step || (a.step == b.step && a.off < b.off); });
    }
    return out;
}
} // namespace

const Groove& groove (int genre, int index)
{
    static const std::vector<std::vector<Groove>> all = []
    {
        std::vector<std::vector<Groove>> v;
        for (int g = 0; g < numGenres; ++g) v.push_back (buildGenre (g));
        return v;
    }();
    const auto& list = all[(size_t) std::clamp (genre, 0, numGenres - 1)];
    static const Groove empty;
    if (list.empty()) return empty;
    return list[(size_t) std::clamp (index, 0, (int) list.size() - 1)];
}

std::string grooveLabel (int genre, int index)
{
    const auto& g = groove (genre, index);
    const int n = std::clamp (index, 0, groovesPerGenre - 1) + 1;
    return (n < 10 ? "0" : "") + std::to_string (n) + " " + g.name;
}
} // namespace vesper
