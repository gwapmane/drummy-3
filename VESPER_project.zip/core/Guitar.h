// Guitar chord shapes for any chord (standard tuning), no heap use.
#pragma once

#include "Theory.h"

namespace vesper
{
struct Shape
{
    std::array<int, 6> fret { -1, -1, -1, -1, -1, -1 };   // low E .. high E, -1 = muted
    int score = 0;
    int lowestFret() const;    // lowest fretted (non-open) fret, 0 if none
    int highestFret() const;
};

constexpr int maxShapes = 8;
int findShapes (const Chord&, Shape* out, int maxOut);   // returns how many, best first
Notes shapeNotes (const Shape&);                         // MIDI notes, low to high
} // namespace vesper
