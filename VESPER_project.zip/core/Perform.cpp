#include "Perform.h"

#include <algorithm>
#include <cstring>
#include <initializer_list>

namespace vesper
{
static inline int pcOf (int x) { return ((x % 12) + 12) % 12; }

//==============================================================================
const StyleInfo& rhythmInfo (int r)
{
    static const StyleInfo info[numRhythms] = {
        { "rPulse",     "PULSING",     "The whole chord repeating in time, steady eighths" },
        { "rDriving",   "DRIVING",     "Rock/pop piano: bass and chord on the beat, chord on the off-beat, pushed accents" },
        { "rStabs",     "STABS",       "Short punchy chord hits on every beat" },
        { "rSkank",     "SKANK",       "Reggae / ska: soft bass on the beat, chord chopped on the off-beat" },
        { "rHouse",     "HOUSE",       "Dance off-beat chord stabs" },
        { "rComping",   "COMPING",     "Jazz comping: Charleston hits that answer the melody" },
        { "rBossa",     "BOSSA NOVA",  "Brazilian bossa comping rhythm over two bars" },
        { "rLatin",     "MONTUNO",     "Latin / salsa montuno: syncopated upper and lower halves" },
        { "rFunk",      "FUNK",        "16th-note clav-style syncopated stabs" },
        { "rShuffle",   "SHUFFLE",     "Swung triplet shuffle, blues and old-school R&B" },
        { "rGospel",    "GOSPEL 6/8",  "Church 12/8 feel: bass, then rolling triplet chords" },
        { "rBallad",    "BALLAD",      "Big chord on 1, soft re-strike on 3, let it ring" },
        { "rStride",    "STRIDE",      "Old-school stride: bass on 1 and 3, chord on 2 and 4" },
        { "rBoogie",    "BOOGIE",      "Walking boogie-woogie bass line with chord jabs" },
        { "rBroken",    "BROKEN",      "Bass then chord, oom-pah, singer-songwriter style" },
        { "rAlberti",   "ALBERTI",     "Classical broken pattern: low, high, middle, high" },
        { "rArpUp",     "ARP UP",      "Arpeggio going up" },
        { "rArpDown",   "ARP DOWN",    "Arpeggio going down" },
        { "rArpUpDown", "ARP UP-DOWN", "Arpeggio up and back down" },
        { "rArpRandom", "ARP RANDOM",  "Chord tones in a random order" },
        { "rArp2Oct",   "ARP 2 OCT",   "Arpeggio climbing through two octaves" },
        { "rWaterfall", "WATERFALL",   "Notes cascade down from above the chord and keep ringing" },
        { "rRising",    "RISING",      "Harp-style sweep up through the chord, notes keep ringing" },
        { "rTremolo",   "TREMOLO",     "Rapid rocking between the low and high half of the chord" },
        { "rTrill",     "TRILL",       "Chord holds while the top note trills with the next note up" },
    };
    return info[std::clamp (r, 0, numRhythms - 1)];
}

const StyleInfo& feelInfo (int f)
{
    static const StyleInfo info[numFeels] = {
        { "fSoft",     "SOFT",        "Gentle touch: everything quieter and rounder" },
        { "fHard",     "HARD",        "Heavy touch: everything louder and harder" },
        { "fAccent",   "ACCENT TOP",  "Top note sings out like a melody, inner notes tucked under" },
        { "fStaccato", "STACCATO",    "Short and detached" },
        { "fLegato",   "LEGATO",      "Long and connected, notes overlap" },
        { "fGhost",    "GHOST NOTES", "Very quiet in-between hits that fill the gaps" },
        { "fOctaves",  "OCTAVES",     "Doubles the top note an octave up and the bass an octave down" },
        { "fSwell",    "SWELL",       "Each chord fades in (sends expression, CC11)" },
        { "fFade",     "FADE OUT",    "Each chord fades away (sends expression, CC11)" },
    };
    return info[std::clamp (f, 0, numFeels - 1)];
}

const StyleInfo& timingInfo (int t)
{
    static const StyleInfo info[numTimings] = {
        { "tStrum",    "STRUMMED",  "Guitar-style strums: down on the beat, up on the off-beat (uses the STRUM knob)" },
        { "tRolled",   "ROLLED",    "Harp-style roll from the bottom, timed to the tempo" },
        { "tSwing",    "SWING",     "Swings the off-beats (amount on the SWING knob)" },
        { "tLaidBack", "LAID BACK", "Sits a little behind the beat, lazy neo-soul pocket" },
        { "tPushed",   "PUSHED",    "Rhythm hits land a hair ahead of the beat, urgent" },
    };
    return info[std::clamp (t, 0, numTimings - 1)];
}

int feelPartner (int f)
{
    switch (f)
    {
        case FSoft: return FHard;
        case FHard: return FSoft;
        case FStaccato: return FLegato;
        case FLegato: return FStaccato;
        case FSwell: return FFade;
        case FFade: return FSwell;
        default: return -1;
    }
}

int timingPartner (int t)
{
    switch (t)
    {
        case TStrummed: return TRolled;
        case TRolled: return TStrummed;
        case TLaidBack: return TPushed;
        case TPushed: return TLaidBack;
        default: return -1;
    }
}

const char* rateName (int r)
{
    static const char* n[numRates] = { "1/4", "1/8", "1/8T", "1/16", "1/16T", "1/32" };
    return n[std::clamp (r, 0, numRates - 1)];
}

double rateBeats (int r)
{
    static const double b[numRates] = { 1.0, 0.5, 1.0 / 3.0, 0.25, 1.0 / 6.0, 0.125 };
    return b[std::clamp (r, 0, numRates - 1)];
}

bool rateIsStraight (int r) { return r == 1 || r == 3 || r == 5; }

//==============================================================================
struct PatternDef { const char* pattern; int rate; float gate; };

static const PatternDef& def (int r)
{
    // rate index: 0 1/4, 1 1/8, 2 1/8T, 3 1/16, 4 1/16T, 5 1/32
    static const PatternDef d[numRhythms] = {
        { "x",                1, 0.5f },    // pulse
        { "Xc",               1, 0.7f },    // driving
        { "X...",             3, 0.2f },    // stabs
        { "b.C.",             3, 0.3f },    // skank
        { "..C.",             3, 0.3f },    // house
        { "x..c......c..c..", 1, 0.45f },   // comping (2 bars)
        { "x..c..c..c..c...", 1, 0.5f },    // bossa (2 bars)
        { "X.hH.hH.h.Hh.Hh.", 1, 0.45f },   // montuno (2 bars)
        { "c.cc..c..c.c..c.", 3, 0.25f },   // funk
        { "x.c",              2, 0.6f },    // shuffle
        { "B.cC.c",           2, 0.6f },    // gospel 12/8
        { "X...c...",         1, 0.0f },    // ballad (rings)
        { "BCFC",             0, 0.45f },   // stride
        { nullptr,            1, 0.45f },   // boogie
        { "Bc",               1, 0.95f },   // broken
        { "LTMT",             3, 0.95f },   // alberti
        { nullptr,            3, 0.9f },    // arp up
        { nullptr,            3, 0.9f },    // arp down
        { nullptr,            3, 0.9f },    // arp up-down
        { nullptr,            3, 0.9f },    // arp random
        { nullptr,            3, 0.9f },    // arp 2 oct
        { nullptr,            4, 0.0f },    // waterfall (rings)
        { nullptr,            5, 0.0f },    // rising (rings)
        { nullptr,            5, 0.95f },   // tremolo
        { nullptr,            5, 1.0f },    // trill
    };
    return d[std::clamp (r, 0, numRhythms - 1)];
}

int rhythmDefaultRate (int r) { return def (r).rate; }
float rhythmDefaultGate (int r) { return def (r).gate; }
bool rhythmOneShot (int r) { return r == RWaterfall || r == RRising; }

bool rhythmPlaysBass (int r)
{
    if (r == RBoogie || r == RTremolo) return true;
    const char* p = def (r).pattern;
    return p != nullptr && std::strpbrk (p, "xXbBFLh") != nullptr;
}

bool rhythmNeedsBass (int r)
{
    if (r == RBoogie) return true;
    const char* p = def (r).pattern;
    return p != nullptr && std::strpbrk (p, "bBFL") != nullptr;
}

//==============================================================================
bool rhythmBarAligned (int r) { return def (r).pattern != nullptr || r == RBoogie; }

static Notes doubledPool (const Notes& upper, bool addOctave = true)
{
    Notes pool = upper;
    pool.unique();
    if (upper.empty() || ! addOctave) return pool;
    const int top = upper.highest();
    for (int i = 0; i < upper.size(); ++i)
        if (upper[i] + 12 > top && upper[i] + 12 <= 115) pool.add (upper[i] + 12);
    pool.unique();
    return pool;
}

int rhythmLength (int rhythm, const PatternInput& in)
{
    const int n = std::max (1, in.upper.size());
    switch (rhythm)
    {
        case RArpUp: case RArpDown: case RArpRandom: return n;
        case RArpUpDown: return n < 2 ? 1 : 2 * n - 2;
        case RArp2Oct: return std::max (1, doubledPool (in.upper).size() + n);
        case RWaterfall: case RRising: return std::max (1, doubledPool (in.upper, in.addOctave).size());
        case RBoogie: return 8;
        case RTremolo: case RTrill: return 2;
        default:
        {
            const char* p = def (rhythm).pattern;
            return p != nullptr ? (int) std::strlen (p) : 1;
        }
    }
}

static void addAll (Notes& dst, const Notes& src) { for (int i = 0; i < src.size(); ++i) dst.add (src[i]); }

Hit rhythmStep (int rhythm, int k, const PatternInput& in, Rng& rng, int& memory)
{
    Hit h;
    h.gate = rhythmDefaultGate (rhythm);
    const Notes& U = in.upper;
    const int n = U.size();
    if (n == 0) return h;
    if (k < 0) k = 0;

    auto strike = [&h] (int note) { if (note >= 0 && note <= 127) { h.notes.add (note); h.rest = false; } };

    switch (rhythm)
    {
        case RArpUp:     strike (U[k % n]); return h;
        case RArpDown:   strike (U[n - 1 - (k % n)]); return h;
        case RArpUpDown:
        {
            if (n < 2) { strike (U[0]); return h; }
            const int period = 2 * n - 2;
            const int i = k % period;
            strike (U[i < n ? i : period - i]);
            return h;
        }
        case RArpRandom:
        {
            int idx = rng.below (n);
            if (n > 1 && idx == memory) idx = (idx + 1) % n;
            memory = idx;
            strike (U[idx]);
            return h;
        }
        case RArp2Oct:
        {
            Notes pool = doubledPool (U);
            for (int i = 0; i < n; ++i) if (U[i] + 24 <= 120) pool.add (U[i] + 24);
            pool.unique();
            strike (pool[k % pool.size()]);
            return h;
        }
        case RWaterfall:
        case RRising:
        {
            const Notes pool = doubledPool (U, in.addOctave);   // ascending
            if (k >= pool.size()) return h;        // one-shot finished
            strike (rhythm == RRising ? pool[k] : pool[pool.size() - 1 - k]);
            return h;
        }
        case RTremolo:
        {
            const int half = n / 2;
            if (k % 2 == 0)
            {
                if (in.bass >= 0) strike (in.bass);
                for (int i = 0; i < std::max (1, half); ++i) strike (U[i]);
            }
            else
                for (int i = std::max (1, half); i < n; ++i) strike (U[i]);
            if (h.rest) strike (U[n - 1]);
            return h;
        }
        case RTrill:
        {
            const int top = U[n - 1];
            int up = top + 1;
            while (up < top + 3 && ! ((in.poolMask >> pcOf (up)) & 1)) ++up;
            if (k == 0)
            {
                for (int i = 0; i < n - 1; ++i) h.hold.add (U[i]);
                if (in.bass >= 0) h.hold.add (in.bass);
                strike (top);
            }
            else strike (k % 2 == 1 ? up : top);
            h.rest = false;
            return h;
        }
        case RBoogie:
        {
            if (in.bass < 0) return h;
            const int b = in.bass;
            const bool minor = U.contains (b + 15) || U.contains (b + 27) || U.contains (b + 3);
            static const int majLine[8] = { 0, 4, 7, 9, 10, 9, 7, 4 };
            static const int minLine[8] = { 0, 3, 7, 9, 10, 9, 7, 3 };
            const int step = k % 8;
            strike (b + (minor ? minLine[step] : majLine[step]));
            if (k % 2 == 1)
            {
                addAll (h.notes, U);
                h.gate = 0.4f;
                h.accent = -4;
            }
            else
            {
                h.gate = 0.9f;
                if (step == 0) h.accent = 8;
            }
            return h;
        }
        default: break;
    }

    const char* p = def (rhythm).pattern;
    if (p == nullptr) { addAll (h.notes, U); h.rest = false; return h; }
    const int len = (int) std::strlen (p);
    const char c = p[k % len];
    const int bass = in.bass;
    switch (c)
    {
        case 'x': case 'X':
            if (bass >= 0) strike (bass);
            for (int i = 0; i < n; ++i) strike (U[i]);
            if (c == 'X') h.accent = 14;
            break;
        case 'c': case 'C':
            for (int i = 0; i < n; ++i) strike (U[i]);
            if (c == 'C') h.accent = 12;
            break;
        case 'b': strike (bass); h.accent = -12; break;
        case 'B': strike (bass); break;
        case 'F':
            if (bass >= 0) strike (bass - 5 >= 24 ? bass - 5 : bass + 7);
            break;
        case 'L': strike (bass >= 0 ? bass : U[0]); break;
        case 'T': strike (U[n - 1]); break;
        case 'M':
            if (n >= 3) for (int i = 1; i < n - 1; ++i) strike (U[i]);
            else strike (U[0]);
            break;
        case 'H': for (int i = n / 2; i < n; ++i) strike (U[i]); break;
        case 'h':
            if (bass >= 0) strike (bass);
            for (int i = 0; i < std::max (1, n / 2); ++i) strike (U[i]);
            break;
        default: break;   // rest
    }
    return h;
}

//==============================================================================
const char* extTypeName (int t)
{
    static const char* n[numExtTypes] = { "Tensions (9 11 13)", "Upper triad", "Octave sparkle", "Sus color (9 + 4)", "Stacked 4ths", "Bells (high 5ths)" };
    return n[std::clamp (t, 0, numExtTypes - 1)];
}

const char* extTypeBlurb (int t)
{
    static const char* n[numExtTypes] = {
        "Adds the 9th, 11th and 13th that fit the chord and key, above the top note",
        "A bright triad built from the tensions, floating over the chord",
        "Doubles the top of the chord an octave higher for sparkle",
        "Adds the 9th and 4th on top, open and floaty",
        "Stacks perfect 4ths above the chord, modern gospel and neo-soul",
        "Root and 5th way up high, like a bell" };
    return n[std::clamp (t, 0, numExtTypes - 1)];
}

const char* extModeName (int m)
{
    static const char* n[numExtModes] = { "Hold", "Pulse (tempo)", "Arpeggio (tempo)", "Waterfall (tempo)", "Waterfall loop", "Rising sweep" };
    return n[std::clamp (m, 0, numExtModes - 1)];
}

const char* extModeBlurb (int m)
{
    static const char* n[numExtModes] = {
        "The extension rings for as long as you hold the button",
        "The extension repeats in time with FL's tempo",
        "The extension notes arpeggiate in time",
        "Notes cascade down from the top of the extension through the chord, once per press",
        "The waterfall repeats every bar while you hold",
        "A sweep up through the chord into the extension" };
    return n[std::clamp (m, 0, numExtModes - 1)];
}

Notes upperExtension (const Chord& c, const Notes& voicingIn, int type, int keyRoot, int scale)
{
    Notes out;
    if (! c.valid() || voicingIn.empty()) return out;
    Notes v = voicingIn;
    v.sort();
    const int top = v.highest();
    const int m = tonesMask (c);
    auto has = [m] (int i) { return (m >> i) & 1; };
    const bool inKey = fitsScale (c, keyRoot, scale);
    const int pool = poolMask (keyRoot, scale);
    auto fits = [&] (int rel) { return ! inKey || ((pool >> pcOf (c.root + rel)) & 1); };
    auto inChord = [&] (int rel) { return has (pcOf (rel)); };

    // pick tensions: each group lists alternatives in order of preference (fixed arrays: audio-thread safe)
    int groups[3][3];
    auto setGroups = [&groups] (std::initializer_list<int> a, std::initializer_list<int> b, std::initializer_list<int> c3)
    {
        int gi = 0;
        for (auto l : { a, b, c3 })
        {
            int j = 0;
            for (int x : l) if (j < 3) groups[gi][j++] = x;
            while (j < 3) groups[gi][j++] = -1;
            ++gi;
        }
    };
    const bool dom = has (4) && has (10);
    const bool altered = dom && (has (1) || has (8) || (has (3) && has (4)));
    if (has (3) && has (6) && ! has (7))   setGroups ({ 17 }, { 20 }, { 14, 13 });
    else if (altered)                      setGroups ({ 13, 15 }, { 20 }, { 18 });
    else if (dom)                          setGroups ({ 14, 13, 15 }, { 21, 20 }, { 18 });
    else if (has (4))                      setGroups ({ 14 }, { 18 }, { 21 });
    else if (has (3))                      setGroups ({ 14 }, { 17 }, { 21, 20 });
    else                                   setGroups ({ 14 }, { 21 }, { 17 });

    Notes tensions;
    for (auto& g : groups)
        for (int rel : g)
            if (rel >= 0 && fits (rel) && ! inChord (rel)) { tensions.add (rel); break; }
    if (tensions.empty())
        for (int rel : { 14, 17, 21, 7 }) if (fits (rel)) { tensions.add (rel); break; }

    auto above = [&] (int rel, int floorNote)
    {
        int note = c.root + rel;
        while (note <= floorNote) note += 12;
        while (note > floorNote + 12) note -= 12;
        return note;
    };

    switch (type)
    {
        case ExtTensions:
        {
            int floorNote = top;
            for (int i = 0; i < tensions.size(); ++i)
            {
                const int note = above (tensions[i], floorNote);
                out.add (note);
                floorNote = note;
            }
            break;
        }
        case ExtUpperTriad:
        {
            Notes pcs = tensions;
            for (int rel : { 7, 4, 3, 10, 11 })
                if (pcs.size() < 3 && has (rel) && ! pcs.contains (rel)) pcs.add (rel);
            for (int i = 0; i < pcs.size(); ++i) out.add (above (pcs[i], top));
            break;
        }
        case ExtOctaves:
            out.add (top + 12);
            if (v.size() >= 2) out.add (v[v.size() - 2] + 12);
            break;
        case ExtSus:
        {
            const int first = fits (14) ? 14 : 13;
            const int second = fits (17) ? 17 : (fits (18) ? 18 : 21);
            const int a = above (first, top);
            out.add (a);
            out.add (above (second, a));
            break;
        }
        case ExtFourths:
        {
            int note = above (tensions.empty() ? 14 : tensions[0], top);
            out.add (note);
            for (int i = 0; i < 2; ++i)
            {
                int next = note + 5;
                if (inKey && ! ((pool >> pcOf (next)) & 1)) next = (pool >> pcOf (note + 6)) & 1 ? note + 6 : note + 4;
                out.add (next);
                note = next;
            }
            break;
        }
        case ExtBells:
        {
            const int r = above (0, top + 5);
            const int fifth = has (7) ? 7 : has (6) ? 6 : has (8) ? 8 : 7;
            out.add (r);
            out.add (r + fifth);
            out.add (r + 12);
            break;
        }
        default: break;
    }

    Notes clipped;
    for (int i = 0; i < out.size(); ++i)
    {
        int note = out[i];
        while (note > 112) note -= 12;
        if (note > top || out.size() == 1) clipped.add (note);
    }
    clipped.unique();
    return clipped;
}
} // namespace vesper
