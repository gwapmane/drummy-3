// VESPER band: plays the generated parts (core/Band) in time with FL, following the chords you play,
// each part on its own MIDI channel. Also keeps band copies of VESPER in step (LinkBus.h).
#include "PluginProcessor.h"

#include <algorithm>
#include <cmath>

using namespace vesper;

static constexpr double stepBeats = 0.25;   // the band runs on a 16th grid

//==============================================================================
// message thread
void VesperProcessor::rollBandSeed (int track)
{
    auto& r = juce::Random::getSystemRandom();
    bandSeed[(size_t) juce::jlimit (0, maxBandTracks - 1, track)].store ((uint32_t) r.nextInt() | 1u);
}

float VesperProcessor::trackValue (int track, int which) const
{
    return bandParams[(size_t) juce::jlimit (0, maxBandTracks - 1, track)][(size_t) juce::jlimit (0, numTrackParams - 1, which)]->load();
}

void VesperProcessor::setTrackValue (int track, int which, float plain)
{
    if (auto* prm = apvts.getParameter (ids::track (track, trackParamSuffix (which))))
        prm->setValueNotifyingHost (prm->convertTo0to1 (plain));
}

int VesperProcessor::trackType (int track) const
{
    return juce::jlimit (0, numBandTypes - 1, (int) std::lround (trackValue (track, TpType)));
}

int VesperProcessor::freeChannel (int exceptTrack) const
{
    uint32_t used = 1u << (juce::jlimit (1, 16, (int) apvts.getRawParameterValue (ids::chordCh)->load()) - 1);
    const int count = juce::jlimit (0, maxBandTracks, numTracks.load());
    for (int t = 0; t < count; ++t)
        if (t != exceptTrack) used |= 1u << (juce::jlimit (1, 16, (int) trackValue (t, TpCh)) - 1);
    static const int order[16] = { 2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 10, 1 };
    const bool drums = exceptTrack >= 0 && bandTypeIsDrums (trackType (exceptTrack));
    if (drums) return 10;   // every drum track shares channel 10, so one drum plugin (VESPER DRUMS, FPC...) plays the whole kit
    for (int ch : order) if (! ((used >> (ch - 1)) & 1u)) return ch;
    return 16;
}

bool VesperProcessor::addTrack()
{
    const int n = numTracks.load();
    if (n >= maxBandTracks) return false;
    const int t = n;
    // start as an instrument the band doesn't have yet
    bool have[numBandTypes] = {};
    for (int k = 0; k < n; ++k) have[trackType (k)] = true;
    static const int prefer[] = { BKeys, BPad, BArp, BGuitar, BStrings, BHorns, BMelody, BCounter, BBass, BDrums };
    int type = bandDefaultType (t);
    for (int ty : prefer) if (! have[ty]) { type = ty; break; }
    const int genre = (int) apvts.getRawParameterValue (ids::bandGenre)->load();
    const auto preset = bandGenrePreset (genre);
    setTrackValue (t, TpType, (float) type);
    setTrackValue (t, TpMode, (float) ModeJam);
    setTrackValue (t, TpStyle, (float) preset.style[type]);
    setTrackValue (t, TpDens, 0.5f);
    setTrackValue (t, TpCplx, 0.5f);
    setTrackValue (t, TpOct, 0.0f);
    setTrackValue (t, TpLvl, 0.75f);
    setTrackValue (t, TpDyn, type == BStrings ? 2.0f : 0.0f);
    trackKeys[(size_t) t].store (0);
    rollBandSeed (t);
    numTracks.store (n + 1);
    setTrackValue (t, TpCh, (float) freeChannel (t));
    setTrackValue (t, TpOn, 1.0f);
    tracksChanged.fetch_add (1);
    return true;
}

void VesperProcessor::removeTrack (int track)
{
    const int n = numTracks.load();
    if (n <= 1 || track < 0 || track >= n) return;
    // every track below it moves up one
    for (int t = track; t < n - 1; ++t)
    {
        for (int w = 0; w < numTrackParams; ++w) setTrackValue (t, w, trackValue (t + 1, w));
        bandSeed[(size_t) t].store (bandSeed[(size_t) (t + 1)].load());
        trackKeys[(size_t) t].store (trackKeys[(size_t) (t + 1)].load());
    }
    setTrackValue (n - 1, TpOn, 0.0f);
    trackKeys[(size_t) (n - 1)].store (0);
    numTracks.store (n - 1);
    tracksChanged.fetch_add (1);
}

void VesperProcessor::setTrackType (int track, int type)
{
    type = juce::jlimit (0, numBandTypes - 1, type);
    if (type == trackType (track)) return;
    const int genre = (int) apvts.getRawParameterValue (ids::bandGenre)->load();
    const auto preset = bandGenrePreset (genre);
    setTrackValue (track, TpType, (float) type);
    setTrackValue (track, TpStyle, (float) preset.style[type]);
    setTrackValue (track, TpDens, preset.density[type]);
    setTrackValue (track, TpCplx, preset.complexity[type]);
    setTrackValue (track, TpDyn, type == BStrings ? 2.0f : 0.0f);
    if (! bandTypeCanHold (type)) setTrackValue (track, TpMode, (float) ModeJam);
    if (bandTypeIsDrums (type))
        setTrackValue (track, TpCh, 10.0f);   // drums go to channel 10 (the General MIDI drum channel), all together
    tracksChanged.fetch_add (1);
}

void VesperProcessor::setAllHold (bool hold)
{
    const int n = numTracks.load();
    for (int t = 0; t < n; ++t)
        if (bandTypeCanHold (trackType (t)))
            setTrackValue (t, TpMode, (float) (hold ? ModeHold : ModeJam));
}

bool VesperProcessor::allHold() const
{
    const int n = numTracks.load();
    bool any = false;
    for (int t = 0; t < n; ++t)
    {
        if (! bandTypeCanHold (trackType (t)) || trackValue (t, TpOn) < 0.5f) continue;
        any = true;
        if ((int) std::lround (trackValue (t, TpMode)) != ModeHold) return false;
    }
    return any;
}

void VesperProcessor::applyBandGenre (int genre)
{
    const BandGenrePreset preset = bandGenrePreset (genre);
    const int n = numTracks.load();
    bool anyOn = false;
    for (int t = 0; t < n; ++t) anyOn = anyOn || trackValue (t, TpOn) > 0.5f;
    for (int t = 0; t < n; ++t)
    {
        const int type = trackType (t);
        setTrackValue (t, TpStyle, (float) preset.style[type]);
        setTrackValue (t, TpDens, preset.density[type]);
        setTrackValue (t, TpCplx, preset.complexity[type]);
        if (! anyOn) setTrackValue (t, TpOn, ((preset.lineup >> type) & 1) ? 1.0f : 0.0f);
    }
    if (auto* prm = apvts.getParameter (ids::bandGenre))
        prm->setValueNotifyingHost (prm->convertTo0to1 ((float) genre));
}

void VesperProcessor::stopBandFromUi()
{
    int s1, z1, s2, z2;
    uiFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    auto& e = uiEvents[(size_t) (z1 > 0 ? s1 : s2)];
    e = UiEvent();
    e.type = 6;
    uiFifo.finishedWrite (1);
}

//==============================================================================
// audio thread
void VesperProcessor::readBand()
{
    linkNowMs = juce::Time::getMillisecondCounterHiRes();
    chordChannel = juce::jlimit (1, 16, (int) apvts.getRawParameterValue (ids::chordCh)->load());
    bandEnabled = apvts.getRawParameterValue (ids::bandOn)->load() > 0.5f;
    bandStopMode = (int) apvts.getRawParameterValue (ids::bandStop)->load();
    bandRoleNow = juce::jlimit (0, (int) maxBandTracks, (int) apvts.getRawParameterValue (ids::bandRole)->load());
    if (bandRoleNow != 0) return;   // a band copy takes everything from the main VESPER

    static const int phrases[4] = { 1, 2, 4, 8 };
    bandCfg.phraseBars = phrases[juce::jlimit (0, 3, (int) apvts.getRawParameterValue (ids::bandPhrase)->load())];
    bandCfg.swing = apvts.getRawParameterValue (ids::bandSwing)->load() / 100.0f * 0.5f;
    bandCfg.numTracks = juce::jlimit (0, (int) maxBandTracks, numTracks.load());
    bandCfg.genre = juce::jlimit (0, numGenres - 1, (int) apvts.getRawParameterValue (ids::bandGenre)->load());
    bandCfg.groove = juce::jlimit (0, groovesPerGenre - 1, (int) apvts.getRawParameterValue (ids::bandGroove)->load());
    for (int t = 0; t < maxBandTracks; ++t)
    {
        const auto& prm = bandParams[(size_t) t];
        auto& pc = bandCfg.part[(size_t) t];
        pc.type = juce::jlimit (0, numBandTypes - 1, (int) std::lround (prm[TpType]->load()));
        pc.on = prm[TpOn]->load() > 0.5f && t < bandCfg.numTracks;
        pc.mode = bandTypeCanHold (pc.type) ? juce::jlimit (0, numBandModes - 1, (int) std::lround (prm[TpMode]->load())) : (int) ModeJam;
        pc.style = juce::jlimit (0, bandNumStyles (pc.type) - 1, (int) std::lround (prm[TpStyle]->load()));
        pc.density = prm[TpDens]->load();
        pc.complexity = prm[TpCplx]->load();
        pc.octave = juce::jlimit (-2, 2, (int) std::lround (prm[TpOct]->load()));
        pc.level = prm[TpLvl]->load();
        pc.channel = juce::jlimit (1, 16, (int) std::lround (prm[TpCh]->load()));
        pc.dyn = juce::jlimit (0, 3, (int) prm[TpDyn]->load());
        pc.keyMask = (uint16_t) (trackKeys[(size_t) t].load (std::memory_order_relaxed) & 0xfff);
        pc.seed = bandSeed[(size_t) t].load();
    }
    updateKeysSkip();
}

void VesperProcessor::updateKeysSkip()
{
    keysSkip = 0;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const auto& d = bandCfg.part[(size_t) t];
        if (d.on && bandTypeIsDrums (d.type) && bandPartHere (t) && d.channel != chordChannel)
            keysSkip = (uint16_t) (keysSkip | (1u << (d.channel - 1)));   // the keys sound doesn't play drum notes
    }
}

bool VesperProcessor::bandPartHere (int track) const
{
    if (bandRoleNow == 0) return ! LinkBus::get().isClaimed (track, linkNowMs);
    return bandRoleNow - 1 == track;
}

bool VesperProcessor::anyBandPartOn() const
{
    // the band clock is only needed for tracks that play their style (HOLD / RING follow your hands)
    for (int t = 0; t < bandCfg.numTracks; ++t)
        if (bandCfg.part[(size_t) t].on && bandCfg.part[(size_t) t].mode == ModeJam) return true;
    return false;
}

bool VesperProcessor::anyChordHeld() const
{
    for (int i = 0; i < numChordSlots; ++i)
        if (slots[(size_t) i].active && ! slots[(size_t) i].isExt) return true;
    return false;
}

double VesperProcessor::lateWindowBeats() const
{
    // a chord that lands just after a band step still makes that step (players are rarely dead on the grid)
    return juce::jmin (0.45 * stepBeats, 0.08 * bpm / 60.0);
}

void VesperProcessor::activateBandSlots()
{
    for (int t = 0; t < maxBandTracks; ++t)
    {
        auto& s = slots[(size_t) bandSlot (t)];
        s = Slot();
        s.active = true;
        s.source = -100 - t;
    }
}

void VesperProcessor::bandChordChanged (const Chord& chord, int pos, juce::MidiBuffer& out, int key)
{
    if (bandRoleNow != 0 || ! chord.valid()) return;
    bandHarm.chord = chord;
    bandHarm.key = key;
    bandHarm.keyRoot = cfg.keyRoot;
    bandHarm.scale = cfg.scale;
    bandHarm.id = ++bandHarmCounter;
    bandHarmBeat = beatAt (pos);
    bandStopAt = -1;
    if (! bandRunning)
    {
        if (bandEnabled && anyBandPartOn()) startBand (pos, out);
        return;
    }
    adoptHarmony (pos, out);
}

void VesperProcessor::startBand (int pos, juce::MidiBuffer& out)
{
    for (int t = 0; t < maxBandTracks; ++t) clearSlotNotes (bandSlot (t), pos, out);
    band.reset();
    activateBandSlots();
    bandRunning = true;
    ++bandStarts;
    bandStopAt = -1;
    bandSynced = hostPlaying;
    const double now = beatAt (pos);
    if (bandSynced)
    {
        bandOrigin = 0;
        auto k = (int64_t) std::floor (now / stepBeats + 1e-9);
        if (now - (double) k * stepBeats > lateWindowBeats()) ++k;
        bandNextStep = k;
    }
    else
    {
        bandOrigin = now;     // FL stopped: your first chord is bar 1
        bandNextStep = 0;
    }
    bandLastStep = -1;
    bandLastStepBeat = -1e9;
    advanceBand (pos, out, true);
}

void VesperProcessor::stopBand (int pos, juce::MidiBuffer& out)
{
    for (int t = 0; t < maxBandTracks; ++t)
    {
        const int si = bandSlot (t);
        if (slots[(size_t) si].active) releaseSlot (si, pos, out);
    }
    if (bandRunning)
        for (int t = 0; t < bandCfg.numTracks; ++t)
        {
            const auto& tc = bandCfg.part[(size_t) t];
            if (tc.on && tc.mode == ModeJam && (tc.type == BStrings || tc.type == BHorns || tc.type == BPad))
                out.addEvent (juce::MidiMessage::controllerEvent (tc.channel, 11, 127), pos);   // swells back to full
        }
    bandRunning = false;
    bandStopAt = -1;
    bandLastStep = -1;
    bandLastStepBeat = -1e9;
}

void VesperProcessor::adoptHarmony (int pos, juce::MidiBuffer& out)
{
    // the old chord's notes stop where the new chord starts
    for (int t = 0; t < maxBandTracks; ++t)
        if (! bandTypeIsDrums (bandCfg.part[(size_t) t].type)) clearSlotNotes (bandSlot (t), pos, out);

    // landed just after a step: play that step again with the new chord instead of waiting for the next one
    if (bandLastStep >= 0 && bandHarmBeat < bandLastStepBeat + lateWindowBeats())
        fireBandStep (bandLastStep, bandLastStepBeat, true, sampleClock + pos, out);
}

void VesperProcessor::fireBandStep (int64_t step, double stepBeat, bool pitchedOnly, int64_t minDue, juce::MidiBuffer& out)
{
    BandEvent ev[Band::maxEventsPerStep];
    const int n = band.step (bandCfg, bandHarm, step, ev, Band::maxEventsPerStep);
    uint32_t hit = 0;
    for (int i = 0; i < n; ++i)
    {
        const BandEvent& e = ev[i];
        if (e.part < 0 || e.part >= maxBandTracks) continue;
        const auto& tc = bandCfg.part[(size_t) e.part];
        if (pitchedOnly && (bandTypeIsDrums (tc.type) || e.isCC)) continue;
        if (! bandPartHere (e.part)) continue;
        if (bandHarm.sitsOut (tc)) continue;   // the track's key strip skips the key you're holding
        const double t = stepBeat + e.offset * stepBeats;
        int64_t due = sampleClock + (int64_t) std::llround ((t - blockBeat) * samplesPerBeat);
        due = std::max (due, minDue);
        if (e.isCC)
        {
            const int pos = (int) juce::jlimit<int64_t> (0, juce::jmax (0, blockSamples - 1), due - sampleClock);
            out.addEvent (juce::MidiMessage::controllerEvent (e.channel, e.note, e.velocity), pos);
            continue;
        }
        const int64_t len = e.length < 0.0f ? -1 : std::max<int64_t> (1, (int64_t) std::llround (e.length * stepBeats * samplesPerBeat));
        schedule (due, e.note, e.velocity, e.channel, bandSlot (e.part), len);
        hit |= 1u << e.part;
    }
    for (int t = 0; t < maxBandTracks; ++t)
        if ((hit >> t) & 1u) partHits[(size_t) t].fetch_add (1, std::memory_order_relaxed);
}

void VesperProcessor::advanceBand (int upToPos, juce::MidiBuffer& out, bool inclusive)
{
    if (! bandRunning) return;
    const double limit = beatAt (upToPos) + (inclusive ? 1e-6 : 0.0);
    const int64_t minDue = sampleClock + (inclusive ? upToPos : 0);
    for (int guard = 0; guard < 64; ++guard)
    {
        const double stepBeat = bandOrigin + (double) bandNextStep * stepBeats;
        if (stepBeat >= limit) break;
        if (bandStopAt >= 0 && stepBeat >= bandStopAt - 1e-9)
        {
            stopBand (posOfBeat (stepBeat), out);
            return;
        }
        fireBandStep (bandNextStep, stepBeat, false, minDue, out);
        bandLastStep = bandNextStep;
        bandLastStepBeat = stepBeat;
        ++bandNextStep;
    }
}

void VesperProcessor::checkBandClock (int pos, juce::MidiBuffer& out)
{
    if (! bandSynced) return;
    const double now = beatAt (pos);
    const double next = bandOrigin + (double) bandNextStep * stepBeats;
    if (next < now - 0.5 || next > now + 1.0)
    {
        // FL looped or jumped: pick the band up at the new spot
        for (int t = 0; t < maxBandTracks; ++t) clearSlotNotes (bandSlot (t), pos, out);
        bandNextStep = (int64_t) std::ceil ((now - bandOrigin) / stepBeats - 1e-9);
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
    }
}

void VesperProcessor::bandHousekeeping (int pos, juce::MidiBuffer& out)
{
    // RING tracks that were switched off (or out of RING) let go
    for (int t = 0; t < maxBandTracks; ++t)
    {
        if (! ((ringMask >> t) & 1u)) continue;
        const auto& tc = bandCfg.part[(size_t) t];
        if (! bandEnabled || ! tc.on || tc.mode != ModeRing)
        {
            clearSlotNotes (ringSlot (t), pos, out);
            ringMask &= ~(1u << t);
        }
    }

    if (! bandRunning)
    {
        // a part switched on while a chord is down: start right away
        if (bandEnabled && anyBandPartOn() && anyChordHeld() && bandHarm.valid()) startBand (pos, out);
        return;
    }
    if (! bandEnabled || ! anyBandPartOn())
    {
        stopBand (pos, out);
        return;
    }

    if (bandSynced != hostPlaying)
    {
        if (! hostPlaying && bandStopMode == 2)
        {
            stopBand (pos, out);   // NEVER mode stops with FL
            return;
        }
        bandSynced = hostPlaying;
        const double now = beatAt (pos);
        if (bandSynced) { bandOrigin = 0; bandNextStep = (int64_t) std::ceil (now / stepBeats - 1e-9); }
        else            { bandOrigin = now; bandNextStep = 0; }
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
    }
    else checkBandClock (pos, out);

    // tracks switched off, out of JAM, or taken over by a band copy go quiet
    for (int t = 0; t < maxBandTracks; ++t)
    {
        const auto& tc = bandCfg.part[(size_t) t];
        if (! (tc.on && tc.mode == ModeJam && bandPartHere (t)))
        {
            const auto& s = slots[(size_t) bandSlot (t)];
            if (! s.sent.empty()) clearSlotNotes (bandSlot (t), pos, out);
        }
    }

    if (anyChordHeld()) { bandStopAt = -1; return; }
    if (bandStopAt >= 0 || bandStopMode == 2) return;
    const double now = beatAt (pos);
    if (bandStopMode == 0)
        bandStopAt = now + 0.15 * bpm / 60.0;   // a short grace, so moving between chords doesn't stop the band
    else
    {
        const double bars = std::ceil ((now - bandOrigin) / 4.0 - 1e-9);
        bandStopAt = bandOrigin + bars * 4.0;
        if (bandStopAt < now + 0.01) bandStopAt = now + 0.15 * bpm / 60.0;
    }
}

//==============================================================================
// link between VESPER copies
void VesperProcessor::publishLink()
{
    LinkSnapshot s;
    s.leaderId = linkId;
    s.wallMs = linkNowMs;
    s.cfg = bandCfg;
    s.harm = bandHarm;
    s.harmBeat = bandHarmBeat;
    s.running = bandRunning;
    s.starts = bandStarts;
    s.synced = bandSynced;
    s.origin = bandOrigin;
    s.clock = sampleClock;
    s.beat = blockBeat;
    s.spb = samplesPerBeat;
    LinkBus::get().publish (s);
}

void VesperProcessor::followLeader (juce::MidiBuffer& out)
{
    const int part = juce::jlimit (0, maxBandTracks - 1, bandRoleNow - 1);
    LinkSnapshot L;
    auto& bus = LinkBus::get();
    if (! bus.read (L) || linkNowMs - L.wallMs > 1000.0 || L.leaderId == linkId)
    {
        followState.store (2);
        if (bandRunning) stopBand (0, out);
        return;
    }
    followState.store (1);
    bus.claim (part, linkNowMs + 600.0);
    bandCfg = L.cfg;
    updateKeysSkip();

    // where the leader's band clock is right now, in our own clock
    const double obs = (double) (L.clock - sampleClock);
    if (L.leaderId != linkLeaderSeen)
    {
        linkLeaderSeen = L.leaderId;
        linkDeltaBest = obs;
        linkStarts = 0;
        linkHarmId = -1;
    }
    linkDeltaBest = std::max (linkDeltaBest, obs);   // same audio cycle = the largest difference we see
    const double offset = (L.synced && hostPlaying) ? 0.0
                        : (L.beat + ((double) sampleClock + linkDeltaBest - (double) L.clock) / L.spb) - blockBeat;

    const bool wanted = L.running && L.cfg.part[(size_t) part].on && L.cfg.part[(size_t) part].mode == ModeJam;
    if (! wanted)
    {
        if (bandRunning) stopBand (0, out);
        linkStarts = L.starts;
        linkHarmId = L.harm.id;
        return;
    }

    const double now = blockBeat;
    auto anchor = [&]
    {
        bandSynced = L.synced;
        bandOrigin = L.origin - offset;
        auto k = (int64_t) std::floor ((now - bandOrigin) / stepBeats + 1e-9);
        if (now - (bandOrigin + (double) k * stepBeats) > lateWindowBeats()) ++k;
        bandNextStep = bandSynced ? k : std::max<int64_t> (0, k);
        bandLastStep = -1;
        bandLastStepBeat = -1e9;
        linkOriginSeen = L.origin;
        linkSyncedSeen = L.synced;
    };

    if (! bandRunning || L.starts != linkStarts)
    {
        if (bandRunning) stopBand (0, out);
        band.reset();
        activateBandSlots();
        bandRunning = true;
        linkStarts = L.starts;
        bandHarm = L.harm;
        linkHarmId = L.harm.id;
        bandHarmBeat = L.harmBeat - offset;
        anchor();
        advanceBand (0, out, true);   // the leader's first step, if we're a moment behind it
        return;
    }

    if (L.synced != linkSyncedSeen || std::abs (L.origin - linkOriginSeen) > 1e-9)
        anchor();                         // FL started or stopped
    else
        checkBandClock (0, out);

    if (L.harm.id != linkHarmId)
    {
        linkHarmId = L.harm.id;
        bandHarm = L.harm;
        bandHarmBeat = L.harmBeat - offset;
        adoptHarmony (0, out);
    }
}

//==============================================================================
// HOLD and RING tracks: they play what you press (not a style), each on its own channel
void VesperProcessor::playLayers (int source, const Chord& chord, const Notes& pressed, int velocity, int pos, juce::MidiBuffer& out)
{
    if (bandRoleNow != 0) return;   // the main VESPER plays HOLD / RING tracks
    const int keyPc = (source >= 0 && source < 128) ? source % 12 : -1;
    int layer = -1;
    for (int t = 0; t < bandCfg.numTracks; ++t)
    {
        const auto& tc = bandCfg.part[(size_t) t];
        if ((ringMask >> t) & 1u)
        {
            // RING: the last note lets go now that you've pressed another key
            clearSlotNotes (ringSlot (t), pos, out);
            ringMask &= ~(1u << t);
        }
        if (! bandEnabled || ! tc.on || tc.mode == ModeJam || ! bandTypeCanHold (tc.type)) continue;
        if (keyPc >= 0 && ((tc.keyMask >> keyPc) & 1)) continue;   // key strip: this track sits this key out
        const Notes notes = bandHoldNotes (tc, pressed, chord);
        if (notes.empty()) continue;
        const int vel = juce::jlimit (1, 127, juce::roundToInt ((float) velocity * (0.45f + 0.75f * tc.level)));
        int slot;
        if (tc.mode == ModeHold)
        {
            // a second slot for the same key: it lets go when the key does (or when HOLD lets the chord go)
            if (layer < 0) layer = allocSlot (source, pos, out);
            slot = layer;
        }
        else
        {
            slot = ringSlot (t);
            auto& rs = slots[(size_t) slot];
            rs = Slot();
            rs.active = true;
            rs.source = -200 - t;
            ringMask |= 1u << t;
        }
        for (int i = 0; i < notes.size(); ++i) schedule (sampleClock + pos, notes[i], vel, tc.channel, slot, -1);
        partHits[(size_t) t].fetch_add (1, std::memory_order_relaxed);
    }
}

void VesperProcessor::clearRings (int pos, juce::MidiBuffer& out)
{
    for (int t = 0; t < maxBandTracks; ++t)
    {
        clearSlotNotes (ringSlot (t), pos, out);
        slots[(size_t) ringSlot (t)].active = false;
    }
    ringMask = 0;
}
