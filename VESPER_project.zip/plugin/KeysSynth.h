// Built-in electric piano so VESPER makes sound before anything is routed.
// Two-operator FM tine with a short "bark", velocity brightness and a gentle stereo tremolo.
#pragma once

#include <array>
#include <cmath>
#include <cstdint>

class KeysSynth
{
public:
    void prepare (double sampleRate)
    {
        sr = sampleRate > 0 ? sampleRate : 44100.0;
        for (auto& v : voices) v = Voice();
        tremPhase = 0;
    }

    void noteOn (int note, int velocity)
    {
        if (note < 0 || note > 127) return;
        // retrigger the same note on its own voice
        Voice* target = nullptr;
        for (auto& v : voices) if (v.active && v.note == note) { target = &v; break; }
        if (target == nullptr)
            for (auto& v : voices) if (! v.active) { target = &v; break; }
        if (target == nullptr)
        {
            target = &voices[0];
            for (auto& v : voices) if (v.age > target->age) target = &v;
        }

        const double vel = velocity / 127.0;
        Voice& v = *target;
        v = Voice();
        v.active = true;
        v.note = note;
        v.freq = 440.0 * std::pow (2.0, (note - 69) / 12.0);
        v.amp = 0.18 * (0.25 + 0.75 * std::pow (vel, 1.4));
        v.index = 0.5 + 2.6 * vel * vel;
        const double t = std::fmax (0.6, std::fmin (3.2, 3.2 - (note - 36) * 0.035));
        v.decay = std::exp (-1.0 / (t * sr));
        v.indexDecay = std::exp (-1.0 / (0.35 * sr));
        v.barkDecay = std::exp (-1.0 / (0.03 * sr));
        v.bark = (v.freq * 14.0 < sr * 0.45) ? 0.35 * vel : 0.0;
        v.env = 1.0;
        v.attack = 0.0;
        v.attackStep = 1.0 / (0.002 * sr);
        for (auto& o : voices) if (o.active) ++o.age;
        v.age = 0;
    }

    void noteOff (int note)
    {
        for (auto& v : voices)
            if (v.active && v.note == note && ! v.releasing)
            {
                if (sustain) v.heldBySustain = true;
                else release (v);
            }
    }

    void setSustain (bool down)
    {
        sustain = down;
        if (! down)
            for (auto& v : voices)
                if (v.active && v.heldBySustain) { v.heldBySustain = false; release (v); }
    }

    void setExpression (float e) { exprTarget = e < 0.0f ? 0.0f : (e > 1.0f ? 1.0f : e); }

    void allOff()
    {
        for (auto& v : voices) if (v.active) release (v);
    }

    void render (float* left, float* right, int numSamples, float gain)
    {
        const double twoPi = 6.283185307179586;
        const double tremInc = 4.6 / sr;
        for (int i = 0; i < numSamples; ++i)
        {
            double sum = 0;
            for (auto& v : voices)
            {
                if (! v.active) continue;
                if (v.attack < 1.0) v.attack = std::fmin (1.0, v.attack + v.attackStep);
                const double mod = std::sin (twoPi * v.phase) * v.index;
                double s = std::sin (twoPi * v.phase + mod);
                if (v.bark > 0) s += std::sin (twoPi * v.phase * 14.0) * v.bark;
                sum += s * v.amp * v.env * v.attack;

                v.phase += v.freq / sr;
                if (v.phase >= 1.0) v.phase -= 1.0;
                v.env *= v.releasing ? v.releaseDecay : v.decay;
                v.index = 0.35 + (v.index - 0.35) * v.indexDecay;
                v.bark *= v.barkDecay;
                if (v.env < 0.0004) v.active = false;
            }
            expr += (exprTarget - expr) * 0.0015f;
            sum *= expr;
            const double trem = 0.22 * std::sin (twoPi * tremPhase);
            tremPhase += tremInc;
            if (tremPhase >= 1.0) tremPhase -= 1.0;
            const float l = (float) (sum * (1.0 + trem)) * gain;
            const float r = (float) (sum * (1.0 - trem)) * gain;
            left[i] += softClip (l);
            right[i] += softClip (r);
        }
    }

private:
    struct Voice
    {
        bool active = false, releasing = false, heldBySustain = false;
        int note = 0;
        uint32_t age = 0;
        double freq = 0, phase = 0, amp = 0, index = 0, env = 0, decay = 1, releaseDecay = 1;
        double indexDecay = 1, bark = 0, barkDecay = 1, attack = 0, attackStep = 1;
    };

    void release (Voice& v)
    {
        v.releasing = true;
        v.releaseDecay = std::exp (-1.0 / (0.09 * sr));
    }

    static float softClip (float x) { return x / (1.0f + std::fabs (x) * 0.6f); }

    std::array<Voice, 40> voices {};
    double sr = 44100.0;
    double tremPhase = 0;
    bool sustain = false;
    float expr = 1.0f, exprTarget = 1.0f;
};
