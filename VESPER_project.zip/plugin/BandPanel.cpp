#include "BandPanel.h"

#include <cmath>

using namespace vesper;

// layout (inside the 1124 x 266 content area)
static constexpr int listTop = 48, stripH = 70, stripGapY = 3, colW = 552, colGap = 10;

//==============================================================================
// KEY STRIP
juce::Rectangle<float> KeyStrip::keyRect (int pc) const
{
    static const int whiteIndex[12] = { 0, -1, 1, -1, 2, 3, -1, 4, -1, 5, -1, 6 };
    static const float blackPos[12] = { 0, 1, 0, 2, 0, 0, 4, 0, 5, 0, 6, 0 };   // the white key it sits after
    const auto b = getLocalBounds().toFloat().reduced (0.5f);
    const float ww = b.getWidth() / 7.0f;
    if (whiteIndex[pc] >= 0)
        return { b.getX() + ww * (float) whiteIndex[pc], b.getY(), ww, b.getHeight() };
    const float bw = ww * 0.62f;
    return { b.getX() + ww * blackPos[pc] - bw * 0.5f, b.getY(), bw, b.getHeight() * 0.58f };
}

int KeyStrip::keyAt (juce::Point<float> p) const
{
    for (int pc : { 1, 3, 6, 8, 10 }) if (keyRect (pc).contains (p)) return pc;
    for (int pc : { 0, 2, 4, 5, 7, 9, 11 }) if (keyRect (pc).contains (p)) return pc;
    return -1;
}

void KeyStrip::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const int m = mask.load();
    const bool scaleMode = ctx.proc().ui.keysMode == 0;
    const bool on = isEnabled();
    static const char* letters[12] = { "C", "", "D", "", "E", "F", "", "G", "", "A", "", "B" };
    static const char* degrees[12] = { "1", "", "2", "", "3", "4", "", "5", "", "6", "", "7" };
    auto drawKey = [&] (int pc, bool black)
    {
        const auto r = keyRect (pc).reduced (black ? 0.0f : 0.6f, 0.0f);
        const bool muted = (m >> pc) & 1;
        juce::Colour fill = muted ? t.cardDark : (black ? t.home.darker (0.45f) : t.home);
        if (! on) fill = fill.withMultipliedSaturation (0.3f).withAlpha (0.5f);
        g.setColour (fill);
        g.fillRoundedRectangle (r, black ? 1.5f : 2.5f);
        g.setColour (t.panelEdge);
        g.drawRoundedRectangle (r, black ? 1.5f : 2.5f, 0.8f);
        if (muted)
        {
            g.setColour (t.dim.withAlpha (0.8f));
            const auto c = r.withSizeKeepingCentre (5.0f, 5.0f).translated (0.0f, black ? -1.0f : -3.0f);
            g.drawLine (c.getX(), c.getY(), c.getRight(), c.getBottom(), 1.1f);
            g.drawLine (c.getRight(), c.getY(), c.getX(), c.getBottom(), 1.1f);
        }
        if (! black && r.getWidth() >= 11.0f)
        {
            g.setFont (uiFont (8.5f, true));
            g.setColour (muted ? t.dim : t.bgBottom);
            g.drawText (scaleMode ? degrees[pc] : letters[pc], r.withTrimmedTop (r.getHeight() * 0.55f), juce::Justification::centred);
        }
    };
    for (int pc : { 0, 2, 4, 5, 7, 9, 11 }) drawKey (pc, false);
    for (int pc : { 1, 3, 6, 8, 10 }) drawKey (pc, true);
}

void KeyStrip::mouseDown (const juce::MouseEvent& e)
{
    const int k = keyAt (e.position);
    if (k < 0) return;
    const int m = mask.load();
    dragTo = ((m >> k) & 1) ? 0 : 1;   // 1 = sit out
    mask.store (dragTo ? (m | (1 << k)) : (m & ~(1 << k)));
    lastKey = k;
    repaint();
}

void KeyStrip::mouseDrag (const juce::MouseEvent& e)
{
    if (dragTo < 0) return;
    const int k = keyAt (e.position);
    if (k < 0 || k == lastKey) return;
    const int m = mask.load();
    mask.store (dragTo ? (m | (1 << k)) : (m & ~(1 << k)));
    lastKey = k;
    repaint();
}

//==============================================================================
void IconButton::paintButton (juce::Graphics& g, bool over, bool down)
{
    const auto& t = ctx.theme();
    const auto r = getLocalBounds().toFloat().reduced (0.5f);
    g.setColour (down ? t.cardDark : (over ? t.cardHi : t.card.brighter (0.06f)));
    g.fillRoundedRectangle (r, 4.0f);
    g.setColour (t.panelEdge);
    g.drawRoundedRectangle (r, 4.0f, 1.0f);
    g.setColour (isEnabled() ? t.text : t.faint);
    const auto c = r.getCentre();
    if (kind == DownArrow || kind == Left || kind == Right)
    {
        juce::Path p;
        if (kind == DownArrow) p.addTriangle (c.x - 4.5f, c.y - 2.5f, c.x + 4.5f, c.y - 2.5f, c.x, c.y + 3.0f);
        else if (kind == Left) p.addTriangle (c.x + 2.5f, c.y - 4.5f, c.x + 2.5f, c.y + 4.5f, c.x - 3.0f, c.y);
        else p.addTriangle (c.x - 2.5f, c.y - 4.5f, c.x - 2.5f, c.y + 4.5f, c.x + 3.0f, c.y);
        g.fillPath (p);
    }
    else
    {
        g.drawLine (c.x - 3.5f, c.y - 3.5f, c.x + 3.5f, c.y + 3.5f, 1.6f);
        g.drawLine (c.x + 3.5f, c.y - 3.5f, c.x - 3.5f, c.y + 3.5f, 1.6f);
    }
}

//==============================================================================
// one track
BandPanel::Strip::Strip (BandPanel& owner, int t)
    : panel (owner), ctx (owner.ctx), track (t),
      typeBtn (owner.ctx, IconButton::DownArrow), remove (owner.ctx, IconButton::Cross),
      drag (owner.ctx, t), keys (owner.ctx, owner.ctx.proc().trackKeys[(size_t) t])
{
    auto& p = ctx.proc();
    auto& apvts = p.apvts;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;
    type = p.trackType (track);

    on.setButtonText (bandTypeName (type));
    on.setClickingTogglesState (true);
    on.setTooltip ("Track " + juce::String (track + 1) + ": click to turn it on or off");
    on.getProperties().set ("radius", 4.0);
    addAndMakeVisible (on);
    buttonAtt.push_back (std::make_unique<BA> (apvts, ids::track (track, "On"), on));

    typeBtn.setTooltip ("TYPE: what this track is (melody, bass, drums, pad, keys, arp, guitar...). Any slot can be any instrument");
    typeBtn.onClick = [this] { showTypeMenu(); };
    addAndMakeVisible (typeBtn);

    for (int st = 0; st < bandNumStyles (type); ++st) style.addItem (bandStyleName (type, st), st + 1);
    style.onChange = [this]
    {
        const int idx = style.getSelectedItemIndex();
        if (idx >= 0 && idx != lastStyle)
        {
            lastStyle = idx;
            ctx.proc().setTrackValue (track, TpStyle, (float) idx);
            style.setTooltip (bandStyleBlurb (type, idx));
        }
    };
    addAndMakeVisible (style);

    dice.setTooltip ("A new line in the same style. Each roll is one of billions");
    dice.onClick = [this] { ctx.proc().rollBandSeed (track); };
    addAndMakeVisible (dice);

    for (int ch = 1; ch <= 16; ++ch) channel.addItem ("CH " + juce::String (ch), ch);
    channel.setTooltip ("MIDI channel this track plays on. In Patcher, VFX Color Mapper output N = channel N");
    addAndMakeVisible (channel);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::track (track, "Ch"), channel));

    octave.addItemList ({ "OCT -2", "OCT -1", "OCT 0", "OCT +1", "OCT +2" }, 1);
    octave.setTooltip ("Move the track up or down an octave");
    addAndMakeVisible (octave);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::track (track, "Oct"), octave));

    dyn.addItemList ({ "DYN OFF", "CC1", "CC11", "CC1+11" }, 1);
    dyn.setTooltip ("Dynamics for the hand-written lines: sends swells and phrasing as CC. "
                    "Orchestral string libraries (Kontakt, Spitfire...) want CC1. Synths like Omnisphere: CC11 (expression)");
    addAndMakeVisible (dyn);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::track (track, "Dyn"), dyn));

    auto knob = [this] (juce::Slider& s, const juce::String& tip)
    {
        s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        s.setTooltip (tip);
        addAndMakeVisible (s);
    };
    knob (density, "BUSY: how many notes. Low = sparse and laid back, high = busy");
    knob (complexity, "COMPLEX: how adventurous. Low = simple and safe, high = runs, leaps, fills, chromatic notes");
    knob (level, "LEVEL: how hard this track plays (velocity)");
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::track (track, "Dens"), density));
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::track (track, "Cplx"), complexity));
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::track (track, "Lvl"), level));

    static const char* modeNames[numBandModes] = { "JAM", "HOLD", "RING" };
    static const char* modeTips[numBandModes] = {
        "JAM: plays its style along with your chords",
        "HOLD: plays exactly what you press, in this track's octave, for as long as you hold the key. No rhythm. "
        "Bass takes the bottom note, melody the top note, everything else the whole chord",
        "RING: one hit when you press a key, ringing until you press the next key (even after you let go). Stops when FL stops" };
    for (int m = 0; m < numBandModes; ++m)
    {
        modeBtns[m].setButtonText (modeNames[m]);
        modeBtns[m].setTooltip (modeTips[m]);
        modeBtns[m].setClickingTogglesState (false);
        modeBtns[m].onClick = [this, m] { ctx.proc().setTrackValue (track, TpMode, (float) m); sync(); };
        addAndMakeVisible (modeBtns[m]);
    }

    drag.setTooltip ("Record (AUTO REC or REC), then drag just this track onto its own instrument's channel");
    addAndMakeVisible (drag);

    keys.setTooltip ("KEY STRIP: the keys on your controller (any octave). Lit keys play. Click a key and this track sits out "
                     "whenever you press it (drag across to do several). In SCALE mode the numbers are the chords: "
                     "1 = the I chord on C, 2 = ii on D ... 7 on B");
    addAndMakeVisible (keys);

    remove.setTooltip ("Remove this track (the tracks below move up)");
    remove.onClick = [this] { ctx.proc().removeTrack (track); };   // the panel rebuilds the strips on its next tick
    addAndMakeVisible (remove);

    lastSeed = p.bandSeed[(size_t) track].load();
    sync();
}

void BandPanel::Strip::showTypeMenu()
{
    juce::PopupMenu m;
    m.addSectionHeader ("TRACK " + juce::String (track + 1) + " IS...");
    for (int ty = 0; ty < BKick; ++ty) m.addItem (ty + 1, bandTypeName (ty), true, ty == type);
    m.addSectionHeader ("ONE PIECE OF THE KIT (plays the GROOVE, on channel 10)");
    for (int ty = BKick; ty < numBandTypes; ++ty) m.addItem (ty + 1, bandTypeName (ty), true, ty == type);
    juce::Component::SafePointer<Strip> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&typeBtn), [safe] (int r)
    {
        if (r <= 0 || safe == nullptr) return;
        safe->ctx.proc().setTrackType (safe->track, r - 1);   // the panel rebuilds the strips on its next tick
    });
}

void BandPanel::Strip::sync()
{
    auto& p = ctx.proc();
    const int st = juce::jlimit (0, bandNumStyles (type) - 1, (int) std::lround (p.trackValue (track, TpStyle)));
    if (st != lastStyle && ! style.isPopupActive())
    {
        lastStyle = st;
        style.setSelectedItemIndex (st, juce::dontSendNotification);
        style.setTooltip (bandStyleBlurb (type, st));
    }
    const bool canHold = bandTypeCanHold (type);
    const int mode = canHold ? juce::jlimit (0, numBandModes - 1, (int) std::lround (p.trackValue (track, TpMode))) : (int) ModeJam;
    const bool isOn = on.getToggleState();
    if (mode != lastMode || isOn != lastOn)
    {
        lastMode = mode;
        lastOn = isOn;
        for (int m = 0; m < numBandModes; ++m)
        {
            modeBtns[m].setToggleState (m == mode, juce::dontSendNotification);
            modeBtns[m].setEnabled (m == ModeJam || canHold);
        }
        const bool jam = mode == ModeJam;
        style.setEnabled (jam);
        dice.setEnabled (jam);
        density.setEnabled (jam);
        complexity.setEnabled (jam);
        dyn.setEnabled (jam);
        repaint();
    }
}

void BandPanel::Strip::resized()
{
    on.setBounds (20, 6, 86, 24);
    typeBtn.setBounds (108, 6, 20, 24);
    style.setBounds (132, 6, 132, 24);
    dice.setBounds (268, 6, 42, 24);
    channel.setBounds (314, 6, 60, 24);
    octave.setBounds (378, 6, 62, 24);
    drag.setBounds (444, 6, 46, 24);
    remove.setBounds (getWidth() - 26, 6, 20, 24);

    density.setBounds (6, 38, 28, 28);
    complexity.setBounds (66, 38, 28, 28);
    level.setBounds (126, 38, 28, 28);
    for (int m = 0; m < numBandModes; ++m) modeBtns[m].setBounds (180 + m * 42, 41, 40, 22);
    keys.setBounds (312, 40, 140, 25);
    dyn.setBounds (458, 41, getWidth() - 464, 22);
}

void BandPanel::Strip::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const auto r = getLocalBounds().toFloat();
    const bool isOn = on.getToggleState();
    g.setColour (isOn ? t.card : t.cardDark);
    g.fillRoundedRectangle (r, 7.0f);
    g.setColour (isOn ? t.panelEdge.brighter (0.2f) : t.panelEdge);
    g.drawRoundedRectangle (r.reduced (0.5f), 7.0f, 1.0f);

    // activity light + track number
    const juce::Rectangle<float> dot (6.0f, 13.0f, 9.0f, 9.0f);
    g.setColour (t.cardDark.interpolatedWith (t.home, isOn ? 0.25f + 0.75f * glow : 0.0f));
    g.fillEllipse (dot);
    g.setColour (t.panelEdge);
    g.drawEllipse (dot, 1.0f);
    g.setFont (uiFont (9.0f, true));
    g.setColour (t.dim);
    g.drawText (juce::String (track + 1), juce::Rectangle<float> (1.0f, 24.0f, 19.0f, 10.0f), juce::Justification::centred);

    const bool jam = lastMode == ModeJam;
    g.setFont (uiFont (9.0f, true));
    g.setColour (jam ? t.dim : t.faint);
    g.drawText ("BUSY", juce::Rectangle<float> (35.0f, 45.0f, 30.0f, 14.0f), juce::Justification::centredLeft);
    g.drawText ("CPLX", juce::Rectangle<float> (95.0f, 45.0f, 30.0f, 14.0f), juce::Justification::centredLeft);
    g.setColour (t.dim);
    g.drawText ("LVL", juce::Rectangle<float> (155.0f, 45.0f, 24.0f, 14.0f), juce::Justification::centredLeft);
}

//==============================================================================
BandPanel::BandPanel (EditorContext& c)
    : ctx (c), chordKeys (c, c.proc().chordKeys), groovePrev (c, IconButton::Left), grooveNext (c, IconButton::Right)
{
    auto& p = ctx.proc();
    auto& apvts = p.apvts;
    using BA = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using CA = juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SA = juce::AudioProcessorValueTreeState::SliderAttachment;

    // ---- top row
    bandOnBtn.setClickingTogglesState (true);
    bandOnBtn.setTooltip ("Master switch for the band (every track)");
    addAndMakeVisible (bandOnBtn);
    buttonAtt.push_back (std::make_unique<BA> (apvts, ids::bandOn, bandOnBtn));

    for (int g = 0; g < numGenres; ++g) genreBox.addItem (genreName (g), g + 1);
    genreBox.setTextWhenNothingSelected ("PICK A GENRE");
    genreBox.setTooltip ("Sets every track to that genre's style. If no tracks are on yet, it also turns on the usual lineup");
    genreBox.onChange = [this]
    {
        const int g = genreBox.getSelectedId() - 1;
        if (g < 0) return;
        ctx.proc().applyBandGenre (g);
        lastGenre = g;
        repaint();
    };
    addAndMakeVisible (genreBox);

    phraseBox.addItemList ({ "1 bar", "2 bars", "4 bars", "8 bars" }, 1);
    phraseBox.setTooltip ("How long a phrase is before the tracks come back around (they repeat with small changes, like a real hook)");
    addAndMakeVisible (phraseBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::bandPhrase, phraseBox));

    swingKnob.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    swingKnob.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    swingKnob.setTooltip ("SWING for the whole band. Every pattern is straight; this is the only swing. "
                          "0% = straight, about 33% = a light bounce, about 67% = a triplet shuffle");
    swingKnob.onValueChange = [this] { repaint (282, 0, 84, 44); };
    addAndMakeVisible (swingKnob);
    sliderAtt.push_back (std::make_unique<SA> (apvts, ids::bandSwing, swingKnob));

    stopModeBox.addItemList ({ "When you let go", "At the end of the bar", "Never (until FL stops)" }, 1);
    stopModeBox.setTooltip ("When the band stops after you let go of the chord");
    addAndMakeVisible (stopModeBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::bandStop, stopModeBox));

    copyBtn.setTooltip ("For a copy of VESPER: make it play ONLY TRACK 3 (etc.) from your main VESPER, out of its own MIDI port. "
                        "(Patcher + VFX Color Mapper is usually easier)");
    copyBtn.onClick = [this] { showCopyMenu(); };
    addAndMakeVisible (copyBtn);

    grooveBox.setTooltip ("GROOVE: 50 drum grooves for this genre, simplest first. Every drum track plays it (DRUMS on GROOVE, "
                          "KICK, SNARE, HATS...), so the kit always locks together");
    grooveBox.onChange = [this]
    {
        const int i = grooveBox.getSelectedItemIndex();
        if (i >= 0 && i != lastGroove) { lastGroove = i; ctx.proc().setBandGroove (i); }
    };
    addAndMakeVisible (grooveBox);
    groovePrev.setTooltip ("Previous groove");
    grooveNext.setTooltip ("Next groove");
    groovePrev.onClick = [this] { ctx.proc().setBandGroove (ctx.proc().bandGrooveNow() - 1); };
    grooveNext.onClick = [this] { ctx.proc().setBandGroove (ctx.proc().bandGrooveNow() + 1); };
    grooveDice.setTooltip ("A random groove for this genre");
    grooveDice.onClick = [this]
    {
        const int now = ctx.proc().bandGrooveNow();
        const int next = (now + 1 + juce::Random::getSystemRandom().nextInt (groovesPerGenre - 1)) % groovesPerGenre;
        ctx.proc().setBandGroove (next);
    };
    addAndMakeVisible (groovePrev);
    addAndMakeVisible (grooveNext);
    addAndMakeVisible (grooveDice);
    fillGrooves();

    for (int ch = 1; ch <= 16; ++ch) chordChBox.addItem ("CH " + juce::String (ch), ch);
    chordChBox.setTooltip ("MIDI channel for VESPER's chords");
    addAndMakeVisible (chordChBox);
    comboAtt.push_back (std::make_unique<CA> (apvts, ids::chordCh, chordChBox));

    chordKeys.setTooltip ("KEY STRIP for the chords: click a key and VESPER's own chords sit out whenever you press it "
                          "(the band still follows). In SCALE mode the numbers are the chords: 1 = I on C ... 7 on B");
    addAndMakeVisible (chordKeys);

    allHoldBtn.setTooltip ("ALL HOLD: every melodic track plays exactly what you press, all at once (no patterns). "
                           "Click again to go back to JAM. Drums keep playing their pattern");
    allHoldBtn.onClick = [this] { ctx.proc().setAllHold (! ctx.proc().allHold()); };
    addAndMakeVisible (allHoldBtn);

    addBtn.setTooltip ("Add a track (up to 15: with your chords that's all 16 MIDI channels)");
    addBtn.onClick = [this] { ctx.proc().addTrack(); };
    addAndMakeVisible (addBtn);

    diceAllBtn.setTooltip ("New lines for every track that's on (same styles, new ideas)");
    diceAllBtn.onClick = [this]
    {
        for (int t = 0; t < ctx.proc().numTracks.load(); ++t)
            if (ctx.proc().trackValue (t, TpOn) > 0.5f) ctx.proc().rollBandSeed (t);
    };
    addAndMakeVisible (diceAllBtn);

    stopBtn.setTooltip ("Stop the band now (and anything RING is holding)");
    stopBtn.onClick = [this] { ctx.proc().stopBandFromUi(); };
    addAndMakeVisible (stopBtn);

    // ---- tracks
    viewport.setViewedComponent (&list, false);
    viewport.setScrollBarsShown (true, false);
    viewport.setScrollBarThickness (8);
    addAndMakeVisible (viewport);
    rebuildStrips();

    lastGenre = (int) apvts.getRawParameterValue (ids::bandGenre)->load();
    lastAnyOn = anyPartOn();
    genreBox.setSelectedId (lastAnyOn ? lastGenre + 1 : 0, juce::dontSendNotification);
    startTimerHz (20);
}

BandPanel::~BandPanel() { stopTimer(); }

juce::Rectangle<int> BandPanel::stripBounds (int track)
{
    const int col = track % 2, row = track / 2;
    return { col * (colW + colGap), row * (stripH + stripGapY), colW, stripH };
}

void BandPanel::rebuildStrips()
{
    auto& p = ctx.proc();
    const int n = juce::jlimit (1, maxBandTracks, p.numTracks.load());
    const auto pos = viewport.getViewPosition();
    strips.clear();
    for (int t = 0; t < n; ++t)
    {
        strips.push_back (std::make_unique<Strip> (*this, t));
        list.addAndMakeVisible (*strips.back());
        strips.back()->setBounds (stripBounds (t));
    }
    const int rows = (n + 1) / 2;
    list.setSize (2 * colW + colGap, rows * (stripH + stripGapY) - stripGapY);
    viewport.setViewPosition (pos);
    lastTracks = n;
    lastChanged = p.tracksChanged.load();
    addBtn.setEnabled (n < maxBandTracks);
    chordKeys.repaint();
    repaint();
}

bool BandPanel::anyPartOn() const
{
    const auto& p = ctx.proc();
    for (int t = 0; t < p.numTracks.load(); ++t)
        if (p.trackValue (t, TpOn) > 0.5f) return true;
    return false;
}

void BandPanel::resized()
{
    bandOnBtn.setBounds (0, 14, 60, 24);
    genreBox.setBounds (66, 14, 126, 24);
    grooveBox.setBounds (198, 14, 136, 24);
    groovePrev.setBounds (336, 14, 18, 24);
    grooveNext.setBounds (356, 14, 18, 24);
    grooveDice.setBounds (378, 14, 40, 24);
    phraseBox.setBounds (424, 14, 60, 24);
    swingKnob.setBounds (488, 9, 32, 32);
    stopModeBox.setBounds (570, 14, 114, 24);
    chordChBox.setBounds (688, 14, 56, 24);
    chordKeys.setBounds (748, 13, 90, 26);
    allHoldBtn.setBounds (844, 14, 64, 24);
    addBtn.setBounds (914, 14, 58, 24);
    diceAllBtn.setBounds (978, 14, 56, 24);
    stopBtn.setBounds (1040, 14, 40, 24);
    copyBtn.setBounds (1084, 14, 40, 24);
    viewport.setBounds (0, listTop, getWidth(), getHeight() - listTop);
}

int BandPanel::role() const
{
    return juce::jlimit (0, (int) maxBandTracks, (int) ctx.proc().apvts.getRawParameterValue (ids::bandRole)->load());
}

void BandPanel::showCopyMenu()
{
    juce::PopupMenu m;
    m.addSectionHeader ("THIS VESPER PLAYS");
    const int r = role();
    m.addItem (1, "EVERYTHING (the main VESPER)", true, r == 0);
    for (int t = 0; t < maxBandTracks; ++t) m.addItem (t + 2, "ONLY TRACK " + juce::String (t + 1) + " (a copy)", true, r == t + 1);
    juce::Component::SafePointer<BandPanel> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&copyBtn), [safe] (int res)
    {
        if (res <= 0 || safe == nullptr) return;
        if (auto* prm = safe->ctx.proc().apvts.getParameter (ids::bandRole))
            prm->setValueNotifyingHost (prm->convertTo0to1 ((float) (res - 1)));
        safe->repaint();
    });
}

void BandPanel::fillGrooves()
{
    const int g = ctx.proc().bandGenreNow();
    grooveBox.clear (juce::dontSendNotification);
    for (int i = 0; i < groovesPerGenre; ++i) grooveBox.addItem (grooveLabel (g, i), i + 1);
    lastGrooveGenre = g;
    lastGroove = ctx.proc().bandGrooveNow();
    grooveBox.setSelectedItemIndex (lastGroove, juce::dontSendNotification);
}

void BandPanel::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    drawCaption (g, { 0.0f, 0.0f, 60.0f, 12.0f }, "BAND", t);
    drawCaption (g, { 66.0f, 0.0f, 126.0f, 12.0f }, "GENRE", t);
    drawCaption (g, { 198.0f, 0.0f, 220.0f, 12.0f }, "GROOVE (50 FOR THIS GENRE)", t);
    drawCaption (g, { 424.0f, 0.0f, 60.0f, 12.0f }, "PHRASE", t);
    drawCaption (g, { 520.0f, 0.0f, 44.0f, 12.0f }, "SWING", t);
    g.setFont (uiFont (11.0f, true));
    g.setColour (t.text);
    g.drawText (juce::String (juce::roundToInt (swingKnob.getValue())) + "%", juce::Rectangle<float> (522.0f, 18.0f, 44.0f, 14.0f), juce::Justification::centredLeft);
    drawCaption (g, { 570.0f, 0.0f, 114.0f, 12.0f }, "STOPS", t);
    drawCaption (g, { 688.0f, 0.0f, 150.0f, 12.0f }, "CHORDS: CHANNEL + KEYS", t);
    drawCaption (g, { 914.0f, 0.0f, 58.0f, 12.0f }, juce::String (p.numTracks.load()) + " / " + juce::String (maxBandTracks), t);

    // playing light, on the line under the controls
    const bool playing = p.bandPlaying.load();
    const juce::Rectangle<float> led (1040.0f, 39.5f, 8.0f, 8.0f);
    g.setColour (playing ? t.home : t.cardDark);
    g.fillEllipse (led);
    g.setColour (t.panelEdge);
    g.drawEllipse (led, 1.0f);
    g.setFont (uiFont (9.5f, true));
    const bool anyOn = anyPartOn();
    g.setColour (playing ? t.text : (anyOn ? t.dim : t.color));
    g.drawText (playing ? "PLAYING" : (anyOn ? "PLAY A CHORD" : "ALL OFF"), juce::Rectangle<float> (1052.0f, 38.0f, 72.0f, 11.0f),
                juce::Justification::centredLeft);

    if (! anyOn && role() == 0)
    {
        g.setFont (uiFont (10.5f, true));
        g.setColour (t.color);
        g.drawText ("Every track is off: pick a GENRE, or click a track's name (MELODY, BASS, DRUMS...) to turn it on",
                    juce::Rectangle<float> (0.0f, 38.0f, (float) getWidth(), 10.0f), juce::Justification::centredLeft);
    }

    // a band copy: explain what it's doing
    const int rl = role();
    if (rl > 0)
    {
        const int f = p.followState.load();
        const juce::String tr = "TRACK " + juce::String (rl);
        juce::String text;
        if (f == 2)
            text = "This VESPER is set to play ONLY " + tr + ", but there's no main VESPER playing yet.\n"
                   "Add a VESPER set to EVERYTHING (your main one), turn " + tr + " on there, and play chords on it.";
        else
            text = "BAND COPY: playing only " + tr + " from your main VESPER, in sync.\n"
                   "Change the band (styles, DICE, channels) on the main VESPER. The main VESPER leaves " + tr + " out.\n"
                   "Give this one its own MIDI output port (FL gear icon > MIDI > Output port) and set that instrument's "
                   "input port to the same number. (HOLD and RING tracks are always played by the main VESPER.)";
        g.setFont (uiFont (13.0f, true));
        g.setColour (t.text);
        g.drawFittedText (text, juce::Rectangle<int> (30, listTop + 10, getWidth() - 60, getHeight() - listTop - 20), juce::Justification::centred, 5);
    }
}

void BandPanel::timerCallback()
{
    auto& p = ctx.proc();
    if (p.numTracks.load() != lastTracks || p.tracksChanged.load() != lastChanged)
        rebuildStrips();

    const int rl = role();
    viewport.setVisible (rl <= 0);
    if (rl != lastRole)
    {
        lastRole = rl;
        copyBtn.setToggleState (rl > 0, juce::dontSendNotification);
        repaint();
    }
    if (p.bandGenreNow() != lastGrooveGenre) fillGrooves();
    else if (p.bandGrooveNow() != lastGroove && ! grooveBox.isPopupActive())
    {
        lastGroove = p.bandGrooveNow();
        grooveBox.setSelectedItemIndex (lastGroove, juce::dontSendNotification);
    }
    for (auto& sp : strips)
    {
        auto& s = *sp;
        bool dirty = false;
        const auto hits = p.partHits[(size_t) s.track].load();
        if (hits != s.lastHits) { s.lastHits = hits; s.glow = 1.0f; dirty = true; }
        else if (s.glow > 0.0f) { s.glow = juce::jmax (0.0f, s.glow - 0.2f); dirty = true; }
        s.sync();
        if (dirty) s.repaint (0, 0, 22, 36);
    }
    allHoldBtn.setToggleState (p.allHold(), juce::dontSendNotification);

    const int genre = (int) p.apvts.getRawParameterValue (ids::bandGenre)->load();
    const bool anyOn = anyPartOn();
    bool dirty = false;
    if (genre != lastGenre || anyOn != lastAnyOn)
    {
        lastGenre = genre;
        lastAnyOn = anyOn;
        // nothing on yet: show PICK A GENRE, so choosing any genre (even the first one) starts the band
        genreBox.setSelectedId (anyOn ? genre + 1 : 0, juce::dontSendNotification);
        dirty = true;
    }
    const bool playing = p.bandPlaying.load();
    const int follow = p.followState.load();
    if (playing != lastPlaying || follow != lastFollow) { lastPlaying = playing; lastFollow = follow; dirty = true; }
    if (dirty) repaint();
}

//==============================================================================
juce::File BandPanel::PartDrag::exportPart()
{
    auto& p = ctx.proc();
    const int ch = (int) p.trackValue (track, TpCh);
    return p.exportRecording (ch, juce::String (bandTypeShort (p.trackType (track))).toLowerCase());
}

void BandPanel::PartDrag::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const bool have = ctx.proc().recordedNotes() > 0;
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    g.setColour (have ? t.cardHi : t.cardDark);
    g.fillRoundedRectangle (r, 5.0f);
    juce::Path border, dashed;
    border.addRoundedRectangle (r, 5.0f);
    const float dashes[] = { 3.0f, 3.0f };
    juce::PathStrokeType (1.0f).createDashedStroke (dashed, border, dashes, 2);
    g.setColour (have ? t.home : t.faint);
    g.fillPath (dashed);
    g.setFont (uiFont (10.5f, have));
    g.setColour (have ? t.text : t.dim);
    g.drawText ("DRAG", getLocalBounds(), juce::Justification::centred);
}

void BandPanel::PartDrag::mouseDrag (const juce::MouseEvent& e)
{
    if (started || e.getDistanceFromDragStart() < 5 || ctx.proc().recordedNotes() == 0) return;
    started = true;
    const auto f = exportPart();
    if (f.existsAsFile())
        juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
}

void BandPanel::PartDrag::mouseUp (const juce::MouseEvent&)
{
    if (! started && ctx.proc().recordedNotes() > 0)
    {
        const auto f = exportPart();
        if (f.existsAsFile())
        {
            auto dir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER");
            dir.createDirectory();
            auto dest = dir.getNonexistentChildFile (f.getFileNameWithoutExtension(), ".mid");
            if (f.copyFileTo (dest)) dest.revealToUser();
        }
    }
    started = false;
}
