#include "Widgets.h"

using namespace vesper;

juce::String toJ (const std::string& s) { return juce::String::fromUTF8 (s.c_str()); }

static juce::Colour roleColour (Role r, const Theme& t)
{
    switch (r)
    {
        case Role::Home:  return t.home;
        case Role::Move:  return t.move;
        case Role::Pull:  return t.pull;
        case Role::Color: return t.color;
    }
    return t.move;
}

static bool isBlackKey (int note)
{
    const int pc = ((note % 12) + 12) % 12;
    return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10;
}

static void auditionBriefly (EditorContext& ctx, juce::Component* owner, int source, const Chord& c, int style, int variant)
{
    if (! c.valid()) return;
    ctx.play (source, c, style, variant);
    juce::Component::SafePointer<juce::Component> safe (owner);
    EditorContext* cp = &ctx;
    juce::Timer::callAfterDelay (650, [safe, cp, source]
    {
        if (safe != nullptr) cp->release (source);
    });
}

static bool leftEditor (const juce::Component& c, const juce::MouseEvent& e)
{
    auto* top = c.getTopLevelComponent();
    if (top == nullptr) return false;
    const auto pt = e.getEventRelativeTo (top).getPosition();
    return ! top->getLocalBounds().contains (pt);
}

//==============================================================================
// PALETTE
juce::Rectangle<float> PaletteGrid::cardRect (int i) const
{
    const float gap = 8.0f;
    const float w = ((float) getWidth() - gap * 11.0f) / 12.0f;
    const float h = ((float) getHeight() - gap) / 2.0f;
    const int row = i / 12, col = i % 12;
    return { (float) col * (w + gap), (float) row * (h + gap), w, h };
}

int PaletteGrid::cardAt (juce::Point<int> pt) const
{
    for (int i = 0; i < paletteSize; ++i)
        if (cardRect (i).contains (pt.toFloat())) return i;
    return -1;
}

void PaletteGrid::paint (juce::Graphics& g)
{
    auto& p = ctx.proc();
    const auto& t = ctx.theme();
    const bool flats = p.flats();

    for (int i = 0; i < paletteSize; ++i)
    {
        const auto r = cardRect (i);
        const auto& card = p.ui.palette[(size_t) i];
        const bool sel = p.ui.selectedCard == i;
        const bool lit = pressed == i || (p.ui.keysMode == 1 && p.isInputKeyDown (48 + i));

        const juce::Colour base = lit ? t.cardHi.brighter (0.15f) : t.card;
        g.setGradientFill (juce::ColourGradient (base.brighter (0.05f), r.getX(), r.getY(), base.darker (0.1f), r.getX(), r.getBottom(), false));
        g.fillRoundedRectangle (r, 7.0f);
        g.setColour (sel ? t.accent : t.panelEdge);
        g.drawRoundedRectangle (r.reduced (0.5f), 7.0f, sel ? 1.6f : 1.0f);
        if (dragging && dragOver == i && dragOver != pressed)
        {
            g.setColour (t.accent.withAlpha (0.85f));
            g.drawRoundedRectangle (r.reduced (2.0f), 6.0f, 2.0f);
        }

        auto inner = r.reduced (8.0f, 6.0f);
        auto top = inner.removeFromTop (12.0f);
        g.setFont (uiFont (9.5f, true));
        g.setColour (t.faint);
        g.drawText (juce::String (i + 1).paddedLeft ('0', 2), top, juce::Justification::centredLeft);
        if (p.ui.keysMode == 1)
            g.drawText (toJ (midiName (48 + i, flats)), top, juce::Justification::centredRight);

        if (! card.chord.valid())
        {
            g.setColour (t.faint);
            g.setFont (uiFont (24.0f));
            g.drawText ("+", r, juce::Justification::centred);
            continue;
        }

        g.setFont (uiFont (12.5f, true));
        g.setColour (t.text.withAlpha (0.9f));
        g.drawFittedText (toJ (chordName (card.chord, flats)), inner.removeFromTop (18.0f).toNearestInt(), juce::Justification::centred, 1, 0.7f);
        if (card.style >= 0)
        {
            g.setFont (uiFont (8.5f, true));
            g.setColour (t.dim);
            g.drawText (juce::String (styleName (card.style)).toUpperCase(), inner.removeFromTop (10.0f), juce::Justification::centred);
        }

        const Role role = chordRole (card.chord, p.ui.keyRoot, p.ui.scale);
        const auto rc = roleColour (role, t);
        auto bottom = inner.removeFromBottom (14.0f);
        g.setFont (uiFont (juce::jmin (26.0f, r.getHeight() * 0.24f)));
        g.setColour (t.text);
        g.drawFittedText (toJ (romanNumeral (card.chord, p.ui.keyRoot)), inner.toNearestInt(), juce::Justification::centred, 1, 0.6f);

        g.setFont (uiFont (9.0f, true).withExtraKerningFactor (0.1f));
        g.setColour (rc.withAlpha (0.9f));
        g.drawText (juce::String (roleWord (role)).toUpperCase(), bottom.removeFromTop (10.0f), juce::Justification::centred);
        g.fillRoundedRectangle (r.getX() + 12.0f, r.getBottom() - 8.0f, r.getWidth() - 24.0f, 3.0f, 1.5f);
    }
}

void PaletteGrid::mouseDown (const juce::MouseEvent& e)
{
    const int i = cardAt (e.getPosition());
    if (i < 0) return;
    auto& p = ctx.proc();

    if (e.mods.isPopupMenu())
    {
        ctx.selectCard (i);
        juce::PopupMenu m;
        m.addItem (1, "Clear this pad");
        m.addItem (2, "Copy to the next pad", i < paletteSize - 1);
        m.addItem (3, "Voicing back to Auto", p.ui.palette[(size_t) i].style >= 0 || p.ui.palette[(size_t) i].variant >= 0);
        m.addSeparator();
        m.addItem (4, "Tip: drag a pad outside VESPER to drop its MIDI into FL", false);
        juce::Component::SafePointer<PaletteGrid> safe (this);
        m.showMenuAsync (juce::PopupMenu::Options().withMousePosition(), [safe, i] (int r)
        {
            if (safe == nullptr || r == 0) return;
            auto& proc = safe->ctx.proc();
            auto pal = proc.ui.palette;
            if (r == 1) pal[(size_t) i] = Card();
            if (r == 2) pal[(size_t) (i + 1)] = pal[(size_t) i];
            if (r == 3) { pal[(size_t) i].style = -1; pal[(size_t) i].variant = -1; }
            proc.setPalette (pal);
            safe->ctx.paletteEdited();
        });
        return;
    }

    pressed = i;
    dragging = draggedOut = false;
    dragOver = -1;
    ctx.selectCard (i);
    const auto& card = p.ui.palette[(size_t) i];
    ctx.play (src::pad + i, card.chord, card.style, card.variant);
    repaint();
}

void PaletteGrid::mouseDrag (const juce::MouseEvent& e)
{
    if (pressed < 0 || draggedOut) return;
    if (e.getDistanceFromDragStart() > 6) dragging = true;
    if (! dragging) return;

    if (leftEditor (*this, e))
    {
        draggedOut = true;
        ctx.release (src::pad + pressed);
        const auto card = ctx.proc().ui.palette[(size_t) pressed];
        ctx.dragChordOut (card.chord, card.style, card.variant);
        return;
    }
    const int over = cardAt (e.getPosition());
    if (over != dragOver) { dragOver = over; repaint(); }
}

void PaletteGrid::mouseUp (const juce::MouseEvent&)
{
    if (pressed < 0) return;
    ctx.release (src::pad + pressed);
    if (dragging && ! draggedOut && dragOver >= 0 && dragOver != pressed)
    {
        auto& p = ctx.proc();
        auto pal = p.ui.palette;
        std::swap (pal[(size_t) pressed], pal[(size_t) dragOver]);
        p.setPalette (pal);
        const int to = dragOver;
        pressed = -1;
        ctx.paletteEdited();
        ctx.selectCard (to);
    }
    pressed = -1;
    dragging = false;
    dragOver = -1;
    repaint();
}

//==============================================================================
// SCALE
juce::Rectangle<float> ScaleGrid::cellRect (int row, int col) const
{
    const float rowH = ((float) getHeight() - (float) headerH) / (float) numRows;
    const float colW = ((float) getWidth() - (float) labelW) / 12.0f;
    const int display = numRows - 1 - row;
    return juce::Rectangle<float> ((float) labelW + (float) col * colW, (float) headerH + (float) display * rowH, colW, rowH).reduced (1.5f);
}

int ScaleGrid::noteAt (juce::Point<int> pt) const
{
    if (pt.x < labelW || pt.y < headerH) return -1;
    const float rowH = ((float) getHeight() - (float) headerH) / (float) numRows;
    const float colW = ((float) getWidth() - (float) labelW) / 12.0f;
    const int col = juce::jlimit (0, 11, (int) (((float) pt.x - (float) labelW) / colW));
    const int display = juce::jlimit (0, numRows - 1, (int) (((float) pt.y - (float) headerH) / rowH));
    const int note = (numRows - 1 - display) * 12 + col;
    return note <= 127 ? note : -1;
}

int ScaleGrid::overflowRowAt (juce::Point<int> pt) const
{
    if (pt.x >= labelW || pt.x < labelW - 34 || pt.y < headerH) return -1;
    const float rowH = ((float) getHeight() - (float) headerH) / (float) numRows;
    const int display = juce::jlimit (0, numRows - 1, (int) (((float) pt.y - (float) headerH) / rowH));
    const int row = numRows - 1 - display;
    return ctx.proc().scaleMap.overflow[(size_t) row].empty() ? -1 : row;
}

void ScaleGrid::paint (juce::Graphics& g)
{
    auto& p = ctx.proc();
    const auto& t = ctx.theme();
    const bool flats = p.flats();
    const auto& map = p.scaleMap;

    // header: the scale degree of each white key, "+" for black keys
    const float colW = ((float) getWidth() - (float) labelW) / 12.0f;
    g.setFont (uiFont (9.5f, true).withExtraKerningFactor (0.08f));
    for (int col = 0; col < 12; ++col)
    {
        const auto r = juce::Rectangle<float> ((float) labelW + (float) col * colW, 0.0f, colW, (float) headerH - 2.0f);
        juce::String label = "+";
        if (! isBlackKey (col))
        {
            const auto& slot = map.keys[(size_t) (48 + col)];
            label = slot.chord.valid() ? toJ (romanNumeral (slot.chord, p.ui.keyRoot)) : juce::String ("-");
        }
        g.setColour (isBlackKey (col) ? t.faint : t.dim);
        g.drawText (label, r, juce::Justification::centred);
    }

    const float rowH = ((float) getHeight() - (float) headerH) / (float) numRows;
    for (int row = 0; row < numRows; ++row)
    {
        const int display = numRows - 1 - row;
        auto lr = juce::Rectangle<float> (0.0f, (float) headerH + (float) display * rowH, (float) labelW - 6.0f, rowH);
        g.setFont (uiFont (10.5f, true).withExtraKerningFactor (0.06f));
        g.setColour (t.text.withAlpha (0.85f));
        g.drawText (rowName (row), lr.withTrimmedLeft (2.0f), juce::Justification::centredLeft);
        g.setFont (uiFont (9.0f));
        g.setColour (t.faint);
        g.drawText (toJ (midiName (rowBaseNote (row), flats)), lr.withTrimmedLeft (50.0f).withTrimmedRight (30.0f), juce::Justification::centredLeft);
        const int extra = (int) map.overflow[(size_t) row].size();
        if (extra > 0)
        {
            auto chip = juce::Rectangle<float> ((float) labelW - 34.0f, lr.getY() + 3.0f, 28.0f, rowH - 6.0f);
            g.setColour (t.cardHi);
            g.fillRoundedRectangle (chip, 4.0f);
            g.setColour (t.text);
            g.drawText ("+" + juce::String (extra), chip, juce::Justification::centred);
        }

        for (int col = 0; col < 12; ++col)
        {
            const int note = row * 12 + col;
            if (note > 127) break;
            const auto r = cellRect (row, col);
            const auto& slot = map.keys[(size_t) note];
            const bool black = isBlackKey (note);
            const bool lit = pressedNote == note || (p.ui.keysMode == 0 && p.isInputKeyDown (note));

            juce::Colour fill = black ? t.cardDark : t.card;
            if (lit) fill = t.cardHi.brighter (0.2f);
            g.setColour (fill);
            g.fillRoundedRectangle (r, 4.0f);
            if (lit)
            {
                g.setColour (t.accent);
                g.drawRoundedRectangle (r, 4.0f, 1.3f);
            }
            if (! slot.chord.valid())
            {
                g.setColour (t.faint.withAlpha (0.5f));
                g.drawText ("-", r, juce::Justification::centred);
                continue;
            }
            if (slot.outside)
            {
                g.setColour (t.color.withAlpha (0.85f));
                g.fillRoundedRectangle (r.getX() + 2.0f, r.getY() + 3.0f, 2.5f, r.getHeight() - 6.0f, 1.0f);
            }
            g.setFont (uiFont (11.0f, true));
            g.setColour (slot.outside ? t.color.brighter (0.2f) : t.text);
            g.drawFittedText (toJ (chordName (slot.chord, flats)), r.reduced (5.0f, 0.0f).toNearestInt(), juce::Justification::centred, 1, 0.6f);
        }
    }
}

void ScaleGrid::mouseDown (const juce::MouseEvent& e)
{
    auto& p = ctx.proc();
    const int ofRow = overflowRowAt (e.getPosition());
    if (ofRow >= 0)
    {
        juce::PopupMenu m;
        const auto& list = p.scaleMap.overflow[(size_t) ofRow];
        m.addSectionHeader ("More in-key chords (click to hear)");
        for (size_t i = 0; i < list.size(); ++i)
            m.addItem ((int) i + 1, toJ (chordName (list[i], p.flats())));
        juce::Component::SafePointer<ScaleGrid> safe (this);
        m.showMenuAsync (juce::PopupMenu::Options().withMousePosition(), [safe, ofRow] (int r)
        {
            if (safe == nullptr || r <= 0) return;
            const auto& lst = safe->ctx.proc().scaleMap.overflow[(size_t) ofRow];
            if (r - 1 >= (int) lst.size()) return;
            Focus f;
            f.chord = lst[(size_t) (r - 1)];
            f.origin = 1;
            safe->ctx.setFocus (f);
            auditionBriefly (safe->ctx, safe.getComponent(), src::scale + 200, f.chord, -1, -1);
        });
        return;
    }

    const int note = noteAt (e.getPosition());
    if (note < 0) return;
    const auto chord = p.scaleMap.keys[(size_t) note].chord;
    if (! chord.valid()) return;

    Focus f;
    f.chord = chord;
    f.origin = 1;
    f.key = note;

    if (e.mods.isPopupMenu())
    {
        ctx.setFocus (f);
        juce::PopupMenu m;
        m.addItem (1, "Send to pad " + juce::String (p.ui.selectedCard + 1).paddedLeft ('0', 2));
        m.addItem (2, "Tip: drag a chord outside VESPER to drop its MIDI into FL", false);
        juce::Component::SafePointer<ScaleGrid> safe (this);
        m.showMenuAsync (juce::PopupMenu::Options().withMousePosition(), [safe, chord] (int r)
        {
            if (safe != nullptr && r == 1) safe->ctx.sendToSelectedCard (chord, -1, -1);
        });
        return;
    }

    pressedNote = note;
    draggedOut = false;
    ctx.setFocus (f);
    ctx.play (src::scale + note, chord, -1, -1);
    repaint();
}

void ScaleGrid::mouseDrag (const juce::MouseEvent& e)
{
    if (pressedNote < 0 || draggedOut || e.getDistanceFromDragStart() < 6) return;
    if (leftEditor (*this, e))
    {
        draggedOut = true;
        ctx.release (src::scale + pressedNote);
        ctx.dragChordOut (ctx.proc().scaleMap.keys[(size_t) pressedNote].chord, -1, -1);
    }
}

void ScaleGrid::mouseUp (const juce::MouseEvent&)
{
    if (pressedNote >= 0) ctx.release (src::scale + pressedNote);
    pressedNote = -1;
    repaint();
}

//==============================================================================
// LIBRARY
struct LibraryView::TypeList : public juce::Component
{
    explicit TypeList (LibraryView& o) : owner (o) {}
    static constexpr int rowH = 22;
    struct Row { bool header; int value; };
    std::vector<Row> rows;

    void build()
    {
        rows.clear();
        const auto& groups = qualityGroups();
        for (int gi = 0; gi < (int) groups.size(); ++gi)
        {
            rows.push_back ({ true, gi });
            for (int q = 0; q < numQualities(); ++q)
                if (qualities()[(size_t) q].group == groups[(size_t) gi]) rows.push_back ({ false, q });
        }
        setSize (juce::jmax (10, getWidth()), (int) rows.size() * rowH);
        repaint();
    }

    void paint (juce::Graphics& g) override
    {
        const auto& t = owner.ctx.theme();
        const bool flats = owner.ctx.proc().flats();
        for (size_t i = 0; i < rows.size(); ++i)
        {
            auto r = juce::Rectangle<float> (0.0f, (float) i * rowH, (float) getWidth(), (float) rowH);
            if (rows[i].header)
            {
                drawCaption (g, r.withTrimmedLeft (6.0f).withTrimmedTop (6.0f), toJ (qualityGroups()[(size_t) rows[i].value]).toUpperCase(), t);
                continue;
            }
            const int q = rows[i].value;
            if (q == owner.quality)
            {
                g.setColour (t.accent);
                g.fillRoundedRectangle (r.reduced (2.0f, 1.0f), 4.0f);
            }
            Chord c;
            c.root = owner.root;
            c.quality = q;
            c.bass = owner.bass;
            g.setFont (uiFont (12.0f, true));
            g.setColour (q == owner.quality ? t.accentText : t.text);
            g.drawText (toJ (chordName (c, flats)), r.withTrimmedLeft (8.0f).withWidth (r.getWidth() * 0.42f), juce::Justification::centredLeft, true);
            g.setFont (uiFont (11.0f));
            g.setColour (q == owner.quality ? t.accentText.withAlpha (0.75f) : t.dim);
            g.drawText (toJ (qualities()[(size_t) q].name), r.withTrimmedLeft (r.getWidth() * 0.44f).withTrimmedRight (6.0f), juce::Justification::centredLeft, true);
        }
    }

    void mouseDown (const juce::MouseEvent& e) override
    {
        const int i = e.y / rowH;
        if (i < 0 || i >= (int) rows.size() || rows[(size_t) i].header) return;
        owner.quality = rows[(size_t) i].value;
        owner.style = -1;
        owner.variant = -1;
        owner.rebuild();
        const auto c = owner.current();
        Focus f;
        f.chord = c;
        f.origin = 2;
        owner.ctx.setFocus (f);
        owner.ctx.play (src::library, c, -1, -1);
    }

    void mouseUp (const juce::MouseEvent&) override { owner.ctx.release (src::library); }

    LibraryView& owner;
};

struct LibraryView::VoicingList : public juce::Component
{
    explicit VoicingList (LibraryView& o) : owner (o) {}
    static constexpr int rowH = 22;
    struct Row { bool header; int style; int variant; juce::String text, notes; };
    std::vector<Row> rows;

    void build()
    {
        rows.clear();
        const auto c = owner.current();
        const bool flats = owner.ctx.proc().flats();
        const int center = (int) owner.ctx.proc().apvts.getRawParameterValue (ids::height)->load();
        if (c.valid())
            for (int s = 0; s < numStyles; ++s)
            {
                rows.push_back ({ true, s, -1, juce::String (styleName (s)), juce::String (styleBlurb (s)) });
                const int nv = numVariants (c, s);
                for (int v = 0; v < nv; ++v)
                {
                    const Notes n = fitToCenter (buildVoicing (c, s, v), center);
                    juce::String ns;
                    for (int k = 0; k < n.size(); ++k) ns << toJ (noteName (n[k], flats)) << " ";
                    rows.push_back ({ false, s, v, toJ (variantName (c, s, v, flats)), ns.trim() });
                }
            }
        setSize (juce::jmax (10, getWidth()), (int) rows.size() * rowH);
        repaint();
    }

    void paint (juce::Graphics& g) override
    {
        const auto& t = owner.ctx.theme();
        for (size_t i = 0; i < rows.size(); ++i)
        {
            const auto& row = rows[i];
            auto r = juce::Rectangle<float> (0.0f, (float) i * rowH, (float) getWidth(), (float) rowH);
            if (row.header)
            {
                g.setFont (uiFont (11.0f, true).withExtraKerningFactor (0.05f));
                g.setColour (t.text);
                g.drawText (row.text.toUpperCase(), r.withTrimmedLeft (6.0f).withTrimmedTop (4.0f), juce::Justification::centredLeft);
                g.setFont (uiFont (10.0f));
                g.setColour (t.faint);
                g.drawText (row.notes, r.withTrimmedLeft (120.0f).withTrimmedTop (4.0f).withTrimmedRight (4.0f), juce::Justification::centredLeft, true);
                continue;
            }
            const bool sel = row.style == owner.style && row.variant == owner.variant;
            if (sel)
            {
                g.setColour (t.accent);
                g.fillRoundedRectangle (r.reduced (2.0f, 1.0f), 4.0f);
            }
            g.setFont (uiFont (11.0f));
            g.setColour (sel ? t.accentText : t.dim);
            g.drawText (row.text, r.withTrimmedLeft (16.0f).withWidth (r.getWidth() * 0.55f), juce::Justification::centredLeft, true);
            g.setFont (uiFont (10.5f, true));
            g.setColour (sel ? t.accentText : t.text.withAlpha (0.8f));
            g.drawText (row.notes, r.withTrimmedLeft (r.getWidth() * 0.57f).withTrimmedRight (6.0f), juce::Justification::centredRight, true);
        }
    }

    void mouseDown (const juce::MouseEvent& e) override
    {
        const int i = e.y / rowH;
        if (i < 0 || i >= (int) rows.size() || rows[(size_t) i].header) return;
        owner.style = rows[(size_t) i].style;
        owner.variant = rows[(size_t) i].variant;
        repaint();
        Focus f;
        f.chord = owner.current();
        f.style = owner.style;
        f.variant = owner.variant;
        f.origin = 2;
        owner.ctx.setFocus (f);
        owner.ctx.play (src::library, f.chord, owner.style, owner.variant);
    }

    void mouseUp (const juce::MouseEvent&) override { owner.ctx.release (src::library); }

    LibraryView& owner;
};

struct LibraryView::TriadGrid : public juce::Component
{
    explicit TriadGrid (LibraryView& o) : owner (o) {}
    static constexpr int rowH = 22, headerH = 18, labelW = 132, firstOct = 1, lastOct = 8;
    std::vector<TriadInfo> triads;
    int pressedRow = -1, pressedOct = -1;

    void build()
    {
        triads = triadsIn (owner.current(), owner.ctx.proc().flats());
        setSize (juce::jmax (10, getWidth()), headerH + (int) triads.size() * 3 * rowH);
        repaint();
    }

    float cellW() const { return ((float) getWidth() - (float) labelW) / (float) (lastOct - firstOct + 1); }

    static juce::String invName (const TriadInfo& t, int inv)
    {
        if (inv == 0) return "root on bottom";
        if (inv == 1) return t.type == 4 ? "2nd on bottom" : t.type == 5 ? "4th on bottom" : "3rd on bottom";
        return "5th on bottom";
    }

    void paint (juce::Graphics& g) override
    {
        const auto& t = owner.ctx.theme();
        const bool flats = owner.ctx.proc().flats();
        g.setFont (uiFont (9.0f, true));
        g.setColour (t.faint);
        g.drawText ("OCTAVE", juce::Rectangle<float> (4.0f, 0.0f, (float) labelW, (float) headerH), juce::Justification::centredLeft);
        for (int o = firstOct; o <= lastOct; ++o)
            g.drawText (juce::String (o), juce::Rectangle<float> ((float) labelW + (float) (o - firstOct) * cellW(), 0.0f, cellW(), (float) headerH), juce::Justification::centred);

        for (size_t ti = 0; ti < triads.size(); ++ti)
            for (int inv = 0; inv < 3; ++inv)
            {
                const int row = (int) ti * 3 + inv;
                const float y = (float) headerH + (float) row * rowH;
                if (inv == 0 && ti > 0)
                {
                    g.setColour (t.panelEdge);
                    g.drawHorizontalLine ((int) y, 0.0f, (float) getWidth());
                }
                g.setFont (uiFont (11.0f, inv == 0));
                g.setColour (inv == 0 ? t.text : t.dim);
                const juce::String label = (inv == 0 ? toJ (triads[ti].name) + "  " : juce::String ("    ")) + invName (triads[ti], inv);
                g.drawText (label, juce::Rectangle<float> (4.0f, y, (float) labelW - 6.0f, (float) rowH), juce::Justification::centredLeft, true);
                for (int o = firstOct; o <= lastOct; ++o)
                {
                    const Notes n = triadNotes (triads[ti], inv, o);
                    if (n.highest() > 127) continue;
                    auto r = juce::Rectangle<float> ((float) labelW + (float) (o - firstOct) * cellW(), y, cellW(), (float) rowH).reduced (1.5f);
                    const bool lit = pressedRow == row && pressedOct == o;
                    g.setColour (lit ? t.accent : t.card);
                    g.fillRoundedRectangle (r, 3.0f);
                    g.setFont (uiFont (10.0f, true));
                    g.setColour (lit ? t.accentText : t.text.withAlpha (0.85f));
                    g.drawText (toJ (midiName (n[0], flats)), r, juce::Justification::centred);
                }
            }
    }

    void mouseDown (const juce::MouseEvent& e) override
    {
        if (e.x < labelW || e.y < headerH) return;
        const int row = (e.y - headerH) / rowH;
        const int o = firstOct + juce::jlimit (0, lastOct - firstOct, (int) ((float) (e.x - labelW) / cellW()));
        const int ti = row / 3, inv = row % 3;
        if (ti < 0 || ti >= (int) triads.size()) return;
        const Notes n = triadNotes (triads[(size_t) ti], inv, o);
        if (n.highest() > 127) return;
        static const char* suffix[] = { "", "m", "dim", "aug", "sus2", "sus4" };
        const Chord label = makeChord (triads[(size_t) ti].root, suffix[triads[(size_t) ti].type]);
        pressedRow = row;
        pressedOct = o;
        repaint();
        owner.ctx.playNotes (src::libraryTriad, n, label);
    }

    void mouseUp (const juce::MouseEvent&) override
    {
        owner.ctx.release (src::libraryTriad);
        pressedRow = pressedOct = -1;
        repaint();
    }

    LibraryView& owner;
};

LibraryView::LibraryView (EditorContext& c) : ctx (c)
{
    for (int i = 0; i < 12; ++i)
    {
        auto* b = rootButtons.add (new juce::TextButton());
        b->setClickingTogglesState (false);
        b->onClick = [this, i] { chooseRoot (i); };
        addAndMakeVisible (b);
    }
    bassBox.onChange = [this]
    {
        const int id = bassBox.getSelectedId();
        bass = id >= 2 ? id - 2 : -1;
        if (bass == root) bass = -1;
        rebuild();
        Focus f;
        f.chord = current();
        f.origin = 2;
        ctx.setFocus (f);
        auditionBriefly (ctx, this, src::library, f.chord, -1, -1);
    };
    addAndMakeVisible (bassBox);
    toPad.onClick = [this] { ctx.sendToSelectedCard (current(), style, variant); };
    addAndMakeVisible (toPad);

    typeList = std::make_unique<TypeList> (*this);
    voicingList = std::make_unique<VoicingList> (*this);
    triadGrid = std::make_unique<TriadGrid> (*this);
    for (auto* v : { &typeView, &voicingView, &triadView })
    {
        v->setScrollBarsShown (true, false);
        v->setScrollBarThickness (8);
        addAndMakeVisible (*v);
    }
    typeView.setViewedComponent (typeList.get(), false);
    voicingView.setViewedComponent (voicingList.get(), false);
    triadView.setViewedComponent (triadGrid.get(), false);
}

LibraryView::~LibraryView()
{
    typeView.setViewedComponent (nullptr, false);
    voicingView.setViewedComponent (nullptr, false);
    triadView.setViewedComponent (nullptr, false);
}

Chord LibraryView::current() const
{
    Chord c;
    c.root = root;
    c.quality = quality;
    c.bass = (bass >= 0 && bass != root) ? bass : -1;
    return c;
}

void LibraryView::chooseRoot (int r)
{
    root = r;
    if (bass == root) bass = -1;
    rebuild();
    Focus f;
    f.chord = current();
    f.style = style;
    f.variant = variant;
    f.origin = 2;
    ctx.setFocus (f);
    auditionBriefly (ctx, this, src::library, f.chord, style, variant);
}

void LibraryView::syncFromFocus()
{
    const auto& f = ctx.focus();
    if (f.chord.valid())
    {
        root = f.chord.root;
        quality = f.chord.quality;
        bass = f.chord.bass;
        style = f.style;
        variant = f.variant;
    }
    rebuild();
}

void LibraryView::rebuild()
{
    const bool flats = ctx.proc().flats();
    for (int i = 0; i < 12; ++i)
    {
        rootButtons[i]->setButtonText (toJ (noteName (i, flats)));
        rootButtons[i]->setToggleState (i == root, juce::dontSendNotification);
    }
    bassBox.clear (juce::dontSendNotification);
    bassBox.addItem ("No slash bass", 1);
    for (int i = 0; i < 12; ++i) bassBox.addItem ("over " + toJ (noteName (i, flats)), i + 2);
    bassBox.setSelectedId (bass >= 0 ? bass + 2 : 1, juce::dontSendNotification);
    toPad.setButtonText ("SEND TO PAD " + juce::String (ctx.proc().ui.selectedCard + 1).paddedLeft ('0', 2));

    typeList->build();
    voicingList->build();
    triadGrid->build();
    resized();
    repaint();
}

static std::array<juce::Rectangle<int>, 4> libraryColumns (int w, int h)
{
    std::array<juce::Rectangle<int>, 4> c;
    c[0] = { 0, 0, 196, h };
    c[1] = { 208, 0, 250, h };
    c[2] = { 470, 0, 300, h };
    c[3] = { 782, 0, w - 782, h };
    return c;
}

void LibraryView::resized()
{
    const auto cols = libraryColumns (getWidth(), getHeight());
    auto a = cols[0];
    const int bw = (a.getWidth() - 3 * 4) / 4;
    for (int i = 0; i < 12; ++i)
        rootButtons[i]->setBounds (a.getX() + (i % 4) * (bw + 4), 46 + (i / 4) * 30, bw, 26);
    bassBox.setBounds (a.getX(), 158, a.getWidth(), 26);
    toPad.setBounds (a.getX(), a.getBottom() - 32, a.getWidth(), 30);

    typeView.setBounds (cols[1].withTrimmedTop (18));
    voicingView.setBounds (cols[2].withTrimmedTop (18));
    triadView.setBounds (cols[3].withTrimmedTop (18));
    typeList->setSize (typeView.getMaximumVisibleWidth(), typeList->getHeight());
    voicingList->setSize (voicingView.getMaximumVisibleWidth(), voicingList->getHeight());
    triadGrid->setSize (triadView.getMaximumVisibleWidth(), triadGrid->getHeight());
}

void LibraryView::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    const auto cols = libraryColumns (getWidth(), getHeight());
    g.setFont (uiFont (20.0f, true));
    g.setColour (t.text);
    g.drawFittedText (toJ (chordName (current(), ctx.proc().flats())), cols[0].withHeight (26), juce::Justification::centredLeft, 1, 0.6f);
    drawCaption (g, cols[0].withY (30).withHeight (12).toFloat(), "ROOT", t);
    drawCaption (g, cols[0].withY (142).withHeight (12).toFloat(), "SLASH BASS", t);
    drawCaption (g, cols[1].withHeight (14).toFloat(), toJ ("CHORD TYPE  \xc2\xb7  ") + juce::String (numQualities()) + " TYPES", t);
    drawCaption (g, cols[2].withHeight (14).toFloat(), toJ ("VOICINGS  \xc2\xb7  EVERY STYLE + INVERSION"), t);
    drawCaption (g, cols[3].withHeight (14).toFloat(), toJ ("TRIADS INSIDE  \xc2\xb7  EVERY OCTAVE, EVERY STARTING NOTE"), t);
    g.setColour (t.panelEdge);
    for (int i = 1; i < 4; ++i)
        g.drawVerticalLine (cols[(size_t) i].getX() - 6, 0.0f, (float) getHeight());
}

//==============================================================================
// CURRENT CHORD
ChordPanel::ChordPanel (EditorContext& c) : ctx (c)
{
    for (auto* b : { &prev, &next, &toPad }) addAndMakeVisible (b);
    prev.onClick = [this] { ctx.selectCard ((ctx.proc().ui.selectedCard + paletteSize - 1) % paletteSize); };
    next.onClick = [this] { ctx.selectCard ((ctx.proc().ui.selectedCard + 1) % paletteSize); };
    toPad.onClick = [this] { const auto& f = ctx.focus(); ctx.sendToSelectedCard (f.chord, f.style, f.variant); };
    prev.setTooltip ("Previous pad");
    next.setTooltip ("Next pad");

    for (auto* b : { &rootBox, &typeBox, &bassBox, &styleBox, &shapeBox })
    {
        addAndMakeVisible (b);
        b->onChange = [this] { if (! refreshing) edited(); };
    }

    // chord types, grouped
    const auto& groups = qualityGroups();
    for (const auto& gname : groups)
    {
        typeBox.addSectionHeading (toJ (gname));
        for (int q = 0; q < numQualities(); ++q)
            if (qualities()[(size_t) q].group == gname)
            {
                const auto& Q = qualities()[(size_t) q];
                typeBox.addItem ((Q.suffix.empty() ? juce::String ("maj") : toJ (Q.suffix)) + toJ ("  \xc2\xb7  ") + toJ (Q.name), q + 1);
            }
    }
    styleBox.addItem ("Auto", 1);
    for (int s = 0; s < numStyles; ++s) styleBox.addItem (styleName (s), s + 2);
}

juce::Rectangle<int> ChordPanel::nameArea() const { return { 44, 26, getWidth() - 88, 42 }; }

void ChordPanel::resized()
{
    prev.setBounds (10, 30, 28, 34);
    next.setBounds (getWidth() - 38, 30, 28, 34);
    rootBox.setBounds (12, 102, 66, 24);
    typeBox.setBounds (84, 102, 176, 24);
    bassBox.setBounds (266, 102, getWidth() - 278, 24);
    styleBox.setBounds (12, 150, 140, 24);
    shapeBox.setBounds (158, 150, getWidth() - 158 - 76, 24);
    toPad.setBounds (getWidth() - 70, 150, 58, 24);
}

void ChordPanel::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    drawPanel (g, getLocalBounds().toFloat(), t, "CURRENT CHORD");
    const auto& f = ctx.focus();
    const bool flats = p.flats();

    juce::String where;
    if (f.origin == 0) where = "PAD " + juce::String (f.card + 1).paddedLeft ('0', 2) + "/24";
    else if (f.origin == 1) where = "SCALE";
    else if (f.origin == 2) where = "LIBRARY";
    else if (f.origin == 3) where = "SUGGESTED";
    else where = "PLAYED";
    drawCaption (g, { 14.0f, 8.0f, (float) getWidth() - 28.0f, 14.0f }, where, t, juce::Justification::centredRight);

    const auto na = nameArea();
    g.setFont (uiFont (25.0f, true));
    g.setColour (auditioning ? t.accent : t.text);
    g.drawFittedText (f.chord.valid() ? toJ (chordName (f.chord, flats)) : juce::String ("-"), na, juce::Justification::centred, 1, 0.6f);

    if (f.chord.valid())
    {
        const Role role = chordRole (f.chord, p.ui.keyRoot, p.ui.scale);
        juce::String info = toJ (romanNumeral (f.chord, p.ui.keyRoot)) + toJ ("   \xc2\xb7   ") + juce::String (roleWord (role));
        int key = f.key;
        if (key < 0 && f.origin == 0 && p.ui.keysMode == 1) key = 48 + f.card;
        if (key < 0 && p.ui.keysMode == 0)
            for (int n = 0; n < 128; ++n)
                if (p.scaleMap.keys[(size_t) n].chord == f.chord) { key = n; break; }
        if (key >= 0) info << toJ ("   \xc2\xb7   key ") << toJ (midiName (key, flats));
        g.setFont (uiFont (11.5f));
        g.setColour (roleColour (role, t));
        g.drawText (info, juce::Rectangle<int> (12, 70, getWidth() - 24, 16), juce::Justification::centred);
    }
    g.setColour (t.faint);
    g.setFont (uiFont (9.0f));
    g.drawText ("click the name to hear it", juce::Rectangle<int> (12, 84, getWidth() - 24, 10), juce::Justification::centred);

    drawCaption (g, { 12.0f, 90.0f, 66.0f, 12.0f }, "ROOT", t);
    drawCaption (g, { 84.0f, 90.0f, 176.0f, 12.0f }, "TYPE", t);
    drawCaption (g, { 266.0f, 90.0f, 100.0f, 12.0f }, "SLASH BASS", t);
    drawCaption (g, { 12.0f, 138.0f, 140.0f, 12.0f }, "VOICING", t);
    drawCaption (g, { 158.0f, 138.0f, 160.0f, 12.0f }, "INVERSION / SHAPE", t);
}

void ChordPanel::refresh()
{
    refreshing = true;
    auto& p = ctx.proc();
    const auto& f = ctx.focus();
    const bool flats = p.flats();

    rootBox.clear (juce::dontSendNotification);
    for (int i = 0; i < 12; ++i) rootBox.addItem (toJ (noteName (i, flats)), i + 1);
    bassBox.clear (juce::dontSendNotification);
    bassBox.addItem ("none", 1);
    for (int i = 0; i < 12; ++i) bassBox.addItem ("/" + toJ (noteName (i, flats)), i + 2);

    const bool valid = f.chord.valid();
    rootBox.setSelectedId (valid ? f.chord.root + 1 : 0, juce::dontSendNotification);
    typeBox.setSelectedId (valid ? f.chord.quality + 1 : 0, juce::dontSendNotification);
    bassBox.setSelectedId (valid && f.chord.bass >= 0 ? f.chord.bass + 2 : 1, juce::dontSendNotification);
    styleBox.changeItemText (1, "Auto (" + juce::String (styleName (p.ui.style)) + ")");
    styleBox.setSelectedId (f.style >= 0 ? f.style + 2 : 1, juce::dontSendNotification);

    shapeBox.clear (juce::dontSendNotification);
    shapeBox.addItem ("Auto", 1);
    if (valid)
    {
        const int s = f.style >= 0 ? f.style : p.ui.style;
        const int nv = numVariants (f.chord, s);
        for (int v = 0; v < nv; ++v) shapeBox.addItem (toJ (variantName (f.chord, s, v, flats)), v + 2);
    }
    shapeBox.setSelectedId (f.variant >= 0 ? f.variant + 2 : 1, juce::dontSendNotification);

    for (auto* b : { &rootBox, &typeBox, &bassBox, &styleBox, &shapeBox }) b->setEnabled (valid);
    toPad.setVisible (f.origin != 0 && valid);
    toPad.setButtonText ("PAD " + juce::String (p.ui.selectedCard + 1).paddedLeft ('0', 2));
    toPad.setTooltip ("Put this chord on the selected pad");
    refreshing = false;
    repaint();
}

void ChordPanel::edited()
{
    auto& p = ctx.proc();
    Focus f = ctx.focus();
    Chord c;
    c.root = juce::jmax (0, rootBox.getSelectedId() - 1);
    c.quality = juce::jmax (0, typeBox.getSelectedId() - 1);
    const int b = bassBox.getSelectedId() - 2;
    c.bass = (b >= 0 && b != c.root) ? b : -1;
    const int style = styleBox.getSelectedId() - 2;
    int variant = shapeBox.getSelectedId() - 2;
    if (style != f.style) variant = -1;
    const bool chordChanged = c != f.chord;
    if (chordChanged) variant = -1;

    f.chord = c;
    f.style = style;
    f.variant = variant;
    if (f.origin == 0 && f.card >= 0)
    {
        auto pal = p.ui.palette;
        pal[(size_t) f.card] = Card { c, style, variant };
        p.setPalette (pal);
        ctx.setFocus (f);
        ctx.paletteEdited();
    }
    else ctx.setFocus (f);
    auditionBriefly (ctx, this, src::chordPanel, c, style, variant);
}

void ChordPanel::mouseDown (const juce::MouseEvent& e)
{
    if (! nameArea().contains (e.getPosition())) return;
    const auto& f = ctx.focus();
    if (! f.chord.valid()) return;
    auditioning = true;
    ctx.play (src::chordPanel, f.chord, f.style, f.variant);
    repaint();
}

void ChordPanel::mouseUp (const juce::MouseEvent&)
{
    if (! auditioning) return;
    auditioning = false;
    ctx.release (src::chordPanel);
    repaint();
}

//==============================================================================
// VOICING PREVIEW + GUITAR
PreviewPanel::PreviewPanel (EditorContext& c) : ctx (c)
{
    addAndMakeVisible (prevShape);
    addAndMakeVisible (nextShape);
    prevShape.onClick = [this] { if (numShapes > 0) { shapeIndex = (shapeIndex + numShapes - 1) % numShapes; repaint(); } };
    nextShape.onClick = [this] { if (numShapes > 0) { shapeIndex = (shapeIndex + 1) % numShapes; repaint(); } };
    prevShape.setTooltip ("Previous guitar shape");
    nextShape.setTooltip ("Next guitar shape");
}

juce::Rectangle<float> PreviewPanel::guitarArea() const { return { 22.0f, 112.0f, 92.0f, 70.0f }; }

void PreviewPanel::resized()
{
    prevShape.setBounds (124, 158, 26, 22);
    nextShape.setBounds (154, 158, 26, 22);
}

void PreviewPanel::refresh()
{
    const auto& played = ctx.lastPlayed();
    const auto& f = ctx.focus();
    const Chord c = played.chord.valid() ? played.chord : f.chord;
    if (c != chord)
    {
        chord = c;
        numShapes = findShapes (chord, shapes, maxShapes);
        shapeIndex = 0;
    }
    if (played.chord == chord && played.style == GuitarStyle && numShapes > 0)
        shapeIndex = juce::jlimit (0, numShapes - 1, played.variant);
    repaint();
}

void PreviewPanel::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    const bool flats = p.flats();
    drawPanel (g, getLocalBounds().toFloat(), t, "VOICING PREVIEW");

    const auto& played = ctx.lastPlayed();
    Notes notes = played.notes;
    const int bass = played.bassNote;
    if (played.style >= 0)
        drawCaption (g, { 14.0f, 8.0f, (float) getWidth() - 28.0f, 14.0f },
                     juce::String (styleName (played.style)).toUpperCase()
                         + (played.rhythm >= 0 ? juce::String ("  -  ") + rhythmInfo (played.rhythm).name : juce::String()),
                     t, juce::Justification::centredRight);

    // keyboard window
    int lo = 48, hi = 83;
    if (! notes.empty())
    {
        lo = notes.lowest();
        hi = notes.highest();
        if (bass >= 0) lo = juce::jmin (lo, bass);
        lo -= lo % 12;
        hi = juce::jmax (hi, lo + 35);
        hi = hi - hi % 12 + 11;
        if (hi - lo > 59) hi = lo + 59;
    }
    const auto kb = juce::Rectangle<float> (14.0f, 28.0f, (float) getWidth() - 28.0f, 48.0f);
    int whites = 0;
    for (int n = lo; n <= hi; ++n) if (! isBlackKey (n)) ++whites;
    const float ww = kb.getWidth() / (float) juce::jmax (1, whites);
    int wi = 0;
    for (int n = lo; n <= hi; ++n)
    {
        if (isBlackKey (n)) continue;
        auto r = juce::Rectangle<float> (kb.getX() + (float) wi * ww, kb.getY(), ww, kb.getHeight()).reduced (0.5f, 0.0f);
        const bool on = notes.contains (n), isBass = n == bass;
        g.setColour (isBass ? t.wine.brighter (0.6f) : on ? t.home : t.silver.withAlpha (0.92f));
        g.fillRoundedRectangle (r, 2.0f);
        if (n % 12 == 0)
        {
            g.setColour (t.cardDark.withAlpha (0.7f));
            g.setFont (uiFont (7.5f));
            g.drawText (toJ (midiName (n, flats)), r.removeFromBottom (11.0f), juce::Justification::centred);
        }
        ++wi;
    }
    wi = 0;
    for (int n = lo; n <= hi; ++n)
    {
        if (! isBlackKey (n)) { ++wi; continue; }
        auto r = juce::Rectangle<float> (kb.getX() + (float) wi * ww - ww * 0.3f, kb.getY(), ww * 0.6f, kb.getHeight() * 0.6f);
        const bool on = notes.contains (n), isBass = n == bass;
        g.setColour (isBass ? t.wine.brighter (0.4f) : on ? t.home.darker (0.2f) : t.cardDark);
        g.fillRoundedRectangle (r, 1.5f);
    }

    // note names
    juce::String names;
    if (bass >= 0) names << toJ (midiName (bass, flats)) << "  |  ";
    for (int i = 0; i < notes.size(); ++i) names << toJ (midiName (notes[i], flats)) << "  ";
    g.setFont (uiFont (11.0f, true));
    g.setColour (t.text.withAlpha (0.85f));
    g.drawText (notes.empty() ? juce::String ("play a chord") : names.trim(), juce::Rectangle<int> (14, 80, getWidth() - 28, 16), juce::Justification::centred, true);

    // guitar box
    const auto ga = guitarArea();
    drawCaption (g, { 124.0f, 106.0f, 200.0f, 12.0f }, "ON GUITAR", t);
    if (numShapes == 0)
    {
        g.setColour (t.faint);
        g.setFont (uiFont (11.0f));
        g.drawText ("no shape", ga, juce::Justification::centred);
        return;
    }
    const auto& s = shapes[shapeIndex];
    const int hiF = s.highestFret(), loF = s.lowestFret();
    const int baseFret = hiF <= 4 ? 1 : loF;
    const float sx = ga.getWidth() / 5.0f, fy = (ga.getHeight() - 12.0f) / 5.0f;
    const float top = ga.getY() + 12.0f;
    g.setColour (t.silver.withAlpha (0.7f));
    for (int i = 0; i < 6; ++i)
        g.drawVerticalLine ((int) (ga.getX() + (float) i * sx), top, top + fy * 5.0f);
    for (int f = 0; f <= 5; ++f)
        g.fillRect (ga.getX(), top + (float) f * fy - (f == 0 && baseFret == 1 ? 1.5f : 0.5f), ga.getWidth(), (f == 0 && baseFret == 1) ? 3.0f : 1.0f);
    if (baseFret > 1)
    {
        g.setFont (uiFont (9.0f, true));
        g.setColour (t.dim);
        g.drawText (juce::String (baseFret) + "fr", juce::Rectangle<float> (ga.getX() - 22.0f, top, 20.0f, fy), juce::Justification::centredRight);
    }
    for (int i = 0; i < 6; ++i)
    {
        const int fr = s.fret[(size_t) i];
        const float x = ga.getX() + (float) i * sx;
        g.setFont (uiFont (9.5f, true));
        if (fr < 0) { g.setColour (t.faint); g.drawText ("x", juce::Rectangle<float> (x - 5.0f, ga.getY() - 1.0f, 10.0f, 11.0f), juce::Justification::centred); }
        else if (fr == 0) { g.setColour (t.dim); g.drawEllipse (x - 3.0f, ga.getY() + 2.0f, 6.0f, 6.0f, 1.2f); }
        else
        {
            const float y = top + ((float) (fr - baseFret) + 0.5f) * fy;
            g.setColour (t.home);
            g.fillEllipse (x - 5.0f, y - 5.0f, 10.0f, 10.0f);
        }
    }

    juce::String tab;
    for (int i = 0; i < 6; ++i) tab << (s.fret[(size_t) i] < 0 ? juce::String ("x") : juce::String (s.fret[(size_t) i])) << (i < 5 ? " " : "");
    g.setFont (uiFont (12.0f, true));
    g.setColour (t.text);
    g.drawText (tab, juce::Rectangle<int> (124, 120, getWidth() - 136, 16), juce::Justification::centredLeft);
    g.setFont (uiFont (10.5f));
    g.setColour (t.dim);
    g.drawText ("Shape " + juce::String (shapeIndex + 1) + " of " + juce::String (numShapes)
                    + (baseFret > 1 ? toJ ("  \xc2\xb7  fret ") + juce::String (baseFret) : juce::String (toJ ("  \xc2\xb7  open position"))),
                juce::Rectangle<int> (124, 136, getWidth() - 136, 14), juce::Justification::centredLeft);
    g.setColour (t.faint);
    g.setFont (uiFont (9.0f));
    g.drawText ("tap the diagram to hear it", juce::Rectangle<int> (186, 160, getWidth() - 198, 18), juce::Justification::centredLeft);
}

void PreviewPanel::mouseDown (const juce::MouseEvent& e)
{
    if (numShapes == 0 || ! guitarArea().expanded (8.0f).contains (e.position)) return;
    ctx.playNotes (src::guitar, shapeNotes (shapes[shapeIndex]), chord);
}

void PreviewPanel::mouseUp (const juce::MouseEvent&) { ctx.release (src::guitar); }

//==============================================================================
// WHAT'S NEXT
juce::Rectangle<float> NextPanel::cardRect (int i) const
{
    const float gap = 8.0f;
    const float w = ((float) getWidth() - 28.0f - gap * 3.0f) / 4.0f;
    return { 14.0f + (float) i * (w + gap), 30.0f, w, (float) getHeight() - 44.0f };
}

void NextPanel::refresh (const Chord& current)
{
    auto& p = ctx.proc();
    std::vector<Chord> avail;
    if (p.ui.keysMode == 0)
    {
        avail = p.scaleMap.allInKey;
        for (const auto& k : p.scaleMap.keys) if (k.chord.valid() && k.outside) avail.push_back (k.chord);
    }
    else
        for (const auto& c : p.ui.palette) if (c.chord.valid()) avail.push_back (c.chord);

    items = suggestNext (current, p.ui.keyRoot, p.ui.scale, avail);
    where.clear();
    keys.clear();
    for (const auto& s : items)
    {
        int key = -1;
        juce::String w;
        if (p.ui.keysMode == 0)
        {
            for (int n = 0; n < 128; ++n)
                if (p.scaleMap.keys[(size_t) n].chord == s.chord) { key = n; break; }
        }
        else
            for (int i = 0; i < paletteSize; ++i)
                if (p.ui.palette[(size_t) i].chord == s.chord) { key = 48 + i; w = "pad " + juce::String (i + 1).paddedLeft ('0', 2) + "  "; break; }
        if (key >= 0) w << "key " << toJ (midiName (key, p.flats()));
        else w = "click to hear";
        where.push_back (w);
        keys.push_back (key);
    }
    repaint();
}

void NextPanel::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    drawPanel (g, getLocalBounds().toFloat(), t, "WHAT SOUNDS GOOD NEXT");
    if (items.empty())
    {
        g.setColour (t.faint);
        g.setFont (uiFont (12.0f));
        g.drawText ("play a chord to get ideas", getLocalBounds().withTrimmedTop (24), juce::Justification::centred);
        return;
    }
    for (int i = 0; i < (int) items.size() && i < 4; ++i)
    {
        const auto r = cardRect (i);
        const auto& s = items[(size_t) i];
        const Role role = chordRole (s.chord, p.ui.keyRoot, p.ui.scale);
        g.setColour (pressed == i ? t.cardHi.brighter (0.15f) : t.card);
        g.fillRoundedRectangle (r, 7.0f);
        g.setColour (t.panelEdge);
        g.drawRoundedRectangle (r.reduced (0.5f), 7.0f, 1.0f);
        auto in = r.reduced (6.0f, 8.0f);
        g.setFont (uiFont (12.0f, true));
        g.setColour (t.text.withAlpha (0.9f));
        g.drawFittedText (toJ (chordName (s.chord, p.flats())), in.removeFromTop (16.0f).toNearestInt(), juce::Justification::centred, 1, 0.6f);
        g.setFont (uiFont (24.0f));
        g.setColour (t.text);
        g.drawFittedText (toJ (romanNumeral (s.chord, p.ui.keyRoot)), in.removeFromTop (50.0f).toNearestInt(), juce::Justification::centred, 1, 0.6f);
        g.setFont (uiFont (10.5f, true));
        g.setColour (roleColour (role, t));
        g.drawFittedText (toJ (s.why), in.removeFromTop (28.0f).toNearestInt(), juce::Justification::centred, 2);
        g.setFont (uiFont (9.0f));
        g.setColour (t.faint);
        g.drawFittedText (where[(size_t) i], in.toNearestInt(), juce::Justification::centredBottom, 2);
    }
}

void NextPanel::mouseDown (const juce::MouseEvent& e)
{
    for (int i = 0; i < (int) items.size() && i < 4; ++i)
        if (cardRect (i).contains (e.position))
        {
            const auto chord = items[(size_t) i].chord;
            if (e.mods.isPopupMenu())
            {
                juce::PopupMenu m;
                m.addItem (1, "Send to pad " + juce::String (ctx.proc().ui.selectedCard + 1).paddedLeft ('0', 2));
                juce::Component::SafePointer<NextPanel> safe (this);
                m.showMenuAsync (juce::PopupMenu::Options().withMousePosition(), [safe, chord] (int r)
                {
                    if (safe != nullptr && r == 1) safe->ctx.sendToSelectedCard (chord, -1, -1);
                });
                return;
            }
            pressed = i;
            ctx.play (src::next + i, chord, -1, -1);
            repaint();
            return;
        }
}

void NextPanel::mouseUp (const juce::MouseEvent&)
{
    if (pressed >= 0) ctx.release (src::next + pressed);
    pressed = -1;
    repaint();
}

//==============================================================================
// KEYBOARD STRIP
static int whiteIndexOf (int note)
{
    static const int w[12] = { 0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 5, 6 };
    return (note / 12) * 7 + w[note % 12];
}

juce::Rectangle<float> KeyboardStrip::keyRect (int note) const
{
    const float ww = whiteW();
    const float top = 13.0f, h = (float) getHeight() - top;
    if (! isBlackKey (note))
        return { (float) whiteIndexOf (note) * ww, top, ww, h };
    const float bw = ww * 0.62f;
    return { (float) (whiteIndexOf (note) + 1) * ww - bw * 0.5f, top, bw, h * 0.6f };
}

int KeyboardStrip::noteAt (juce::Point<float> pt) const
{
    for (int n = 0; n < 128; ++n)
        if (isBlackKey (n) && keyRect (n).contains (pt)) return n;
    for (int n = 0; n < 128; ++n)
        if (! isBlackKey (n) && keyRect (n).contains (pt)) return n;
    return -1;
}

void KeyboardStrip::paint (juce::Graphics& g)
{
    auto& p = ctx.proc();
    const auto& t = ctx.theme();
    const bool flats = p.flats();
    const bool scaleMode = p.ui.keysMode == 0;

    // zone labels
    g.setFont (uiFont (8.5f, true).withExtraKerningFactor (0.08f));
    const auto& u = p.ui;
    if (u.split)
    {
        const int sp = u.splitNote;
        const auto a = keyRect (juce::jmax (0, sp - 12)), b = keyRect (sp - 1);
        const auto c = keyRect (sp), d = keyRect (juce::jmin (127, sp + 12));
        const juce::String dot = juce::String::fromUTF8 ("  \xc2\xb7  ");
        juce::String left = "CHORDS";
        if (u.keysMode == 0) left << dot << (u.leftRow >= 0 ? juce::String (rowName (u.leftRow)) : juce::String (rowName ((sp - 1) / 12)));
        else left << dot << (u.padBank == 0 ? "PADS 1-12" : "PADS 13-24");
        g.setColour (t.home);
        g.drawText (left, juce::Rectangle<float> (a.getX(), 0.0f, b.getRight() - a.getX(), 12.0f), juce::Justification::centred, true);
        g.setColour (t.accent);
        juce::String right = "YOUR NOTES";
        if (u.rightCh > 0) right << dot << "CH " << u.rightCh;
        if (u.rightOct != 0) right << dot << (u.rightOct > 0 ? "+" : "") << u.rightOct << " OCT";
        if (u.rightSnap) right << dot << "SNAP";
        g.drawText (right, juce::Rectangle<float> (c.getX(), 0.0f, d.getRight() - c.getX(), 12.0f), juce::Justification::centred, true);
    }
    else if (scaleMode)
    {
        for (int r = 0; r < numRows; ++r)
        {
            const auto a = keyRect (r * 12);
            const auto b = keyRect (juce::jmin (127, r * 12 + 11));
            const auto band = juce::Rectangle<float> (a.getX(), 0.0f, b.getRight() - a.getX(), 12.0f);
            g.setColour (r % 2 == 0 ? t.dim : t.faint);
            g.drawText (rowName (r), band, juce::Justification::centred, true);
        }
    }
    else
    {
        const auto a = keyRect (48), b = keyRect (71);
        g.setColour (t.home);
        g.drawText ("PADS 01-24", juce::Rectangle<float> (a.getX(), 0.0f, b.getRight() - a.getX(), 12.0f), juce::Justification::centred);
        g.setColour (t.faint);
        g.drawText ("melody passes through", juce::Rectangle<float> (0.0f, 0.0f, a.getX(), 12.0f), juce::Justification::centred);
        g.drawText ("melody passes through", juce::Rectangle<float> (b.getRight(), 0.0f, (float) getWidth() - b.getRight(), 12.0f), juce::Justification::centred);
    }

    for (int pass = 0; pass < 2; ++pass)
        for (int n = 0; n < 128; ++n)
        {
            const bool black = isBlackKey (n);
            if ((pass == 0) == black) continue;
            auto r = keyRect (n);
            const bool down = p.isInputKeyDown (n);
            const bool sounding = p.isOutputNoteOn (n);
            bool zone = scaleMode ? ((n / 12) % 2 == 0) : (n >= 48 && n < 72);
            if (u.split) zone = n >= u.splitNote - 12;
            juce::Colour c;
            if (black) c = t.cardDark;
            else c = t.silver.withAlpha (zone ? 0.95f : 0.78f);
            if (! scaleMode && zone && ! black && ! u.split) c = c.interpolatedWith (t.home, 0.25f);
            if (u.split && ! black) c = c.interpolatedWith (n >= u.splitNote ? t.accent : t.home, n >= u.splitNote ? 0.34f : 0.24f);
            if (down) c = t.accent.interpolatedWith (t.wine, 0.35f);
            g.setColour (c);
            g.fillRect (black ? r : r.reduced (0.5f, 0.0f));
            if (sounding)
            {
                g.setColour (t.wine.brighter (0.8f));
                const float d = juce::jmin (r.getWidth() - 4.0f, 7.0f);
                g.fillEllipse (r.getCentreX() - d * 0.5f, r.getBottom() - d - 4.0f, d, d);
            }
            if (p.extTrigType.load() == 1 && p.extTrigNum.load() == n)
            {
                g.setColour (t.wine.brighter (0.6f));
                g.fillRect (r.withHeight (5.0f));
            }
            if (! black && n % 12 == 0 && ! sounding)
            {
                g.setColour (t.cardDark.withAlpha (0.65f));
                g.setFont (uiFont (7.0f));
                g.drawText (toJ (midiName (n, flats)), r.withTrimmedTop (r.getHeight() - 12.0f), juce::Justification::centred, false);
            }
        }

    if (u.split)
    {
        const float x = keyRect (u.splitNote).getX();
        g.setColour (t.wine.brighter (0.4f));
        g.fillRect (x - 1.5f, 0.0f, 3.0f, (float) getHeight());
    }
}

void KeyboardStrip::mouseDown (const juce::MouseEvent& e)
{
    int n = noteAt (e.position);
    if (n < 0) return;
    auto& p = ctx.proc();
    const auto& u = p.ui;
    if (u.split)
    {
        if (n >= u.splitNote) return;                       // the right hand's keys play your own sounds
        if (u.keysMode == 0 && u.leftRow >= 0) n += 12 * (u.leftRow - (u.splitNote - 1) / 12);
        if (u.keysMode == 1) n = 48 + n - (u.splitNote - 12) + 12 * u.padBank;
        if (n < 0 || n > 127) return;
    }
    if (p.ui.keysMode == 0)
    {
        const auto c = p.scaleMap.keys[(size_t) n].chord;
        if (! c.valid()) return;
        Focus f;
        f.chord = c;
        f.origin = 1;
        f.key = n;
        ctx.setFocus (f);
        pressedSource = src::scale + n;
        ctx.play (pressedSource, c, -1, -1);
    }
    else if (n >= 48 && n < 72)
    {
        const int idx = n - 48;
        ctx.selectCard (idx);
        const auto& card = p.ui.palette[(size_t) idx];
        pressedSource = src::pad + idx;
        ctx.play (pressedSource, card.chord, card.style, card.variant);
    }
}

void KeyboardStrip::mouseUp (const juce::MouseEvent&)
{
    if (pressedSource >= 0) ctx.release (pressedSource);
    pressedSource = -1;
}

//==============================================================================
// DRAG TILE
void DragTile::paint (juce::Graphics& g)
{
    const auto& t = ctx.theme();
    auto& p = ctx.proc();
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    const int n = p.recordedNotes();
    g.setColour (n > 0 ? t.cardHi : t.cardDark);
    g.fillRoundedRectangle (r, 6.0f);
    juce::Path border;
    border.addRoundedRectangle (r, 6.0f);
    juce::Path dashed;
    const float dashes[] = { 4.0f, 3.0f };
    juce::PathStrokeType (1.0f).createDashedStroke (dashed, border, dashes, 2);
    g.setColour (n > 0 ? t.home : t.faint);
    g.fillPath (dashed);

    g.setFont (uiFont (11.5f, n > 0));
    g.setColour (n > 0 ? t.text : t.dim);
    const int parts = p.recordedParts();
    juce::String text;
    if (n == 0) text = "Record in FL (or hit REC), then drag your chords from here onto your instrument";
    else if (parts > 1)
        text = toJ ("DRAG ALL ") + juce::String (parts) + toJ (" PARTS  \xc2\xb7  ") + juce::String (n)
               + toJ (" notes\ndrop on an empty spot in FL, tick 'Create one channel per track'");
    else if (p.takeSynced.load())
        text = toJ ("DRAG MIDI  \xc2\xb7  ") + juce::String (n) + toJ (" notes  \xc2\xb7  drop at bar 1 on your instrument's channel, it lines up with the song");
    else
        text = toJ ("DRAG MIDI  \xc2\xb7  ") + juce::String (n) + toJ (" notes  \xc2\xb7  drag into your instrument's piano roll (click to save)");
    if (parts > 1) g.setFont (uiFont (10.5f, true));
    g.drawFittedText (text, getLocalBounds().reduced (8, 1), juce::Justification::centred, parts > 1 ? 2 : 1, 0.7f);
}

void DragTile::mouseDrag (const juce::MouseEvent& e)
{
    if (started || e.getDistanceFromDragStart() < 5 || ctx.proc().recordedNotes() == 0) return;
    started = true;
    const auto f = ctx.proc().exportRecording();
    if (f.existsAsFile())
        juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
}

void DragTile::mouseUp (const juce::MouseEvent&)
{
    if (! started && ctx.proc().recordedNotes() > 0)
    {
        const auto f = ctx.proc().exportRecording();
        if (f.existsAsFile())
        {
            auto dir = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER");
            dir.createDirectory();
            auto dest = dir.getNonexistentChildFile (f.getFileNameWithoutExtension(), ".mid");
            if (f.copyFileTo (dest)) dest.revealToUser();
        }
    }
    started = false;
}
