#include "Look.h"

static Theme makeTheme (const char* name, juce::uint32 bgTop, juce::uint32 bgBottom, juce::uint32 panel, juce::uint32 edge,
                        juce::uint32 card, juce::uint32 cardHi, juce::uint32 cardDark, juce::uint32 text, juce::uint32 dim,
                        juce::uint32 faint, juce::uint32 accent, juce::uint32 accentText, juce::uint32 silver, juce::uint32 wine,
                        juce::uint32 home, juce::uint32 move, juce::uint32 pull, juce::uint32 color)
{
    Theme t;
    t.name = name;
    t.bgTop = juce::Colour (bgTop); t.bgBottom = juce::Colour (bgBottom); t.panel = juce::Colour (panel);
    t.panelEdge = juce::Colour (edge); t.card = juce::Colour (card); t.cardHi = juce::Colour (cardHi);
    t.cardDark = juce::Colour (cardDark); t.text = juce::Colour (text); t.dim = juce::Colour (dim);
    t.faint = juce::Colour (faint); t.accent = juce::Colour (accent); t.accentText = juce::Colour (accentText);
    t.silver = juce::Colour (silver); t.wine = juce::Colour (wine);
    t.home = juce::Colour (home); t.move = juce::Colour (move); t.pull = juce::Colour (pull); t.color = juce::Colour (color);
    return t;
}

const Theme& themeFor (int index)
{
    static const Theme themes[] = {
        makeTheme ("Forest", 0xff2c4235, 0xff1b2921, 0xff23362b, 0x24ffffff, 0xff2f4839, 0xff3b5847, 0xff1a2820,
                   0xffe9eee9, 0xffa2b5a8, 0xff6f8577, 0xffcfd7d2, 0xff1b2921, 0xffcfd7d2, 0xff8c2f3f,
                   0xff8fd3a1, 0xffa9c1d6, 0xffd0596b, 0xffdcaa5f),
        makeTheme ("Smoke", 0xff5a564d, 0xff3a3833, 0xff48453e, 0x28ffffff, 0xff5a564d, 0xff6b665b, 0xff34322d,
                   0xfff1ece2, 0xffc2bba9, 0xff8f8878, 0xffe8dcc0, 0xff2e2c27, 0xffd9d4c8, 0xff9a3b3b,
                   0xff9fd39a, 0xff9fc0e0, 0xffe07a6a, 0xffe8b85a),
        makeTheme ("Midnight", 0xff20242c, 0xff14171d, 0xff1b1f27, 0x20ffffff, 0xff272c36, 0xff323947, 0xff13161c,
                   0xffe7eaf0, 0xff9aa3b5, 0xff626b7d, 0xffb7c6ff, 0xff141720, 0xffc9d0dc, 0xff8a3448,
                   0xff7ed6a7, 0xff8fb4ff, 0xffff7a8c, 0xffffc66b),
    };
    return themes[juce::jlimit (0, 2, index)];
}

int numThemes() { return 3; }

juce::Font uiFont (float size, bool bold)
{
    return juce::Font (juce::FontOptions (size, bold ? juce::Font::bold : juce::Font::plain));
}

VesperLook::VesperLook() { setTheme (themeFor (0)); }

void VesperLook::setTheme (const Theme& theme)
{
    t = theme;
    setColour (juce::ResizableWindow::backgroundColourId, t.bgBottom);
    setColour (juce::PopupMenu::backgroundColourId, t.cardDark);
    setColour (juce::PopupMenu::textColourId, t.text);
    setColour (juce::PopupMenu::headerTextColourId, t.dim);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, t.cardHi);
    setColour (juce::PopupMenu::highlightedTextColourId, t.text);
    setColour (juce::ComboBox::textColourId, t.text);
    setColour (juce::ComboBox::backgroundColourId, t.cardDark);
    setColour (juce::ComboBox::outlineColourId, t.panelEdge);
    setColour (juce::ComboBox::arrowColourId, t.dim);
    setColour (juce::Label::textColourId, t.text);
    setColour (juce::TextButton::textColourOffId, t.text);
    setColour (juce::TextButton::textColourOnId, t.accentText);
    setColour (juce::TextButton::buttonColourId, t.card);
    setColour (juce::TextButton::buttonOnColourId, t.accent);
    setColour (juce::ToggleButton::textColourId, t.text);
    setColour (juce::ScrollBar::thumbColourId, t.faint);
    setColour (juce::TooltipWindow::backgroundColourId, t.cardDark);
    setColour (juce::TooltipWindow::textColourId, t.text);
    setColour (juce::TooltipWindow::outlineColourId, t.panelEdge);
    setColour (juce::Slider::textBoxTextColourId, t.text);
}

void VesperLook::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                   float startAngle, float endAngle, juce::Slider&)
{
    const float r = (float) juce::jmin (w, h) * 0.5f - 2.0f;
    const float cx = (float) x + (float) w * 0.5f, cy = (float) y + (float) h * 0.5f;

    juce::Path track;
    track.addCentredArc (cx, cy, r, r, 0.0f, startAngle, endAngle, true);
    g.setColour (t.cardDark);
    g.strokePath (track, juce::PathStrokeType (2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    const float angle = startAngle + pos * (endAngle - startAngle);
    if (pos > 0.001f)
    {
        juce::Path val;
        val.addCentredArc (cx, cy, r, r, 0.0f, startAngle, angle, true);
        g.setColour (t.wine.brighter (0.6f));
        g.strokePath (val, juce::PathStrokeType (2.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    const float kr = r - 4.5f;
    g.setColour (juce::Colours::black.withAlpha (0.35f));
    g.fillEllipse (cx - kr, cy - kr + 1.5f, kr * 2, kr * 2);
    juce::ColourGradient body (t.silver.brighter (0.35f), cx - kr * 0.6f, cy - kr * 0.7f,
                               t.silver.darker (0.7f), cx + kr * 0.6f, cy + kr * 0.8f, false);
    g.setGradientFill (body);
    g.fillEllipse (cx - kr, cy - kr, kr * 2, kr * 2);

    g.setColour (juce::Colours::black.withAlpha (0.22f));
    for (int i = 0; i < 40; ++i)
    {
        const float a = juce::MathConstants<float>::twoPi * (float) i / 40.0f;
        g.drawLine (cx + std::cos (a) * kr * 0.84f, cy + std::sin (a) * kr * 0.84f,
                    cx + std::cos (a) * kr, cy + std::sin (a) * kr, 0.8f);
    }
    const float cr = kr * 0.72f;
    juce::ColourGradient cap (t.silver.brighter (0.5f), cx, cy - cr, t.silver.darker (0.35f), cx, cy + cr, false);
    g.setGradientFill (cap);
    g.fillEllipse (cx - cr, cy - cr, cr * 2, cr * 2);

    g.setColour (t.cardDark);
    g.drawLine (cx + std::sin (angle) * kr * 0.15f, cy - std::cos (angle) * kr * 0.15f,
                cx + std::sin (angle) * kr * 0.66f, cy - std::cos (angle) * kr * 0.66f, 2.0f);
}

void VesperLook::drawComboBox (juce::Graphics& g, int w, int h, bool, int, int, int, int, juce::ComboBox& box)
{
    auto r = juce::Rectangle<float> (0, 0, (float) w, (float) h).reduced (0.5f);
    g.setColour (t.cardDark.withAlpha (box.isEnabled() ? 0.95f : 0.5f));
    g.fillRoundedRectangle (r, 5.0f);
    g.setColour (t.panelEdge);
    g.drawRoundedRectangle (r, 5.0f, 1.0f);
    juce::Path p;
    const float cy = (float) h * 0.5f;
    p.startNewSubPath ((float) w - 15.0f, cy - 2.0f);
    p.lineTo ((float) w - 11.0f, cy + 2.0f);
    p.lineTo ((float) w - 7.0f, cy - 2.0f);
    g.setColour (t.dim);
    g.strokePath (p, juce::PathStrokeType (1.4f));
}

void VesperLook::positionComboBoxText (juce::ComboBox& box, juce::Label& label)
{
    label.setBounds (6, 0, box.getWidth() - 22, box.getHeight());
    label.setFont (getComboBoxFont (box));
}

juce::Font VesperLook::getComboBoxFont (juce::ComboBox& box)
{
    return uiFont (juce::jmin (13.0f, (float) box.getHeight() * 0.52f), true);
}

juce::Font VesperLook::getPopupMenuFont() { return uiFont (13.5f); }

void VesperLook::drawPopupMenuBackground (juce::Graphics& g, int w, int h)
{
    g.fillAll (t.cardDark);
    g.setColour (t.panelEdge);
    g.drawRect (0, 0, w, h, 1);
}

void VesperLook::drawButtonBackground (juce::Graphics& g, juce::Button& b, const juce::Colour&, bool over, bool down)
{
    auto r = b.getLocalBounds().toFloat().reduced (0.5f);
    const bool on = b.getToggleState();
    juce::Colour fill = on ? t.accent : t.card;
    if (! b.isEnabled()) fill = fill.withAlpha (0.4f);
    if (over) fill = fill.brighter (0.07f);
    if (down) fill = fill.darker (0.12f);
    const float radius = (float) b.getProperties().getWithDefault ("radius", 5.0);
    g.setColour (fill);
    g.fillRoundedRectangle (r, radius);
    g.setColour (on ? t.accent.brighter (0.2f) : t.panelEdge);
    g.drawRoundedRectangle (r, radius, 1.0f);
}

juce::Font VesperLook::getTextButtonFont (juce::TextButton&, int h)
{
    return uiFont (juce::jmin (12.5f, (float) h * 0.5f), true);
}

void VesperLook::drawButtonText (juce::Graphics& g, juce::TextButton& b, bool, bool)
{
    g.setFont (getTextButtonFont (b, b.getHeight()));
    g.setColour (b.getToggleState() ? t.accentText : (b.isEnabled() ? t.text : t.faint));
    g.drawFittedText (b.getButtonText(), b.getLocalBounds().reduced (4, 1), juce::Justification::centred, 1);
}

void VesperLook::drawToggleButton (juce::Graphics& g, juce::ToggleButton& b, bool over, bool)
{
    auto r = b.getLocalBounds().toFloat().reduced (0.5f);
    const bool on = b.getToggleState();
    g.setColour (over ? t.cardDark.brighter (0.08f) : t.cardDark);
    g.fillRoundedRectangle (r, r.getHeight() * 0.5f);
    g.setColour (on ? t.wine.brighter (0.5f).withAlpha (0.8f) : t.panelEdge);
    g.drawRoundedRectangle (r, r.getHeight() * 0.5f, 1.0f);

    const float lx = r.getX() + 11.0f, ly = r.getCentreY();
    if (on)
    {
        g.setColour (t.wine.brighter (0.9f).withAlpha (0.35f));
        g.fillEllipse (lx - 6.0f, ly - 6.0f, 12.0f, 12.0f);
        g.setColour (t.wine.brighter (1.1f));
    }
    else g.setColour (t.faint.withAlpha (0.6f));
    g.fillEllipse (lx - 3.5f, ly - 3.5f, 7.0f, 7.0f);

    g.setFont (uiFont (11.0f, true).withExtraKerningFactor (0.06f));
    g.setColour (on ? t.text : t.dim);
    g.drawFittedText (b.getButtonText(), r.withTrimmedLeft (20.0f).withTrimmedRight (6.0f).toNearestInt(),
                      juce::Justification::centred, 1);
}

void VesperLook::drawScrollbar (juce::Graphics& g, juce::ScrollBar&, int x, int y, int w, int h, bool vertical,
                                int thumbStart, int thumbSize, bool over, bool)
{
    juce::Rectangle<float> thumb = vertical
        ? juce::Rectangle<float> ((float) x + 2, (float) thumbStart, (float) w - 4, (float) thumbSize)
        : juce::Rectangle<float> ((float) thumbStart, (float) y + 2, (float) thumbSize, (float) h - 4);
    g.setColour (t.faint.withAlpha (over ? 0.9f : 0.55f));
    g.fillRoundedRectangle (thumb, 3.0f);
}

void drawPanel (juce::Graphics& g, juce::Rectangle<float> r, const Theme& t, const juce::String& title)
{
    juce::ColourGradient grad (t.panel.brighter (0.05f), r.getX(), r.getY(), t.panel.darker (0.08f), r.getX(), r.getBottom(), false);
    g.setGradientFill (grad);
    g.fillRoundedRectangle (r, 10.0f);
    g.setColour (t.panelEdge);
    g.drawRoundedRectangle (r.reduced (0.5f), 10.0f, 1.0f);
    if (title.isNotEmpty())
        drawCaption (g, { r.getX() + 14.0f, r.getY() + 8.0f, r.getWidth() - 28.0f, 14.0f }, title, t);
}

void drawCaption (juce::Graphics& g, juce::Rectangle<float> r, const juce::String& text, const Theme& t, juce::Justification j)
{
    g.setFont (uiFont (9.5f, true).withExtraKerningFactor (0.14f));
    g.setColour (t.dim);
    g.drawText (text, r, j, true);
}
