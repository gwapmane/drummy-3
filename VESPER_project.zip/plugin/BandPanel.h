#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "Widgets.h"

// One octave of the keys on your controller (C..B, any octave). Lit keys play; click one to make
// this track (or the chords) sit out whenever you press that key.
class KeyStrip : public juce::Component, public juce::SettableTooltipClient
{
public:
    KeyStrip (EditorContext& c, std::atomic<int>& m) : ctx (c), mask (m) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override { dragTo = -1; }

private:
    int keyAt (juce::Point<float>) const;
    juce::Rectangle<float> keyRect (int pc) const;
    EditorContext& ctx;
    std::atomic<int>& mask;
    int dragTo = -1, lastKey = -1;
};

// A small square button with a drawn icon (drawn, not a font symbol, so it looks the same everywhere)
struct IconButton : public juce::Button
{
    enum Kind { DownArrow = 0, Cross, Left, Right };
    IconButton (EditorContext& c, Kind k) : juce::Button ({}), ctx (c), kind (k) {}
    void paintButton (juce::Graphics&, bool over, bool down) override;
    EditorContext& ctx;
    Kind kind;
};

// The BAND tab: up to 15 tracks that play along with your chords, each on its own MIDI channel.
class BandPanel : public juce::Component, private juce::Timer
{
public:
    explicit BandPanel (EditorContext& c);
    ~BandPanel() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct PartDrag : public juce::Component, public juce::SettableTooltipClient
    {
        PartDrag (EditorContext& c, int t) : ctx (c), track (t) {}
        void paint (juce::Graphics&) override;
        void mouseDrag (const juce::MouseEvent&) override;
        void mouseUp (const juce::MouseEvent&) override;
        juce::File exportPart();
        EditorContext& ctx;
        int track;
        bool started = false;
    };

    // one track's controls
    struct Strip : public juce::Component
    {
        Strip (BandPanel& owner, int track);
        void paint (juce::Graphics&) override;
        void resized() override;
        void sync();              // follow the parameters (style, mode, what's enabled)
        void showTypeMenu();

        BandPanel& panel;
        EditorContext& ctx;
        const int track;
        int type = 0;
        juce::TextButton on, dice { "DICE" };
        IconButton typeBtn, remove;
        juce::TextButton modeBtns[vesper::numBandModes];
        juce::ComboBox style, channel, octave, dyn;
        juce::Slider density, complexity, level;
        PartDrag drag;
        KeyStrip keys;
        uint32_t lastHits = 0, lastSeed = 0;
        float glow = 0.0f;
        int lastMode = -1, lastStyle = -1;
        bool lastOn = false;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtt;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAtt;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
    };

    struct TrackList : public juce::Component
    {
        void paint (juce::Graphics&) override {}
    };

    void timerCallback() override;
    void rebuildStrips();
    bool anyPartOn() const;
    static juce::Rectangle<int> stripBounds (int track);

    EditorContext& ctx;
    juce::Viewport viewport;
    TrackList list;
    std::vector<std::unique_ptr<Strip>> strips;
    KeyStrip chordKeys;
    juce::TextButton bandOnBtn { "BAND ON" }, diceAllBtn { "DICE ALL" }, stopBtn { "STOP" };
    juce::TextButton allHoldBtn { "ALL HOLD" }, addBtn { "+ TRACK" }, copyBtn { "COPY" };
    juce::TextButton grooveDice { "DICE" };
    IconButton groovePrev, grooveNext;
    juce::ComboBox genreBox, grooveBox, phraseBox, stopModeBox, chordChBox;
    juce::Slider swingKnob;
    int lastGenre = -1, lastFollow = -1, lastTracks = -1, lastGrooveGenre = -1, lastGroove = -1, lastRole = -1;
    void fillGrooves();
    int role() const;
    void showCopyMenu();
    uint32_t lastChanged = 0;
    bool lastPlaying = false, lastAnyOn = false;

    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
};
