#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "Theory.h"
#include "Voicing.h"
#include "Perform.h"
#include "KeysSynth.h"
#include "Band.h"
#include "LinkBus.h"

#include <array>
#include <atomic>
#include <vector>

namespace ids
{
    inline constexpr const char* strum     = "strum";
    inline constexpr const char* strumDir  = "strumDir";
    inline constexpr const char* humanize  = "humanize";
    inline constexpr const char* height    = "height";
    inline constexpr const char* keysOn    = "keysOn";
    inline constexpr const char* keysLevel = "keysLevel";
    inline constexpr const char* vary      = "vary";
    inline constexpr const char* smooth    = "smooth";
    inline constexpr const char* hold      = "hold";
    inline constexpr const char* bassMode  = "bassMode";
    inline constexpr const char* velMode   = "velMode";
    // playing styles (the per-style switches use the ids in vesper::rhythmInfo / feelInfo / timingInfo)
    inline constexpr const char* rate      = "rate";
    inline constexpr const char* swing     = "swing";
    inline constexpr const char* multi     = "multi";
    inline constexpr const char* extType   = "extType";
    inline constexpr const char* extMode   = "extMode";
    inline constexpr const char* extRate   = "extRate";
    inline constexpr const char* extStyles = "extStyles";
    inline constexpr const char* extLatch  = "extLatch";
    // STACK: what each key plays (the whole chord, one note, octaves, stacked 3rds...)
    inline constexpr const char* stack      = "stack";
    inline constexpr const char* stackNotes = "stackNotes";
    // band (per-track ids are "t1".."t15" + On / Type / Mode / Style / Dens / Cplx / Oct / Lvl / Ch / Dyn)
    inline constexpr const char* bandOn     = "bandOn";
    inline constexpr const char* bandGenre  = "bandGenre";
    inline constexpr const char* bandGroove = "bandGroove";
    inline constexpr const char* bandPhrase = "bandPhrase";
    inline constexpr const char* bandSwing  = "bandSwing";
    inline constexpr const char* bandStop   = "bandStop";
    inline constexpr const char* bandRole   = "bandRole";
    inline constexpr const char* chordCh    = "chordCh";
    inline juce::String track (int t, const char* what) { return "t" + juce::String (t + 1) + what; }
    // version 1.5 and older: six fixed parts ("bMelOn" ...), loaded into tracks 1-6
    inline juce::String legacyBand (int part, const char* what) { return juce::String (vesper::bandPartId (part)) + what; }
}

// per-track parameters, in the order VesperProcessor::trackParams holds them
enum TrackParam { TpOn = 0, TpType, TpMode, TpStyle, TpDens, TpCplx, TpOct, TpLvl, TpCh, TpDyn, numTrackParams };
const char* trackParamSuffix (int which);

// What the audio thread needs to turn keys into chords. Trivially copyable.
struct EngineConfig
{
    int keyRoot = 0, scale = 0, genre = 0, style = vesper::Lush;
    int keysMode = 0;          // 0 = SCALE (every chord in the key), 1 = PADS (the 24-chord palette)
    int paletteStart = 48;     // first key of the pads in PADS mode (FL: C4)
    // SPLIT: chords under the left hand, the right hand plays its own notes
    bool split = false;
    int splitNote = 60;        // first key of the right hand (FL: C5)
    int rightCh = 0;           // MIDI channel for the right hand, 0 = same as the chords
    int rightOct = 0;          // right hand octave shift
    bool rightSnap = false;    // right hand: wrong notes snap into the key
    int leftRow = -1;          // SCALE mode: chord family for the octave left of the split (-1 = by octave)
    int padBank = 0;           // PADS mode: 0 = pads 1-12 left of the split, 1 = pads 13-24
    uint16_t scaleMask = 0;    // pitch classes in the key
    std::array<vesper::KeySlot, 128> scaleKeys {};
    vesper::Palette palette {};
};

// The last chord played, for the display. Audio thread -> UI.
struct PlayedInfo
{
    vesper::Chord chord;
    vesper::Notes notes;       // the voicing
    int bassNote = -1;
    int style = 0, variant = 0;
    int rhythm = -1;           // playing style, -1 = plain chord
    int source = -1;           // MIDI key (0..127) or a UI id (>= 1000)
};

// Everything the editor edits. Message thread only.
struct UiState
{
    int keyRoot = 0, scale = 0, genre = vesper::Soul, style = vesper::Lush;
    int keysMode = 0, theme = 0, uiScale = 1, tab = 0, selectedCard = 0;
    bool autoRec = true;       // follow FL's record button
    uint32_t diceSeed = 0;
    vesper::Palette palette {};
    // split keyboard (see EngineConfig)
    bool split = false, rightSnap = false;
    int splitNote = 60, rightCh = 0, rightOct = 0, leftRow = -1, padBank = 0;
};

class VesperProcessor : public juce::AudioProcessor, private juce::Timer
{
public:
    VesperProcessor();
    ~VesperProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "VESPER"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return true; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 2.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return "Default"; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    //==============================================================================
    // Message-thread API used by the editor
    juce::AudioProcessorValueTreeState apvts;
    UiState ui;
    vesper::ScaleMap scaleMap;

    void applyUiState();                                   // rebuild the key map and hand it to the audio thread
    void setKeyScaleGenre (int key, int scale, int genre, bool rebuildPalette);
    void setPalette (const vesper::Palette&);              // undoable
    bool undo();
    bool redo();
    bool canUndo() const { return historyPos > 0; }
    bool canRedo() const { return historyPos + 1 < (int) history.size(); }

    void uiPlayChord (int source, const vesper::Chord&, int style, int variant);
    void uiPlayNotes (int source, const vesper::Notes&, const vesper::Chord& label);
    void uiRelease (int source);
    void uiExt (bool down);                                // the on-screen EXT pad
    void panic();

    bool getLastPlayed (PlayedInfo& out);
    uint32_t playedCounter() const { return playedCount.load(); }

    bool isInputKeyDown (int note) const;
    bool isOutputNoteOn (int note) const;

    std::atomic<uint32_t> loopEvents { 0 };   // bumps each time a MIDI feedback loop is caught

    // upper extension trigger: 0 = none, 1 = a key (note number), 2 = a CC (pedal, wheel, pad)
    std::atomic<int> extTrigType { 0 }, extTrigNum { -1 };
    std::atomic<bool> learnArmed { false };
    std::atomic<uint32_t> learnCount { 0 };
    std::atomic<bool> extOn { false };        // extension currently playing (for the UI light)
    // split keyboard: learn the split point from the next key pressed
    std::atomic<bool> splitLearnArmed { false };
    std::atomic<int> splitLearned { -1 };
    std::atomic<uint32_t> splitLearnCount { 0 };
    juce::String extTriggerName() const;

    std::atomic<bool> recording { false };
    std::atomic<bool> autoRec { true };       // start/stop REC with FL's own record button
    std::atomic<bool> takeSynced { false };   // the take is lined up with FL's song position
    void clearRecording() { clearRequested.store (true); }
    int recordedNotes() const { return recordedNoteOns.load(); }
    int recordedParts() const { return juce::countNumberOfBits (recChannelMask.load()); }
    juce::File exportRecording (int onlyChannel = 0, const juce::String& label = {});   // 0 = every channel, one track each
    juce::File exportPartsFolder();        // every channel as its own file in Documents/VESPER/Takes
    std::vector<int> takeChannels();       // channels with notes in the take, chords first
    juce::String channelName (int channel);
    bool writeTake (const juce::File&, int onlyChannel);
    juce::File exportChord (const vesper::Chord&, int style, int variant);

    bool flats() const { return vesper::keyPrefersFlats (ui.keyRoot, ui.scale); }

    // band
    std::array<std::atomic<uint32_t>, vesper::maxBandTracks> bandSeed;     // DICE per track
    void rollBandSeed (int track);
    void applyBandGenre (int genre);       // every track's style for the genre (+ its usual lineup if nothing is on)
    std::atomic<bool> bandPlaying { false };
    std::atomic<int> followState { 0 };    // copies: 0 = this is the main VESPER, 1 = following one, 2 = no main VESPER found
    std::array<std::atomic<uint32_t>, vesper::maxBandTracks> partHits;   // bumps when a track plays (lights)
    void stopBandFromUi();

    // tracks: how many are showing, and the key strips (bit per key C..B: that key is skipped)
    std::atomic<int> numTracks { vesper::defaultBandTracks };
    std::array<std::atomic<int>, vesper::maxBandTracks> trackKeys;
    std::atomic<int> chordKeys { 0 };      // the main chord output's key strip
    std::atomic<uint32_t> tracksChanged { 0 };   // bumps when tracks are added, removed or retyped (UI rebuilds)
    float trackValue (int track, int which) const;
    void setTrackValue (int track, int which, float plainValue);
    int trackType (int track) const;
    bool addTrack();                       // false when all 15 are in use
    void removeTrack (int track);
    void setTrackType (int track, int type);
    void setAllHold (bool hold);           // ALL HOLD: every melodic track plays what you press
    bool allHold() const;
    int freeChannel (int exceptTrack) const;
    int bandGenreNow() const;              // the BAND tab's genre and groove
    int bandGrooveNow() const;
    void setBandGroove (int index);

    // VESPER DRUMS follows the band's genre: VESPER writes it to a small file both plugins can see
    static juce::File drumLinkFile();

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    //==============================================================================
    // audio thread
    struct UiEvent
    {
        int type = 0;          // 0 play chord, 1 play notes, 2 release, 3 panic, 4 ext down, 5 ext up
        int source = 0;
        vesper::Chord chord;
        int style = -1, variant = -1;
        vesper::Notes notes;
    };

    struct Slot
    {
        bool active = false;
        int source = -1;
        uint32_t age = 0;
        vesper::Notes sent;                                  // notes this slot is sounding
        std::array<uint8_t, vesper::Notes::cap> chans {};

        // performance
        bool isExt = false;        // an upper-extension layer
        int parent = -1;           // ext layers: the chord slot they sit on
        bool applyFeel = true;
        vesper::Chord chord;
        vesper::Notes upper;       // chord tones, sorted
        vesper::Notes ext;         // extension notes merged into this chord's pattern
        int bass = -1, bassCh = 1;
        int velocity = 100;
        int rhythm = -1;           // -1 = plain chord
        double stepBeats = 0.5, anchor = 0, nextBeat = 0;
        int64_t gridIndex = 0;
        int stepCount = 0, memory = -1;
        bool synced = false, loopBar = false, done = false, swingOK = false, restartPending = false;
        bool muted = false;        // the chord output's key strip skips this key (band and layers still play)
        bool spreadOctave = true;  // waterfall / rising also use the octave above
    };

    struct Pending
    {
        int64_t due = 0;
        int note = 0, velocity = 0, channel = 1, slot = 0;
        int64_t offAfter = -1;     // note-ons: samples until the matching note-off, -1 = ring until release
        bool isOff = false;
        uint32_t gen = 0;          // note-offs: which strike of the note they belong to
    };

    struct VaryMemory { int id = -1; vesper::Notes notes; };

    struct RecEvent { double beat = 0; uint8_t kind = 0, channel = 1, d1 = 0, d2 = 0, synced = 0; };   // kind 0 on, 1 off, 2 cc

    // per-block snapshot of the playing-style switches
    struct StyleNow
    {
        bool rhythm[vesper::numRhythms] {};
        bool feel[vesper::numFeels] {};
        bool timing[vesper::numTimings] {};
        int rate = 0;              // 0 = each style's own, else index + 1
        float swing = 0.25f;       // fraction of a step
        int multi = 0;
        int extType = 0, extMode = 0, extRate = 3;
        bool extStyles = false, extLatch = false;
        float strumMs = 0, human = 0.35f;
        int strumDir = 0;
    };

    void readStyle();
    void handleUiEvent (const UiEvent&, juce::MidiBuffer& out);
    void triggerChord (int source, const vesper::Chord&, int style, int variant, int velocity, int pos, juce::MidiBuffer& out);
    void triggerNotes (int source, const vesper::Notes&, const vesper::Chord& label, int velocity, int pos, juce::MidiBuffer& out);
    int allocSlot (int source, int pos, juce::MidiBuffer& out);
    void releaseSource (int source, int pos, juce::MidiBuffer& out);
    void releaseSlot (int index, int pos, juce::MidiBuffer& out);
    void releaseAll (int pos, juce::MidiBuffer& out);
    void strike (int slot, const vesper::Notes& notes, int velocity, int accent, int pos, int64_t offAfter,
                 int stepParity, bool useFeel, bool useKnobStrum);
    void playStep (int slot, int pos, juce::MidiBuffer& out);
    void advancePatterns (int upToPos, juce::MidiBuffer& out);
    void setupRhythm (int slot, int rhythm, int rateIndex, int pos, juce::MidiBuffer& out);
    void extPress (int pos, juce::MidiBuffer& out);
    void extRelease (int pos, juce::MidiBuffer& out);
    void startExt (int parent, int pos, juce::MidiBuffer& out);
    void stopExt (int pos, juce::MidiBuffer& out);
    void noteOffOwned (int slot, int note, int channel, int pos, juce::MidiBuffer& out);
    void schedule (int64_t due, int note, int velocity, int channel, int slot, int64_t offAfter);
    void emitNoteOn (int note, int velocity, int channel, int slot, int pos, juce::MidiBuffer& out);
    void flushPending (int upTo, juce::MidiBuffer& out);
    void publish (const vesper::Chord&, const vesper::Notes&, int bass, int style, int variant, int rhythm, int source);
    void clearSlotNotes (int index, int pos, juce::MidiBuffer& out);
    // band
    void readBand();
    bool bandPartHere (int part) const;
    void bandChordChanged (const vesper::Chord&, int pos, juce::MidiBuffer& out, int key);
    void startBand (int pos, juce::MidiBuffer& out);
    void stopBand (int pos, juce::MidiBuffer& out);
    void adoptHarmony (int pos, juce::MidiBuffer& out);
    void advanceBand (int upToPos, juce::MidiBuffer& out, bool inclusive = false);
    void fireBandStep (int64_t step, double stepBeat, bool pitchedOnly, int64_t minDue, juce::MidiBuffer& out);
    void bandHousekeeping (int pos, juce::MidiBuffer& out);
    void playLayers (int source, const vesper::Chord&, const vesper::Notes& pressed, int velocity, int pos, juce::MidiBuffer& out);
    void clearRings (int pos, juce::MidiBuffer& out);
    void followLeader (juce::MidiBuffer& out);
    void publishLink();
    bool anyChordHeld() const;
    void startExpression (int pos, juce::MidiBuffer& out);
    void updateExpression (juce::MidiBuffer& out);
    double beatAt (int pos) const { return blockBeat + pos / samplesPerBeat; }
    int posOfBeat (double beat) const { return juce::jlimit (0, juce::jmax (0, blockSamples - 1), (int) std::floor ((beat - blockBeat) * samplesPerBeat)); }
    double stepTime (const Slot& s, int64_t index) const;

    EngineConfig cfg, pendingCfg;
    juce::SpinLock cfgLock;
    std::atomic<bool> cfgDirty { false };

    juce::AbstractFifo uiFifo { 256 };
    std::array<UiEvent, 256> uiEvents;

    static constexpr int numChordSlots = 32;
    // chord slots (keys you hold, plus their HOLD layers), then one per band track, then one RING slot per track
    std::array<Slot, numChordSlots + 2 * vesper::maxBandTracks> slots;
    static constexpr int bandSlot (int track) { return numChordSlots + track; }
    static constexpr int ringSlot (int track) { return numChordSlots + vesper::maxBandTracks + track; }
    std::array<Pending, 1024> pending, dueList;
    int numPending = 0;
    std::array<std::array<int16_t, 128>, 16> owner {};
    std::array<std::array<uint32_t, 128>, 16> strikeGen {};
    std::array<VaryMemory, 64> varyMemory;
    vesper::Notes lastVoicing;
    vesper::Rng rng;
    uint32_t slotAge = 0;
    bool strumFlip = false;
    bool lastHold = false;
    bool lastHostRec = false;
    bool extHeld = false;
    int rhythmTurn = 0, lastRhythm = -1;

    StyleNow st;
    std::array<std::atomic<float>*, vesper::numRhythms> rhythmParams {};
    std::array<std::atomic<float>*, vesper::numFeels> feelParams {};
    std::array<std::atomic<float>*, vesper::numTimings> timingParams {};

    // expression (CC11) swell / fade
    int exprMode = 0;          // 0 off, 1 swell, 2 fade
    double exprStartBeat = 0;
    int lastExprSent = 127;
    float synthExpr = 1.0f;

    // block timing
    double blockBeat = 0, samplesPerBeat = 22050.0, bpm = 120.0;
    int blockSamples = 0;
    bool hostPlaying = false;

    // band (audio thread)
    vesper::Band band;
    vesper::BandConfig bandCfg;
    vesper::Harmony bandHarm;
    double bandHarmBeat = 0;
    int bandHarmCounter = 0;
    bool bandRunning = false, bandSynced = false, bandEnabled = true;
    double bandOrigin = 0, bandStopAt = -1, bandLastStepBeat = -1e9;
    int64_t bandNextStep = 0, bandLastStep = -1;
    uint32_t bandStarts = 0;
    int bandStopMode = 0, bandRoleNow = 0, chordChannel = 1;
    uint16_t keysSkip = 0;                 // channels the built-in keys sound leaves alone (drums)
    std::array<std::array<std::atomic<float>*, numTrackParams>, vesper::maxBandTracks> bandParams {};
    std::atomic<float>* stackParam = nullptr;
    std::atomic<float>* stackNotesParam = nullptr;
    uint32_t ringMask = 0;                 // RING tracks currently ringing
    bool lastHostPlaying = false;
    void migrateOldState (juce::XmlElement&);
    void timerCallback() override;         // keeps the VESPER DRUMS link file up to date
    int linkGenreWritten = -1, linkGrooveWritten = -1;
    double linkWrittenAt = 0;
    // link between VESPER copies
    int linkId = 0;
    double linkDelta = 0, linkDeltaBest = -1e18, linkDeltaSince = 0;
    uint32_t linkStarts = 0;
    int linkHarmId = -1;
    bool linkHaveDelta = false;
    double linkNowMs = 0, linkOriginSeen = 0;
    bool linkSyncedSeen = false;
    int lastRole = 0, linkLeaderSeen = 0;
    bool anyBandPartOn() const;
    double lateWindowBeats() const;
    void checkBandClock (int pos, juce::MidiBuffer& out);
    void activateBandSlots();
    void updateKeysSkip();

    juce::MidiBuffer outBuffer;
    KeysSynth synth;
    double sr = 44100.0;
    int64_t sampleClock = 0;
    double freeBeat = 0;

    std::array<std::atomic<uint32_t>, 4> inDown {}, outOn {};
    std::array<int, 128> passthroughOn {};
    // per input key: the single note it is sounding (right hand / pass-through) and the
    // key whose chord it started (left hand), so note-offs match even if settings change
    std::array<int16_t, 128> keyOutNote {}, keyChordKey {};
    std::array<uint8_t, 128> keyOutCh {};
    void resetKeyMaps();

    // MIDI loop guard: if VESPER's own output gets routed back into it, its chords would
    // retrigger more chords forever. Remember what went out and drop it when it comes back.
    std::array<int64_t, 128> sentOnAt {}, sentOffAt {};
    std::array<std::array<int64_t, 128>, 16> chOnAt {}, chOffAt {};   // the same, per MIDI channel
    uint16_t bandChannels = 0;     // channels the band / HOLD / RING tracks play on (not the chords' channel)
    void loopCleanup (int pos, juce::MidiBuffer& out);
    std::array<int, 128> sentOnVel {};
    int64_t loopActiveUntil = 0, burstStart = 0, mutedUntil = 0;
    int burstCount = 0;
    float sentEnergy = 0, matchEnergy = 0;   // recent notes sent vs. notes that came straight back
    void resetLoopGuard();

    juce::SpinLock playedLock;
    PlayedInfo played;
    std::atomic<uint32_t> playedCount { 0 };

    std::vector<RecEvent> rec;
    std::atomic<int> recCount { 0 };
    std::atomic<int> recordedNoteOns { 0 };
    std::atomic<uint32_t> recChannelMask { 0 };
    std::atomic<bool> clearRequested { false };

    // message thread
    std::vector<vesper::Palette> history;
    int historyPos = -1;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (VesperProcessor)
};
