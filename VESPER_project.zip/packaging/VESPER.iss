; Inno Setup script: builds VESPER-Setup.exe from the collected build folder.
#ifndef SrcDir
  #define SrcDir "dist"
#endif

[Setup]
AppName=VESPER
AppVersion=1.7.0
AppPublisher=VESPER
DefaultDirName={commoncf64}\VST3
DisableDirPage=yes
DisableProgramGroupPage=yes
OutputBaseFilename=VESPER-Setup
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
PrivilegesRequired=admin
UninstallFilesDir={commonappdata}\VESPER
Compression=lzma2
SolidCompression=yes

[Files]
Source: "{#SrcDir}\VESPER.vst3\*"; DestDir: "{commoncf64}\VST3\VESPER.vst3"; Flags: recursesubdirs createallsubdirs ignoreversion
Source: "{#SrcDir}\VESPER DRUMS.vst3\*"; DestDir: "{commoncf64}\VST3\VESPER DRUMS.vst3"; Flags: recursesubdirs createallsubdirs ignoreversion

[Messages]
FinishedLabel=VESPER and VESPER DRUMS are installed. In FL Studio: Options > Manage plugins > Find installed plugins. Both show up under Generators.
