// VESPER DRUMS: a kit = what's on the 16 pads (the sound, what kind of sound it is, and how it plays).
#pragma once

#include <juce_core/juce_core.h>

#include "DrumLibrary.h"

#include <array>

namespace drums
{
static constexpr int numPads = 16;

struct PadSettings
{
    juce::String label = "PAD";   // "PERC 1"
    juce::String path;            // the sound file
    int cat = CatKick;            // what DICE pulls from
    int note = 36;                // the MIDI note that plays it (VESPER's drums use the standard GM notes)
    float level = 0.8f;           // 0..1
    float pan = 0.0f;             // -1..1
    float tune = 0.0f;            // semitones, -24..24
    float decay = 1.0f;           // 1 = the whole sound, lower = shorter
    int choke = 0;                // pads in the same group cut each other off (closed hat stops the open hat)
    bool locked = false;          // DICE ALL and genre changes leave it alone
};

struct Kit
{
    juce::String name = "NEW KIT";
    int genre = -1;
    std::array<PadSettings, numPads> pads;
};

Kit defaultKit();                       // the MPC-style layout: kick on pad 1 ... tambourine on pad 16
std::unique_ptr<juce::XmlElement> kitToXml (const Kit&);
bool kitFromXml (const juce::XmlElement&, Kit&);

// where kits live: Documents/VESPER DRUMS/Kits/<GENRE>/<name>.vdkit
juce::File kitsFolder();
juce::File kitFolderFor (int genre);
juce::Array<juce::File> kitsFor (int genre);        // -1 = every kit
juce::File defaultKitFor (int genre);               // the kit you made the default for this genre, if any
void setDefaultKitFor (int genre, const juce::File&);
} // namespace drums
