#include "DrumLibrary.h"

#include <algorithm>
#include <set>

namespace drums
{
const char* catName (int cat)
{
    static const char* n[numCats] = { "KICK", "SNARE", "CLAP", "SNAP", "RIM", "CLOSED HAT", "OPEN HAT", "RIDE", "CRASH", "TOM",
                                      "PERC", "SHAKER", "TAMBOURINE", "808", "FX", "VOX", "OTHER" };
    return n[juce::jlimit (0, numCats - 1, cat)];
}

juce::Colour catColour (int cat)
{
    static const juce::uint32 c[numCats] = {
        0xffd9534f,   // kick: red
        0xfff0ad4e,   // snare: amber
        0xffe8c547,   // clap: gold
        0xffd7c26a,   // snap
        0xffc9a46b,   // rim
        0xff3fb6a8,   // closed hat: teal
        0xff5bc8e8,   // open hat: cyan
        0xff8fb3c9,   // ride
        0xffb8c4d0,   // crash: silver
        0xffe0823d,   // tom: orange
        0xffa27fd8,   // perc: purple
        0xff7fc97f,   // shaker: green
        0xffbfd86a,   // tambourine
        0xffb03a48,   // 808: deep red
        0xff5a8de0,   // fx: blue
        0xffe07fb0,   // vox: pink
        0xff8a8f96    // other
    };
    return juce::Colour (c[juce::jlimit (0, numCats - 1, cat)]);
}

const char* genreName (int g)
{
    static const char* n[numGenres] = { "R&B / SOUL", "JAZZ", "GOSPEL", "ROCK / INDIE", "POP", "HIP-HOP", "TRAP", "DRILL", "NEO-SOUL",
                                        "LO-FI", "FUNK / DISCO", "HOUSE / EDM", "AFROBEATS", "LATIN", "REGGAETON", "REGGAE", "COUNTRY",
                                        "BLUES", "CINEMATIC" };
    return n[juce::jlimit (0, numGenres - 1, g)];
}

//==============================================================================
namespace
{
// "OpenHat_02 (Tape).wav" -> "open hat 02 tape"
juce::StringArray tokens (const juce::String& raw)
{
    juce::String spaced;
    juce::juce_wchar prev = 0;
    for (auto it = raw.getCharPointer(); ! it.isEmpty(); ++it)
    {
        const auto c = *it;
        const bool boundary = (juce::CharacterFunctions::isLowerCase (prev) && juce::CharacterFunctions::isUpperCase (c))
                           || (juce::CharacterFunctions::isLetter (prev) && juce::CharacterFunctions::isDigit (c))
                           || (juce::CharacterFunctions::isDigit (prev) && juce::CharacterFunctions::isLetter (c));
        if (boundary) spaced << ' ';
        spaced << (juce::CharacterFunctions::isLetterOrDigit (c) ? juce::CharacterFunctions::toLowerCase (c) : (juce::juce_wchar) ' ');
        prev = c;
    }
    juce::StringArray t;
    t.addTokens (spaced, " ", "");
    t.removeEmptyStrings();
    return t;
}

struct Words
{
    juce::StringArray t;
    juce::String joined;   // " open hat 02 "
    explicit Words (const juce::String& raw) : t (tokens (raw)), joined (" " + t.joinIntoString (" ") + " ") {}
    bool has (const char* w) const { return t.contains (w); }
    bool any (std::initializer_list<const char*> ws) const { for (auto* w : ws) if (t.contains (w)) return true; return false; }
    bool phrase (const char* p) const { return joined.contains (juce::String (" ") + p + " "); }
};

int catOf (const Words& w)
{
    const bool hat = w.any ({ "hat", "hats", "hh", "hihat", "hihats", "hhs" }) || w.phrase ("hi hat") || w.phrase ("hi hats");
    const bool open = w.any ({ "open", "opn" });
    if (w.any ({ "oh", "ohh", "ohat", "openhat", "openhats", "ophat" }) || (open && hat) || w.phrase ("hat open")) return CatOpenHat;
    if (w.any ({ "kick", "kicks", "kik", "kck", "bd", "bassdrum", "kickdrum" }) || w.phrase ("bass drum")) return CatKick;
    if (w.any ({ "snare", "snares", "snr", "sd", "snaredrum" })) return CatSnare;
    if (w.any ({ "clap", "claps", "clp", "handclap", "handclaps" })) return CatClap;
    if (w.any ({ "snap", "snaps", "fingersnap", "finger" })) return CatSnap;
    if (w.any ({ "rim", "rims", "rimshot", "rimshots", "sidestick", "stick", "xstick", "crossstick" })) return CatRim;
    if (hat || w.any ({ "chh", "closedhat", "hhc", "closedhats", "pedal" })) return CatClosedHat;
    if (w.any ({ "ride", "rides" })) return CatRide;
    if (w.any ({ "crash", "crashes", "cymbal", "cymbals", "cym", "china", "splash" })) return CatCrash;
    if (w.any ({ "tom", "toms", "floortom" })) return CatTom;
    if (w.any ({ "shaker", "shakers", "shk", "maraca", "maracas", "cabasa" })) return CatShaker;
    if (w.any ({ "tamb", "tambourine", "tamborine", "tambo", "tambourines" })) return CatTambourine;
    if (w.any ({ "perc", "percs", "percussion", "conga", "congas", "bongo", "bongos", "tabla", "cowbell", "bell", "clave", "claves",
                 "timbale", "timbales", "woodblock", "block", "agogo", "djembe", "guiro", "triangle", "cajon", "shekere", "cuica", "log" }))
        return CatPerc;
    if (w.any ({ "808", "808s", "sub", "subs" }) || (w.has ("bass") && ! w.has ("drum"))) return Cat808;
    if (w.any ({ "fx", "sfx", "riser", "risers", "impact", "impacts", "sweep", "noise", "uplifter", "downlifter", "reverse",
                 "transition", "whoosh", "texture" }))
        return CatFx;
    if (w.any ({ "vox", "vocal", "vocals", "voice", "chant", "chants", "adlib", "adlibs", "shout" })) return CatVox;
    return CatOther;
}
} // namespace

int categorize (const juce::String& fileName, const juce::StringArray& folders)
{
    const auto stem = fileName.containsChar ('.') ? fileName.upToLastOccurrenceOf (".", false, false) : fileName;
    const int c = catOf (Words (stem));
    if (c != CatOther) return c;
    for (const auto& f : folders)   // nearest folder first: "Kicks/Hard 1.wav"
    {
        const int fc = catOf (Words (f));
        if (fc != CatOther) return fc;
    }
    return CatOther;
}

uint32_t genreTags (const juce::String& fileName, const juce::StringArray& folders)
{
    juce::String all = fileName;
    for (const auto& f : folders) all << " / " << f;
    const Words w (all);
    const juce::String raw = all.toLowerCase();
    uint32_t g = 0;
    auto tag = [&g] (int genre) { g |= 1u << genre; };
    if (w.any ({ "rnb", "soul" }) || raw.contains ("r&b") || raw.contains ("r & b")) tag (0);
    if (w.any ({ "jazz", "jazzy", "bebop", "brush", "brushes" })) tag (1);
    if (w.any ({ "gospel", "church", "choir" })) tag (2);
    if (w.any ({ "rock", "indie", "live", "acoustic", "punk", "metal" })) tag (3);
    if (w.any ({ "pop", "kpop" })) tag (4);
    if (w.any ({ "hiphop", "boombap", "rap", "dusty", "90s" }) || w.phrase ("hip hop") || w.phrase ("boom bap")) tag (5);
    if (w.any ({ "trap", "traps" })) tag (6);
    if (w.any ({ "drill", "drills" })) tag (7);
    if (w.any ({ "neo", "neosoul" })) tag (8);
    if (w.any ({ "lofi", "vinyl", "tape", "chillhop" }) || w.phrase ("lo fi")) tag (9);
    if (w.any ({ "funk", "funky", "disco", "boogie" })) tag (10);
    if (w.any ({ "house", "edm", "techno", "dance", "club", "deep" })) tag (11);
    if (w.any ({ "afro", "afrobeat", "afrobeats", "amapiano", "afrohouse", "highlife", "naija" })) tag (12);
    if (w.any ({ "latin", "salsa", "cumbia", "bossa", "samba" })) tag (13);
    if (w.any ({ "reggaeton", "dembow", "perreo" })) tag (14);
    if (w.any ({ "reggae", "dancehall", "dub", "riddim" })) tag (15);
    if (w.any ({ "country", "folk", "americana" })) tag (16);
    if (w.any ({ "blues", "bluesy" })) tag (17);
    if (w.any ({ "cinematic", "trailer", "orchestral", "epic", "film", "score", "taiko" })) tag (18);
    return g;
}

//==============================================================================
Library::Library() : juce::Thread ("VESPER DRUMS library scan") {}

Library::~Library() { stopThread (8000); }

juce::File Library::home()
{
    return juce::File::getSpecialLocation (juce::File::userDocumentsDirectory).getChildFile ("VESPER DRUMS");
}

bool Library::isAudioFile (const juce::File& f)
{
    const auto ext = f.getFileExtension().toLowerCase();
    return ext == ".wav" || ext == ".aif" || ext == ".aiff" || ext == ".flac" || ext == ".ogg" || ext == ".mp3";
}

void Library::scan (const juce::StringArray& r)
{
    stopThread (8000);
    {
        const std::lock_guard<std::mutex> g (lock);
        pendingRoots = r;
    }
    progress.store (0);
    startThread();
}

void Library::run()
{
    juce::StringArray rootsNow;
    {
        const std::lock_guard<std::mutex> g (lock);
        rootsNow = pendingRoots;
    }
    std::vector<Entry> found;
    std::set<juce::String> seen;
    for (const auto& r : rootsNow)
    {
        const juce::File root (r);
        if (! root.isDirectory()) continue;
        for (const auto& it : juce::RangedDirectoryIterator (root, true, "*", juce::File::findFiles))
        {
            if (threadShouldExit()) return;
            const auto f = it.getFile();
            if (! isAudioFile (f) || f.getFileName().startsWithChar ('.') || f.getFullPathName().contains ("__MACOSX")) continue;
            if (! seen.insert (f.getFullPathName()).second) continue;
            juce::StringArray folders;
            for (auto d = f.getParentDirectory(); d.exists() && d != root.getParentDirectory() && folders.size() < 12; d = d.getParentDirectory())
            {
                folders.add (d.getFileName());
                if (d == root) break;
            }
            Entry e;
            e.path = f.getFullPathName();
            e.cat = categorize (f.getFileName(), folders);
            e.genres = genreTags (f.getFileNameWithoutExtension(), folders);
            found.push_back (e);
            progress.store ((int) found.size());
            if (found.size() > 300000) break;
        }
    }
    std::sort (found.begin(), found.end(), [] (const Entry& a, const Entry& b) { return a.path.compareNatural (b.path) < 0; });
    {
        const std::lock_guard<std::mutex> g (lock);
        entries = std::move (found);
        rootList = rootsNow;
    }
    saveIndex();
    changed.fetch_add (1);
}

void Library::saveIndex() const
{
    juce::XmlElement x ("VESPER_DRUMS_LIBRARY");
    {
        const std::lock_guard<std::mutex> g (lock);
        for (const auto& r : rootList) x.createNewChildElement ("ROOT")->setAttribute ("path", r);
        for (const auto& e : entries)
        {
            auto* s = x.createNewChildElement ("S");
            s->setAttribute ("p", e.path);
            s->setAttribute ("c", e.cat);
            s->setAttribute ("g", (int) e.genres);
        }
    }
    const auto f = home().getChildFile ("library.xml");
    f.getParentDirectory().createDirectory();
    x.writeTo (f);
}

bool Library::loadIndex()
{
    const auto f = home().getChildFile ("library.xml");
    if (! f.existsAsFile()) return false;
    auto x = juce::XmlDocument::parse (f);
    if (x == nullptr) return false;
    std::vector<Entry> list;
    juce::StringArray r;
    for (auto* c : x->getChildIterator())
    {
        if (c->hasTagName ("ROOT")) r.add (c->getStringAttribute ("path"));
        else if (c->hasTagName ("S"))
        {
            Entry e;
            e.path = c->getStringAttribute ("p");
            e.cat = juce::jlimit (0, numCats - 1, c->getIntAttribute ("c", CatOther));
            e.genres = (uint32_t) c->getIntAttribute ("g", 0);
            list.push_back (e);
        }
    }
    {
        const std::lock_guard<std::mutex> g (lock);
        entries = std::move (list);
        rootList = r;
    }
    changed.fetch_add (1);
    return true;
}

juce::StringArray Library::roots() const { const std::lock_guard<std::mutex> g (lock); return rootList; }
int Library::size() const { const std::lock_guard<std::mutex> g (lock); return (int) entries.size(); }

int Library::count (int cat) const
{
    const std::lock_guard<std::mutex> g (lock);
    int n = 0;
    for (const auto& e : entries) if (e.cat == cat) ++n;
    return n;
}

std::vector<Entry> Library::inCategory (int cat) const
{
    const std::lock_guard<std::mutex> g (lock);
    std::vector<Entry> v;
    for (const auto& e : entries) if (e.cat == cat) v.push_back (e);
    return v;
}

Entry Library::entry (const juce::String& path) const
{
    const std::lock_guard<std::mutex> g (lock);
    for (const auto& e : entries) if (e.path == path) return e;
    Entry e;
    e.path = path;
    return e;
}

juce::String Library::pick (int cat, int genre, juce::Random& r, const juce::String& avoid) const
{
    const auto all = inCategory (cat);
    if (all.empty()) return {};
    std::vector<const Entry*> tagged, rest;
    for (const auto& e : all)
    {
        if (e.path == avoid && all.size() > 1) continue;
        ((genre >= 0 && ((e.genres >> genre) & 1u)) ? tagged : rest).push_back (&e);
    }
    // mostly the genre's own sounds, now and then a wildcard from the rest of the folder
    const bool useTagged = ! tagged.empty() && (rest.empty() || r.nextFloat() < 0.8f);
    const auto& from = useTagged ? tagged : (rest.empty() ? tagged : rest);
    if (from.empty()) return all.front().path;
    return from[(size_t) r.nextInt ((int) from.size())]->path;
}

juce::String Library::step (int cat, const juce::String& from, int dir) const
{
    const auto all = inCategory (cat);
    if (all.empty()) return {};
    int i = -1;
    for (int k = 0; k < (int) all.size(); ++k) if (all[(size_t) k].path == from) { i = k; break; }
    if (i < 0) return all[dir >= 0 ? 0 : all.size() - 1].path;
    const int n = (int) all.size();
    return all[(size_t) (((i + dir) % n + n) % n)].path;
}
} // namespace drums
