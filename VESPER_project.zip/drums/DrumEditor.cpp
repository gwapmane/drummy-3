#include "DrumEditor.h"

namespace drums
{
// layout (base size 1060 x 700)
static constexpr int padX0 = 28, padY0 = 84, cellW = 138, cellH = 126, padW = 130, padH = 96;

static juce::Rectangle<int> padCell (int i)
{
    const int row = 3 - i / 4, col = i % 4;   // MPC: pad 1 is bottom-left
    return { padX0 + col * cellW, padY0 + row * cellH, padW, padH };
}

static juce::String shortName (const juce::String& path)
{
    if (path.isEmpty()) return "EMPTY";
    return juce::File (path).getFileNameWithoutExtension();
}

//==============================================================================
void PadButton::paint (juce::Graphics& g)
{
    const auto& t = ed.theme();
    const auto& p = ed.proc.kit().pads[(size_t) index];
    const auto r = getLocalBounds().toFloat().reduced (1.0f);
    const auto col = catColour (p.cat);
    const bool sel = ed.proc.selectedPad == index;
    const bool has = ed.proc.padSample (index) != nullptr;

    // rubber pad, lit from underneath when hit
    g.setGradientFill (juce::ColourGradient (t.cardHi.brighter (0.05f), r.getX(), r.getY(), t.cardDark, r.getX(), r.getBottom(), false));
    g.fillRoundedRectangle (r, 9.0f);
    if (glow > 0.01f)
    {
        g.setColour (col.withAlpha (0.25f + 0.55f * glow));
        g.fillRoundedRectangle (r, 9.0f);
    }
    g.setColour (col.withAlpha (has ? 0.95f : 0.35f));
    g.fillRoundedRectangle (r.getX() + 10.0f, r.getBottom() - 9.0f, r.getWidth() - 20.0f, 3.0f, 1.5f);
    g.setColour (sel ? col : t.panelEdge.brighter (0.3f));
    g.drawRoundedRectangle (r, 9.0f, sel ? 2.2f : 1.0f);

    g.setFont (uiFont (9.5f, true));
    g.setColour (t.dim);
    g.drawText (juce::String (index + 1), r.reduced (9.0f, 6.0f), juce::Justification::topLeft);
    if (p.locked)
    {
        g.setColour (t.dim);
        juce::Path lk;
        const float lx = r.getRight() - 18.0f, ly = r.getY() + 8.0f;
        lk.addRoundedRectangle (lx, ly + 4.0f, 9.0f, 7.0f, 1.5f);
        g.fillPath (lk);
        g.drawRoundedRectangle (lx + 1.5f, ly, 6.0f, 9.0f, 3.0f, 1.4f);
    }
    g.setFont (uiFont (12.5f, true));
    g.setColour (t.text);
    g.drawFittedText (p.label, juce::Rectangle<int> ((int) r.getX() + 6, (int) r.getY() + 24, (int) r.getWidth() - 12, 18), juce::Justification::centred, 1);
    g.setFont (uiFont (10.0f));
    g.setColour (has ? t.text.withAlpha (0.7f) : t.color);
    g.drawFittedText (has ? shortName (p.path) : (p.path.isEmpty() ? juce::String ("EMPTY") : juce::String ("MISSING")),
                      juce::Rectangle<int> ((int) r.getX() + 6, (int) r.getY() + 46, (int) r.getWidth() - 12, 30), juce::Justification::centred, 2, 0.8f);
}

void PadButton::mouseDown (const juce::MouseEvent& e)
{
    ed.selectPad (index);
    // MPC-style: harder toward the top of the pad
    const int vel = juce::jlimit (40, 127, 127 - (int) (e.position.y / (float) getHeight() * 60.0f));
    ed.proc.hitPad (index, vel);
}

void PadButton::mouseDrag (const juce::MouseEvent& e)
{
    if (dragged || e.getDistanceFromDragStart() < 8) return;
    dragged = true;
    const juce::File f (ed.proc.kit().pads[(size_t) index].path);
    if (f.existsAsFile())   // drop the sound on FL's channel rack and it becomes a sampler channel
        juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
}

//==============================================================================
juce::File MidiDrag::make()
{
    return pad < 0 ? ed.proc.exportAll() : ed.proc.exportPad (pad);
}

void MidiDrag::paint (juce::Graphics& g)
{
    const auto& t = ed.theme();
    const bool have = pad < 0 ? ed.proc.recordedHits() > 0 : ed.proc.recordedHitsOn (pad) > 0;
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    g.setColour (have ? t.cardHi : t.cardDark);
    g.fillRoundedRectangle (r, 5.0f);
    juce::Path border, dashed;
    border.addRoundedRectangle (r, 5.0f);
    const float dashes[] = { 3.0f, 3.0f };
    juce::PathStrokeType (1.0f).createDashedStroke (dashed, border, dashes, 2);
    g.setColour (have ? t.home : t.faint);
    g.fillPath (dashed);
    g.setFont (uiFont (pad < 0 ? 11.5f : 10.0f, have));
    g.setColour (have ? t.text : t.dim);
    g.drawFittedText (text.isNotEmpty() ? text : juce::String ("DRAG"), getLocalBounds().reduced (6, 0), juce::Justification::centred, 1);
}

void MidiDrag::mouseDrag (const juce::MouseEvent& e)
{
    if (started || e.getDistanceFromDragStart() < 5) return;
    started = true;
    const auto f = make();
    if (f.existsAsFile())
        juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
}

void MidiDrag::mouseUp (const juce::MouseEvent&)
{
    if (! started)
    {
        const auto f = make();
        if (f.existsAsFile())
        {
            auto dir = Library::home().getChildFile ("MIDI");
            dir.createDirectory();
            auto dest = dir.getNonexistentChildFile (f.getFileNameWithoutExtension(), ".mid");
            if (f.copyFileTo (dest)) dest.revealToUser();
        }
    }
    started = false;
}

//==============================================================================
void SoundTile::paint (juce::Graphics& g)
{
    const auto& t = ed.theme();
    const int pad = ed.proc.selectedPad;
    const auto& p = ed.proc.kit().pads[(size_t) pad];
    const auto* s = ed.proc.padSample (pad);
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    g.setColour (t.cardDark);
    g.fillRoundedRectangle (r, 6.0f);
    g.setColour (t.panelEdge);
    g.drawRoundedRectangle (r, 6.0f, 1.0f);
    const auto col = catColour (p.cat);
    if (s != nullptr && ! s->peaks.empty())
    {
        const auto wave = r.reduced (10.0f, 22.0f).withTrimmedBottom (-12.0f);
        const float mid = wave.getCentreY(), half = wave.getHeight() * 0.5f;
        // DECAY shortens the sound: show where it fades
        const float d = p.decay;
        juce::Path path;
        const int n = (int) s->peaks.size();
        for (int i = 0; i < n; ++i)
        {
            const float x = wave.getX() + wave.getWidth() * (float) i / (float) (n - 1);
            float fade = 1.0f;
            if (d < 0.99f)
            {
                const double secs = (double) s->data.getNumSamples() / s->rate;
                const double tt = secs * (double) i / (double) (n - 1);
                const double dsec = 0.03 + (double) (d * d) * 2.5;
                fade = (float) std::pow (0.001, tt / dsec);
            }
            const float h = juce::jmax (0.5f, s->peaks[(size_t) i] * fade * half);
            path.addRectangle (x, mid - h, juce::jmax (1.0f, wave.getWidth() / (float) n), 2.0f * h);
        }
        g.setColour (col.withAlpha (0.85f));
        g.fillPath (path);
    }
    g.setFont (uiFont (11.0f, true));
    g.setColour (t.text);
    g.drawFittedText (s != nullptr ? shortName (p.path) : (p.path.isEmpty() ? juce::String ("No sound yet: ADD DRUM FOLDER below") : "Missing: " + shortName (p.path)),
                      getLocalBounds().reduced (10, 4).removeFromTop (16), juce::Justification::centredLeft, 1);
    if (s != nullptr)
    {
        g.setFont (uiFont (9.5f));
        g.setColour (t.dim);
        g.drawText (juce::String ((double) s->data.getNumSamples() / s->rate, 2) + " s  -  drag me into FL",
                    getLocalBounds().reduced (10, 4).removeFromBottom (14), juce::Justification::centredRight);
    }
}

void SoundTile::mouseDrag (const juce::MouseEvent& e)
{
    if (started || e.getDistanceFromDragStart() < 6) return;
    started = true;
    const juce::File f (ed.proc.kit().pads[(size_t) ed.proc.selectedPad].path);
    if (f.existsAsFile())
        juce::DragAndDropContainer::performExternalDragDropOfFiles ({ f.getFullPathName() }, false, this);
}

//==============================================================================
DrumEditor::DrumEditor (DrumProcessor& p) : AudioProcessorEditor (p), proc (p)
{
    look.setTheme (themeFor (2));
    setLookAndFeel (&look);
    addAndMakeVisible (canvas);
    canvas.setBounds (0, 0, baseW, baseH);
    canvas.painter = [this] (juce::Graphics& g) { paintCanvas (g); };
    canvas.click = [this] (const juce::MouseEvent& e)
    {
        // the category list: point the selected pad at that kind of sound and roll one
        for (int c = 0; c < numCats; ++c)
            if (catRect (c).contains (e.getPosition()))
            {
                changePad ([c] (PadSettings& s) { s.cat = c; });
                proc.dicePad (proc.selectedPad, true);
                return;
            }
    };

    // ---- pads
    for (int i = 0; i < numPads; ++i)
    {
        pads[(size_t) i] = std::make_unique<PadButton> (*this, i);
        pads[(size_t) i]->setTooltip ("Click to play. Drag the pad out onto FL's channel rack to drop its sound in as a sampler");
        canvas.addAndMakeVisible (*pads[(size_t) i]);
        padDice[(size_t) i] = std::make_unique<juce::TextButton> ("DICE");
        padDice[(size_t) i]->setTooltip ("Another sound of the same kind from your folder (prefers this genre's sounds)");
        padDice[(size_t) i]->onClick = [this, i] { selectPad (i); proc.dicePad (i, true); };
        canvas.addAndMakeVisible (*padDice[(size_t) i]);
        padDrag[(size_t) i] = std::make_unique<MidiDrag> (*this, i);
        padDrag[(size_t) i]->setTooltip ("Record (AUTO REC or REC), then drag this pad's MIDI onto its channel in FL. "
                                         "It's on C5, the note an FL sampler plays at normal pitch. Click to save it as a file");
        canvas.addAndMakeVisible (*padDrag[(size_t) i]);
        const auto c = padCell (i);
        pads[(size_t) i]->setBounds (c);
        padDice[(size_t) i]->setBounds (c.getX(), c.getBottom() + 4, 62, 20);
        padDrag[(size_t) i]->setBounds (c.getX() + 68, c.getBottom() + 4, 62, 20);
    }

    // ---- header
    kitBtn.setTooltip ("Your kits: load one, save this one, make one the default for a genre");
    kitBtn.onClick = [this] { showKitMenu(); };
    saveBtn.setTooltip ("Save this kit (your sounds and settings) for this genre");
    saveBtn.onClick = [this] { askKitName (false); };
    diceAllBtn.setTooltip ("DICE every pad that isn't locked: a whole new kit from your folder, in this genre");
    diceAllBtn.onClick = [this] { proc.diceAll(); };
    for (int g = 0; g < numGenres; ++g) genreBox.addItem (genreName (g), g + 1);
    genreBox.setTooltip ("The genre: loads your default kit for it, or builds one from your folder (sounds from folders named "
                         "like the genre come first)");
    genreBox.onChange = [this]
    {
        const int g = genreBox.getSelectedId() - 1;
        if (g >= 0 && g != proc.genre()) proc.setGenre (g);
    };
    followBtn.setTooltip ("FOLLOW VESPER: when you change the genre on VESPER's BAND tab, VESPER DRUMS changes with it");
    followBtn.onClick = [this] { proc.follow = followBtn.getToggleState(); };
    for (juce::Component* c : { (juce::Component*) &kitBtn, (juce::Component*) &saveBtn, (juce::Component*) &diceAllBtn,
                                (juce::Component*) &genreBox, (juce::Component*) &followBtn })
        canvas.addAndMakeVisible (c);

    // ---- selected pad
    padName.setEditable (false, true, false);
    padName.setFont (uiFont (17.0f, true));
    padName.setTooltip ("Double-click to rename the pad");
    padName.onTextChange = [this] { const auto t = padName.getText().toUpperCase(); changePad ([t] (PadSettings& s) { s.label = t; }); };
    for (int c = 0; c < numCats; ++c) catBox.addItem (catName (c), c + 1);
    catBox.setTooltip ("SOUND TYPE: what kind of sound this pad takes. DICE and < > pull from it");
    catBox.onChange = [this] { if (updating) return; const int c = catBox.getSelectedId() - 1; changePad ([c] (PadSettings& s) { s.cat = c; }); };
    chokeBox.addItem ("NO CHOKE", 1);
    for (int c = 1; c <= 4; ++c) chokeBox.addItem ("CHOKE " + juce::String (c), c + 1);
    chokeBox.setTooltip ("Pads in the same choke group cut each other off, like a closed hat stopping the open hat");
    chokeBox.onChange = [this] { if (updating) return; const int c = chokeBox.getSelectedId() - 1; changePad ([c] (PadSettings& s) { s.choke = c; }); };
    for (int n = 0; n < 128; ++n) noteBox.addItem (juce::String (n) + "  " + juce::MidiMessage::getMidiNoteName (n, true, true, 5), n + 1);
    noteBox.setTooltip ("The MIDI note that plays this pad. VESPER's drums use the standard drum notes (kick 36, snare 38, closed hat 42...)");
    noteBox.onChange = [this] { if (updating) return; const int n = noteBox.getSelectedId() - 1; changePad ([n] (PadSettings& s) { s.note = n; }); };
    lockBtn.setTooltip ("LOCK: DICE KIT and genre changes leave this pad alone");
    lockBtn.onClick = [this] { const bool l = lockBtn.getToggleState(); changePad ([l] (PadSettings& s) { s.locked = l; }); };
    prevBtn.setTooltip ("The previous sound of this kind in your folder");
    nextBtn.setTooltip ("The next sound of this kind in your folder");
    prevBtn.onClick = [this] { proc.stepPad (proc.selectedPad, -1); };
    nextBtn.onClick = [this] { proc.stepPad (proc.selectedPad, 1); };
    diceBtn.setTooltip ("A random sound of this kind");
    diceBtn.onClick = [this] { proc.dicePad (proc.selectedPad, true); };
    sound.setTooltip ("The pad's sound. Drag it onto FL's channel rack to drop it in as a sampler");
    auto knob = [this] (juce::Slider& k, double lo, double hi, double step, const juce::String& tip)
    {
        k.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        k.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        k.setRange (lo, hi, step);
        k.setTooltip (tip);
        canvas.addAndMakeVisible (k);
    };
    knob (tuneKnob, -24.0, 24.0, 0.1, "TUNE: pitch in semitones");
    knob (decayKnob, 0.02, 1.0, 0.001, "DECAY: all the way up plays the whole sound, lower makes it shorter and tighter");
    knob (levelKnob, 0.0, 1.0, 0.001, "LEVEL: this pad's volume");
    knob (panKnob, -1.0, 1.0, 0.01, "PAN: left / right");
    tuneKnob.setDoubleClickReturnValue (true, 0.0);
    panKnob.setDoubleClickReturnValue (true, 0.0);
    decayKnob.setDoubleClickReturnValue (true, 1.0);
    levelKnob.setDoubleClickReturnValue (true, 0.8);
    tuneKnob.onValueChange = [this] { if (updating) return; const float v = (float) tuneKnob.getValue(); changePad ([v] (PadSettings& s) { s.tune = v; }); };
    decayKnob.onValueChange = [this] { if (updating) return; const float v = (float) decayKnob.getValue(); changePad ([v] (PadSettings& s) { s.decay = v; }); };
    levelKnob.onValueChange = [this] { if (updating) return; const float v = (float) levelKnob.getValue(); changePad ([v] (PadSettings& s) { s.level = v; }); };
    panKnob.onValueChange = [this] { if (updating) return; const float v = (float) panKnob.getValue(); changePad ([v] (PadSettings& s) { s.pan = v; }); };
    for (juce::Component* c : { (juce::Component*) &padName, (juce::Component*) &catBox, (juce::Component*) &chokeBox,
                                (juce::Component*) &noteBox, (juce::Component*) &lockBtn, (juce::Component*) &prevBtn,
                                (juce::Component*) &nextBtn, (juce::Component*) &diceBtn, (juce::Component*) &sound })
        canvas.addAndMakeVisible (c);

    // ---- library
    addFolderBtn.setTooltip ("Point VESPER DRUMS at your drum folder (add as many as you like). It sorts every sound into "
                             "kicks, snares, claps, hats... from the file and folder names");
    addFolderBtn.onClick = [this] { addFolder(); };
    rescanBtn.setTooltip ("Scan your drum folders again (after adding new sounds)");
    rescanBtn.onClick = [this] { if (proc.library.roots().size() > 0) proc.library.scan (proc.library.roots()); };
    canvas.addAndMakeVisible (addFolderBtn);
    canvas.addAndMakeVisible (rescanBtn);

    // ---- footer
    recBtn.setClickingTogglesState (true);
    recBtn.setTooltip ("Record what the pads play, then drag it into FL");
    recBtn.onClick = [this] { proc.recording.store (recBtn.getToggleState()); };
    autoRecBtn.setToggleState (proc.autoRec.load(), juce::dontSendNotification);
    autoRecBtn.setTooltip ("Records automatically whenever you record in FL, lined up with your song");
    autoRecBtn.onClick = [this] { proc.autoRec.store (autoRecBtn.getToggleState()); };
    clearBtn.onClick = [this] { proc.clearRecording(); };
    savePadsBtn.setTooltip ("Saves each pad's MIDI and its sound into Documents\\VESPER DRUMS\\Takes and opens the folder: "
                            "drop the sound on the channel rack, then its MIDI on that channel");
    savePadsBtn.onClick = [this] { const auto d = proc.savePadsFolder(); if (d.isDirectory()) d.startAsProcess(); };
    dragAll.setTooltip ("Every pad as its own track. Drop it on an empty spot in FL (or File > Import > MIDI file) and tick "
                        "\"Create one channel per track\"");
    masterKnob.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    masterKnob.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    masterKnob.setTooltip ("MASTER volume");
    masterAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, "master", masterKnob);
    masterKnob.onValueChange = [this] { canvas.repaint (800, 600, 160, 70); };
    static const char* sizeNames[] = { "S", "M", "L" };
    for (int i = 0; i < 3; ++i)
    {
        sizeBtns[i].setButtonText (sizeNames[i]);
        sizeBtns[i].onClick = [this, i] { applyScale (i); };
        canvas.addAndMakeVisible (sizeBtns[i]);
    }
    for (juce::Component* c : { (juce::Component*) &recBtn, (juce::Component*) &autoRecBtn, (juce::Component*) &clearBtn,
                                (juce::Component*) &savePadsBtn, (juce::Component*) &dragAll, (juce::Component*) &masterKnob })
        canvas.addAndMakeVisible (c);

    for (int c = 0; c < numCats; ++c) catCounts[(size_t) c] = proc.library.count (c);
    lastLib = proc.library.changed.load();
    lastAround = proc.vesperAround();
    layout();
    selectPad (proc.selectedPad);
    applyScale (1);
    startTimerHz (30);
}

DrumEditor::~DrumEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

void DrumEditor::applyScale (int s)
{
    uiScale = juce::jlimit (0, 2, s);
    static const float scales[3] = { 0.8f, 1.0f, 1.2f };
    const float k = scales[uiScale];
    canvas.setTransform (juce::AffineTransform::scale (k));
    setSize ((int) std::round (baseW * k), (int) std::round (baseH * k));
    for (int i = 0; i < 3; ++i) sizeBtns[i].setToggleState (i == uiScale, juce::dontSendNotification);
}

void DrumEditor::layout()
{
    kitBtn.setBounds (232, 26, 250, 28);
    saveBtn.setBounds (488, 26, 80, 28);
    diceAllBtn.setBounds (574, 26, 82, 28);
    genreBox.setBounds (672, 26, 170, 28);
    followBtn.setBounds (850, 26, 132, 28);

    padName.setBounds (614, 82, 236, 28);
    lockBtn.setBounds (948, 84, 82, 24);
    catBox.setBounds (616, 132, 152, 24);
    chokeBox.setBounds (774, 132, 110, 24);
    noteBox.setBounds (890, 132, 140, 24);
    prevBtn.setBounds (616, 166, 30, 26);
    nextBtn.setBounds (650, 166, 30, 26);
    diceBtn.setBounds (684, 166, 70, 26);
    sound.setBounds (616, 198, 414, 96);
    tuneKnob.setBounds (630, 308, 42, 42);
    decayKnob.setBounds (734, 308, 42, 42);
    levelKnob.setBounds (838, 308, 42, 42);
    panKnob.setBounds (942, 308, 42, 42);

    addFolderBtn.setBounds (616, 404, 150, 26);
    rescanBtn.setBounds (772, 404, 76, 26);

    recBtn.setBounds (28, 622, 70, 32);
    autoRecBtn.setBounds (104, 626, 108, 24);
    dragAll.setBounds (218, 622, 330, 32);
    savePadsBtn.setBounds (554, 622, 96, 32);
    clearBtn.setBounds (656, 622, 70, 32);
    masterKnob.setBounds (760, 616, 44, 44);
    for (int i = 0; i < 3; ++i) sizeBtns[i].setBounds (958 + i * 30, 624, 26, 26);
}

juce::Rectangle<int> DrumEditor::catRect (int cat) const
{
    const int col = cat % 3, row = cat / 3;
    return { 616 + col * 139, 440 + row * 23, 135, 20 };
}

void DrumEditor::paintCanvas (juce::Graphics& g)
{
    const auto& t = theme();
    g.setGradientFill (juce::ColourGradient (t.bgTop, 0.0f, 0.0f, t.bgBottom, 0.0f, (float) baseH, false));
    g.fillAll();

    // logo
    const juce::Rectangle<float> logo (22.0f, 18.0f, 32.0f, 32.0f);
    g.setGradientFill (juce::ColourGradient (t.silver.brighter (0.3f), logo.getX(), logo.getY(), t.silver.darker (0.5f), logo.getRight(), logo.getBottom(), false));
    g.fillRoundedRectangle (logo, 7.0f);
    g.setColour (t.bgBottom);
    for (int r = 0; r < 2; ++r)
        for (int c = 0; c < 2; ++c)
            g.fillRoundedRectangle (logo.getX() + 7.0f + (float) c * 10.0f, logo.getY() + 7.0f + (float) r * 10.0f, 8.0f, 8.0f, 2.0f);
    g.setColour (catColour (CatKick));
    g.fillRoundedRectangle (logo.getX() + 7.0f, logo.getY() + 17.0f, 8.0f, 8.0f, 2.0f);
    g.setFont (uiFont (20.0f, true).withExtraKerningFactor (0.2f));
    g.setColour (t.text);
    g.drawText ("VESPER", juce::Rectangle<float> (64.0f, 14.0f, 160.0f, 24.0f), juce::Justification::centredLeft);
    g.setFont (uiFont (9.5f, true).withExtraKerningFactor (0.4f));
    g.setColour (catColour (CatKick).brighter (0.2f));
    g.drawText ("DRUMS", juce::Rectangle<float> (65.0f, 37.0f, 160.0f, 12.0f), juce::Justification::centredLeft);

    drawCaption (g, { 232.0f, 12.0f, 250.0f, 12.0f }, "KIT", t);
    drawCaption (g, { 672.0f, 12.0f, 170.0f, 12.0f }, "GENRE", t);
    // link light: is a VESPER around?
    const bool around = lastAround;
    const juce::Rectangle<float> led (988.0f, 36.0f, 8.0f, 8.0f);
    g.setColour (around ? t.home : t.cardDark);
    g.fillEllipse (led);
    g.setColour (t.panelEdge);
    g.drawEllipse (led, 1.0f);
    g.setFont (uiFont (9.0f, true));
    g.setColour (around ? t.text : t.dim);
    g.drawFittedText (around ? "VESPER\nLINKED" : "NO\nVESPER", juce::Rectangle<int> (1000, 26, 52, 28), juce::Justification::centredLeft, 2);

    drawPanel (g, { 16.0f, 72.0f, 576.0f, 524.0f }, t);
    drawPanel (g, { 604.0f, 72.0f, 440.0f, 524.0f }, t);

    // selected pad
    const int sel = proc.selectedPad;
    const auto& p = proc.kit().pads[(size_t) sel];
    g.setFont (uiFont (10.0f, true));
    g.setColour (catColour (p.cat));
    g.drawText ("PAD " + juce::String (sel + 1), juce::Rectangle<float> (856.0f, 84.0f, 86.0f, 24.0f), juce::Justification::centredRight);
    drawCaption (g, { 616.0f, 118.0f, 152.0f, 12.0f }, "SOUND TYPE", t);
    drawCaption (g, { 774.0f, 118.0f, 110.0f, 12.0f }, "CHOKE", t);
    drawCaption (g, { 890.0f, 118.0f, 140.0f, 12.0f }, "NOTE", t);
    g.setFont (uiFont (10.0f));
    g.setColour (t.dim);
    g.drawText ("flip through your " + juce::String (catName (p.cat)).toLowerCase() + " sounds", juce::Rectangle<float> (762.0f, 166.0f, 268.0f, 26.0f),
                juce::Justification::centredLeft);
    auto knobLabel = [&] (float x, const juce::String& name, const juce::String& value)
    {
        drawCaption (g, { x, 350.0f, 90.0f, 12.0f }, name, t, juce::Justification::centred);
        g.setFont (uiFont (11.0f, true));
        g.setColour (t.text);
        g.drawText (value, juce::Rectangle<float> (x, 362.0f, 90.0f, 16.0f), juce::Justification::centred);
    };
    knobLabel (606.0f, "TUNE", (p.tune >= 0 ? "+" : "") + juce::String (p.tune, 1) + " st");
    knobLabel (710.0f, "DECAY", p.decay >= 0.99f ? juce::String ("FULL") : juce::String (juce::roundToInt (p.decay * 100.0f)) + "%");
    knobLabel (814.0f, "LEVEL", juce::String (juce::roundToInt (p.level * 100.0f)) + "%");
    knobLabel (918.0f, "PAN", std::abs (p.pan) < 0.01f ? juce::String ("C") : (p.pan < 0 ? "L" : "R") + juce::String (juce::roundToInt (std::abs (p.pan) * 100.0f)));

    // the library
    g.setColour (t.panelEdge);
    g.drawLine (616.0f, 390.0f, 1030.0f, 390.0f, 1.0f);
    drawCaption (g, { 616.0f, 392.0f, 300.0f, 12.0f }, "YOUR DRUMS", t);
    g.setFont (uiFont (10.5f, true));
    juce::String status;
    if (proc.library.scanning()) status = "Sorting... " + juce::String (proc.library.scannedSoFar()) + " sounds";
    else if (proc.library.size() == 0) status = "No folder yet";
    else status = juce::String (proc.library.size()) + " sounds";
    g.setColour (proc.library.size() == 0 && ! proc.library.scanning() ? t.color : t.text);
    g.drawFittedText (status, juce::Rectangle<int> (854, 404, 176, 26), juce::Justification::centredLeft, 1);
    for (int c = 0; c < numCats; ++c)
    {
        const auto r = catRect (c).toFloat();
        const bool on = c == p.cat;
        g.setColour (on ? catColour (c).withAlpha (0.28f) : t.cardDark);
        g.fillRoundedRectangle (r, 4.0f);
        g.setColour (catColour (c).withAlpha (on ? 1.0f : 0.7f));
        g.fillRoundedRectangle (r.getX() + 5.0f, r.getCentreY() - 3.0f, 6.0f, 6.0f, 3.0f);
        g.setFont (uiFont (9.5f, on));
        g.setColour (on ? t.text : t.text.withAlpha (0.75f));
        g.drawText (catName (c), r.withTrimmedLeft (15.0f), juce::Justification::centredLeft);
        g.setColour (t.dim);
        g.drawText (juce::String (catCounts[(size_t) c]), r.withTrimmedRight (6.0f), juce::Justification::centredRight);
    }
    g.setFont (uiFont (9.5f));
    g.setColour (t.dim);
    g.drawFittedText ("Click a kind of sound to put it on the selected pad.", juce::Rectangle<int> (616, 576, 414, 14), juce::Justification::centredLeft, 1);

    // footer
    drawPanel (g, { 16.0f, 606.0f, 1028.0f, 82.0f }, t);
    drawCaption (g, { 808.0f, 624.0f, 70.0f, 12.0f }, "MASTER", t);
    g.setFont (uiFont (11.0f, true));
    g.setColour (t.text);
    g.drawText (juce::String (masterKnob.getValue(), 1) + " dB", juce::Rectangle<float> (808.0f, 638.0f, 80.0f, 16.0f), juce::Justification::centredLeft);
    drawCaption (g, { 924.0f, 624.0f, 32.0f, 26.0f }, "SIZE", t);
    g.setFont (uiFont (10.0f));
    g.setColour (t.dim);
    g.drawFittedText ("Each pad's DRAG = its MIDI on C5 (drop the pad's sound on the channel rack, then its MIDI on that channel). "
                      "Drag a pad itself to drop its sound.", juce::Rectangle<int> (28, 660, 900, 22), juce::Justification::centredLeft, 1);
}

void DrumEditor::selectPad (int i)
{
    proc.selectedPad = juce::jlimit (0, numPads - 1, i);
    refreshPad();
    for (auto& pb : pads) pb->repaint();
    canvas.repaint();
}

void DrumEditor::refreshPad()
{
    const juce::ScopedValueSetter<bool> svs (updating, true);
    const auto& p = proc.kit().pads[(size_t) proc.selectedPad];
    padName.setText (p.label, juce::dontSendNotification);
    padName.setColour (juce::Label::textColourId, theme().text);
    catBox.setSelectedId (p.cat + 1, juce::dontSendNotification);
    chokeBox.setSelectedId (p.choke + 1, juce::dontSendNotification);
    noteBox.setSelectedId (p.note + 1, juce::dontSendNotification);
    lockBtn.setToggleState (p.locked, juce::dontSendNotification);
    tuneKnob.setValue (p.tune, juce::dontSendNotification);
    decayKnob.setValue (p.decay, juce::dontSendNotification);
    levelKnob.setValue (p.level, juce::dontSendNotification);
    panKnob.setValue (p.pan, juce::dontSendNotification);
    kitBtn.setButtonText (proc.kit().name);
    genreBox.setSelectedId (proc.genre() + 1, juce::dontSendNotification);
    followBtn.setToggleState (proc.follow, juce::dontSendNotification);
    sound.repaint();
}

void DrumEditor::changePad (std::function<void (PadSettings&)> f)
{
    if (updating) return;
    auto s = proc.kit().pads[(size_t) proc.selectedPad];
    f (s);
    proc.setPadSettings (proc.selectedPad, s);
    pads[(size_t) proc.selectedPad]->repaint();
    canvas.repaint (604, 72, 440, 524);
    sound.repaint();
}

void DrumEditor::showKitMenu()
{
    juce::PopupMenu m, all;
    const int g = proc.genre();
    m.addSectionHeader ("KITS FOR " + juce::String (genreName (g)));
    const auto mine = kitsFor (g);
    const auto def = defaultKitFor (g);
    std::vector<juce::File> files;
    for (const auto& f : mine)
    {
        files.push_back (f);
        m.addItem ((int) files.size(), f.getFileNameWithoutExtension() + (f == def ? "  (default)" : ""), true, f.getFullPathName() == proc.kitFile);
    }
    if (mine.isEmpty()) m.addItem (-1, "(no kits saved for this genre yet)", false);
    for (int og = 0; og < numGenres; ++og)
    {
        if (og == g) continue;
        juce::PopupMenu sub;
        for (const auto& f : kitsFor (og)) { files.push_back (f); sub.addItem ((int) files.size(), f.getFileNameWithoutExtension()); }
        if (sub.getNumItems() > 0) all.addSubMenu (genreName (og), sub);
    }
    if (all.getNumItems() > 0) m.addSubMenu ("OTHER GENRES", all);
    m.addSeparator();
    m.addItem (1001, "Save kit as...");
    m.addItem (1002, "Save as the default " + juce::String (genreName (g)) + " kit...");
    m.addItem (1003, "Fresh " + juce::String (genreName (g)) + " kit from my folder", proc.library.size() > 0);
    m.addItem (1004, "Open the kits folder");
    juce::Component::SafePointer<DrumEditor> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&kitBtn), [safe, files] (int r)
    {
        if (safe == nullptr || r == 0) return;
        auto& p = safe->proc;
        if (r == 1001) safe->askKitName (false);
        else if (r == 1002) safe->askKitName (true);
        else if (r == 1003) p.buildKit (p.genre(), true);
        else if (r == 1004) { kitsFolder().createDirectory(); kitsFolder().startAsProcess(); }
        else if (r >= 1 && r <= (int) files.size()) p.loadKitFile (files[(size_t) (r - 1)]);
        safe->refreshPad();
    });
}

void DrumEditor::askKitName (bool makeDefault)
{
    auto* w = new juce::AlertWindow (makeDefault ? "Save the default kit" : "Save kit",
                                     makeDefault ? "Name it. It loads whenever you pick " + juce::String (genreName (proc.genre())) + "."
                                                 : "Name your kit (saved under " + juce::String (genreName (proc.genre())) + ")",
                                     juce::MessageBoxIconType::NoIcon, this);
    w->addTextEditor ("name", proc.kit().name, "Name");
    w->addButton ("SAVE", 1, juce::KeyPress (juce::KeyPress::returnKey));
    w->addButton ("CANCEL", 0, juce::KeyPress (juce::KeyPress::escapeKey));
    juce::Component::SafePointer<DrumEditor> safe (this);
    w->enterModalState (true, juce::ModalCallbackFunction::create ([safe, w, makeDefault] (int r)
    {
        if (safe != nullptr && r == 1)
        {
            safe->proc.saveKit (w->getTextEditorContents ("name"), makeDefault);
            safe->refreshPad();
        }
    }), true);
}

void DrumEditor::addFolder()
{
    chooser = std::make_unique<juce::FileChooser> ("Pick your drum folder", juce::File::getSpecialLocation (juce::File::userDocumentsDirectory));
    juce::Component::SafePointer<DrumEditor> safe (this);
    chooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectDirectories, [safe] (const juce::FileChooser& fc)
    {
        if (safe == nullptr) return;
        const auto dir = fc.getResult();
        if (! dir.isDirectory()) return;
        auto roots = safe->proc.library.roots();
        roots.addIfNotAlreadyThere (dir.getFullPathName());
        safe->proc.library.scan (roots);
    });
}

void DrumEditor::timerCallback()
{
    for (int i = 0; i < numPads; ++i)
    {
        auto& pb = *pads[(size_t) i];
        const auto h = proc.padHits[(size_t) i].load();
        if (h != pb.lastHits) { pb.lastHits = h; pb.glow = juce::jlimit (0.3f, 1.0f, (float) proc.padVel[(size_t) i].load() / 127.0f); pb.repaint(); }
        else if (pb.glow > 0.0f) { pb.glow = juce::jmax (0.0f, pb.glow - 0.12f); pb.repaint(); }
    }
    const auto k = proc.kitChanged.load();
    if (k != lastKit)
    {
        lastKit = k;
        refreshPad();
        for (auto& pb : pads) pb->repaint();
        canvas.repaint();
    }
    const auto lib = proc.library.changed.load();
    const int scan = proc.library.scanning() ? proc.library.scannedSoFar() : -1;
    if (lib != lastLib || scan != lastScan)
    {
        if (lib != lastLib) for (int c = 0; c < numCats; ++c) catCounts[(size_t) c] = proc.library.count (c);
        lastLib = lib;
        lastScan = scan;
        canvas.repaint (604, 380, 440, 216);
    }
    const int recN = proc.recordedHits();
    if (recN != lastRec)
    {
        lastRec = recN;
        dragAll.text = recN > 0 ? "DRAG ALL PADS  -  " + juce::String (recN) + " hits" : "DRAG ALL PADS  (record first)";
        dragAll.repaint();
        for (auto& d : padDrag) d->repaint();
    }
    recBtn.setToggleState (proc.recording.load(), juce::dontSendNotification);
    if (++ticks % 30 == 1)   // once a second is plenty for the link light
    {
        const bool around = proc.vesperAround();
        if (around != lastAround) { lastAround = around; canvas.repaint (980, 20, 80, 40); }
    }
}
} // namespace drums
