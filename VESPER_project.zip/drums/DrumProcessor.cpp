#include "DrumProcessor.h"
#include "DrumEditor.h"

#include <cmath>

namespace drums
{
static juce::File vesperLinkFile()
{
    // written by VESPER (VesperProcessor::drumLinkFile)
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("VESPER").getChildFile ("drum-link.xml");
}

static juce::AudioProcessorValueTreeState::ParameterLayout drumLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;
    p.push_back (std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { "master", 1 }, "Master",
                                                              juce::NormalisableRange<float> (-48.0f, 6.0f, 0.1f, 2.0f), 0.0f,
                                                              juce::AudioParameterFloatAttributes().withLabel ("dB")));
    return { p.begin(), p.end() };
}

DrumProcessor::DrumProcessor()
    : AudioProcessor (BusesProperties().withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", drumLayout())
{
    formats.registerBasicFormats();
    rec.resize (1 << 17);
    for (auto& h : padHits) h.store (0);
    for (auto& v : padVel) v.store (0);
    for (auto& n : noteToPad) n.store (-1);
    rebuildNoteMap();
    library.loadIndex();
    if (library.size() > 0) buildKit (genreNow, false);
    startTimer (400);
}

DrumProcessor::~DrumProcessor()
{
    stopTimer();
    for (auto& v : voices) v.active = false;
}

bool DrumProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::stereo() && out != juce::AudioChannelSet::mono()) return false;
    return layouts.getMainInputChannelSet().isDisabled();
}

void DrumProcessor::prepareToPlay (double sampleRate, int)
{
    sr = sampleRate > 0 ? sampleRate : 44100.0;
    for (auto& v : voices) if (v.active) endVoice (v);
}

//==============================================================================
// sounds
std::unique_ptr<Sample> DrumProcessor::loadSample (const juce::String& path)
{
    const juce::File f (path);
    if (path.isEmpty() || ! f.existsAsFile()) return nullptr;
    std::unique_ptr<juce::AudioFormatReader> r (formats.createReaderFor (f));
    if (r == nullptr || r->sampleRate <= 0 || r->lengthInSamples <= 0) return nullptr;
    const auto maxLen = (juce::int64) (r->sampleRate * 12.0);   // drums: 12 seconds is plenty
    const int len = (int) juce::jmin (r->lengthInSamples, maxLen);
    auto s = std::make_unique<Sample>();
    s->path = path;
    s->rate = r->sampleRate;
    s->data.setSize (2, len + 1);
    s->data.clear();
    r->read (&s->data, 0, len, 0, true, r->numChannels > 1);
    if (r->numChannels < 2) s->data.copyFrom (1, 0, s->data, 0, 0, len);
    // waveform
    s->peaks.assign (256, 0.0f);
    float maxPeak = 0.0f;
    for (int i = 0; i < 256; ++i)
    {
        const int a = (int) ((juce::int64) len * i / 256), b = juce::jmax (a + 1, (int) ((juce::int64) len * (i + 1) / 256));
        float m = 0.0f;
        for (int k = a; k < b && k < len; ++k) m = juce::jmax (m, std::abs (s->data.getSample (0, k)), std::abs (s->data.getSample (1, k)));
        s->peaks[(size_t) i] = m;
        maxPeak = juce::jmax (maxPeak, m);
    }
    if (maxPeak > 0.0f) for (auto& p : s->peaks) p /= maxPeak;
    return s;
}

void DrumProcessor::installSample (int pad, std::unique_ptr<Sample> s)
{
    Sample* next = s.get();
    if (s != nullptr) owned.push_back (std::move (s));
    Sample* old = live[(size_t) pad].sample.exchange (next);
    if (old != nullptr) retired.push_back ({ old, juce::Time::getMillisecondCounterHiRes() });
}

void DrumProcessor::pushPad (int pad)
{
    const auto& p = current.pads[(size_t) pad];
    auto& l = live[(size_t) pad];
    l.level.store (p.level);
    l.pan.store (p.pan);
    l.tune.store (p.tune);
    l.decay.store (p.decay);
    l.choke.store (p.choke);
}

void DrumProcessor::rebuildNoteMap()
{
    std::array<int, 128> m;
    m.fill (-1);
    for (int i = numPads - 1; i >= 0; --i) m[(size_t) juce::jlimit (0, 127, current.pads[(size_t) i].note)] = i;
    // other standard drum notes go to the pad that plays the closest sound
    static const int extra[][2] = { { 35, 36 }, { 40, 38 }, { 41, 45 }, { 43, 45 }, { 48, 50 }, { 52, 49 }, { 55, 49 }, { 57, 49 },
                                    { 53, 51 }, { 59, 51 }, { 56, 63 }, { 75, 63 }, { 76, 63 }, { 77, 64 }, { 62, 63 }, { 60, 63 },
                                    { 61, 64 }, { 69, 70 }, { 82, 70 }, { 58, 63 } };
    for (const auto& e : extra)
        if (m[(size_t) e[0]] < 0 && m[(size_t) e[1]] >= 0) m[(size_t) e[0]] = m[(size_t) e[1]];
    for (int n = 0; n < 128; ++n) noteToPad[(size_t) n].store (m[(size_t) n]);
}

void DrumProcessor::setPadSettings (int pad, const PadSettings& s)
{
    if (pad < 0 || pad >= numPads) return;
    const auto path = current.pads[(size_t) pad].path;
    current.pads[(size_t) pad] = s;
    current.pads[(size_t) pad].path = path;
    pushPad (pad);
    rebuildNoteMap();
    kitChanged.fetch_add (1);
}

void DrumProcessor::setPadSample (int pad, const juce::String& path, bool audition)
{
    if (pad < 0 || pad >= numPads) return;
    current.pads[(size_t) pad].path = path;
    installSample (pad, loadSample (path));
    pushPad (pad);
    kitChanged.fetch_add (1);
    if (audition) hitPad (pad, 100);
}

const Sample* DrumProcessor::padSample (int pad) const
{
    if (pad < 0 || pad >= numPads) return nullptr;
    return live[(size_t) pad].sample.load();
}

juce::String DrumProcessor::pickFor (int pad, int g, const juce::String& avoid)
{
    // if your folder has none of this kind of sound, the closest kind that it does have
    static const int fallback[numCats][3] = {
        { CatKick, Cat808, -1 },        { CatSnare, CatClap, CatRim },     { CatClap, CatSnap, CatSnare },
        { CatSnap, CatClap, -1 },       { CatRim, CatSnare, CatPerc },     { CatClosedHat, CatShaker, CatRide },
        { CatOpenHat, CatClosedHat, CatCrash }, { CatRide, CatCrash, CatClosedHat }, { CatCrash, CatRide, CatOpenHat },
        { CatTom, CatPerc, -1 },        { CatPerc, CatTom, CatShaker },    { CatShaker, CatTambourine, CatPerc },
        { CatTambourine, CatShaker, CatPerc }, { Cat808, CatKick, -1 },   { CatFx, -1, -1 },
        { CatVox, -1, -1 },             { CatOther, -1, -1 } };
    juce::Random r (juce::Time::currentTimeMillis() + pad * 7919);
    const int cat = juce::jlimit (0, numCats - 1, current.pads[(size_t) pad].cat);
    for (int c : fallback[cat])
    {
        if (c < 0) continue;
        const auto p = library.pick (c, g, r, avoid);
        if (p.isNotEmpty()) return p;
    }
    return {};
}

void DrumProcessor::dicePad (int pad, bool audition)
{
    if (pad < 0 || pad >= numPads) return;
    const auto p = pickFor (pad, genreNow, current.pads[(size_t) pad].path);
    if (p.isNotEmpty()) setPadSample (pad, p, audition);
}

void DrumProcessor::stepPad (int pad, int dir)
{
    if (pad < 0 || pad >= numPads) return;
    const auto p = library.step (current.pads[(size_t) pad].cat, current.pads[(size_t) pad].path, dir);
    if (p.isNotEmpty()) setPadSample (pad, p, true);
}

void DrumProcessor::diceAll()
{
    for (int i = 0; i < numPads; ++i)
        if (! current.pads[(size_t) i].locked) dicePad (i, false);
}

void DrumProcessor::buildKit (int g, bool keepLocked)
{
    for (int i = 0; i < numPads; ++i)
    {
        if (keepLocked && current.pads[(size_t) i].locked) continue;
        const auto p = pickFor (i, g, {});
        if (p.isNotEmpty()) setPadSample (i, p, false);
    }
    current.genre = g;
    current.name = juce::String (genreName (g)) + " KIT";
    kitFile = {};
    kitChanged.fetch_add (1);
}

void DrumProcessor::setGenre (int g)
{
    g = juce::jlimit (0, numGenres - 1, g);
    genreNow = g;
    const auto f = defaultKitFor (g);
    if (f.existsAsFile() && loadKitFile (f)) return;
    if (library.size() > 0) buildKit (g, true);
    kitChanged.fetch_add (1);
}

void DrumProcessor::loadKit (const Kit& k)
{
    for (int i = 0; i < numPads; ++i)
    {
        if (current.pads[(size_t) i].locked) continue;   // locked pads stay put
        const auto& np = k.pads[(size_t) i];
        const bool newSound = np.path != current.pads[(size_t) i].path || live[(size_t) i].sample.load() == nullptr;
        current.pads[(size_t) i] = np;
        if (newSound) installSample (i, loadSample (np.path));
        pushPad (i);
    }
    current.name = k.name;
    current.genre = k.genre;
    rebuildNoteMap();
    kitChanged.fetch_add (1);
}

bool DrumProcessor::loadKitFile (const juce::File& f)
{
    auto x = juce::XmlDocument::parse (f);
    Kit k;
    if (x == nullptr || ! kitFromXml (*x, k)) return false;
    loadKit (k);
    kitFile = f.getFullPathName();
    return true;
}

juce::File DrumProcessor::saveKit (const juce::String& name, bool makeDefault)
{
    current.name = name.trim().isEmpty() ? juce::String ("MY KIT") : name.trim();
    current.genre = genreNow;
    const auto dir = kitFolderFor (genreNow);
    dir.createDirectory();
    const auto f = dir.getChildFile (juce::File::createLegalFileName (current.name) + ".vdkit");
    if (auto x = kitToXml (current)) x->writeTo (f);
    if (makeDefault) setDefaultKitFor (genreNow, f);
    kitFile = f.getFullPathName();
    kitChanged.fetch_add (1);
    return f;
}

void DrumProcessor::hitPad (int pad, int velocity)
{
    int s1, z1, s2, z2;
    hitFifo.prepareToWrite (1, s1, z1, s2, z2);
    if (z1 + z2 == 0) return;
    hitQueue[(size_t) (z1 > 0 ? s1 : s2)] = { pad, velocity };
    hitFifo.finishedWrite (1);
}

bool DrumProcessor::vesperAround() const
{
    const auto f = vesperLinkFile();
    return f.existsAsFile() && (juce::Time::getCurrentTime() - f.getLastModificationTime()).inSeconds() < 15.0;
}

void DrumProcessor::timerCallback()
{
    // free sounds nobody plays any more
    const double now = juce::Time::getMillisecondCounterHiRes();
    for (int i = (int) retired.size() - 1; i >= 0; --i)
    {
        auto* s = retired[(size_t) i].s;
        if (now - retired[(size_t) i].at < 3000.0 || s->voices.load() > 0) continue;
        bool inUse = false;
        for (auto& l : live) if (l.sample.load() == s) inUse = true;
        if (! inUse)
            for (auto it = owned.begin(); it != owned.end(); ++it)
                if (it->get() == s) { owned.erase (it); break; }
        retired.erase (retired.begin() + i);
    }

    // follow VESPER's genre
    const auto f = vesperLinkFile();
    if (f.existsAsFile())
    {
        const auto t = f.getLastModificationTime();
        if (t != linkFileTime)
        {
            linkFileTime = t;
            if (auto x = juce::XmlDocument::parse (f))
            {
                const int g = x->getIntAttribute ("genre", -1);
                if (g >= 0 && g < numGenres)
                {
                    linkGenre = g;
                    if (follow && g != genreNow) setGenre (g);
                }
            }
        }
    }

    // a scan finished and the pads are empty: build a kit right away
    const auto ch = library.changed.load();
    if (ch != libSeen)
    {
        libSeen = ch;
        bool empty = true;
        for (auto& l : live) if (l.sample.load() != nullptr) empty = false;
        if (empty && library.size() > 0) buildKit (genreNow, true);
    }
}

//==============================================================================
// audio thread
void DrumProcessor::endVoice (Voice& v)
{
    if (v.active && v.s != nullptr) v.s->voices.fetch_sub (1);
    v.active = false;
    v.s = nullptr;
}

void DrumProcessor::trigger (int pad, int velocity, int offset)
{
    if (pad < 0 || pad >= numPads) return;
    auto& l = live[(size_t) pad];
    Sample* s = l.sample.load();
    padHits[(size_t) pad].fetch_add (1, std::memory_order_relaxed);
    padVel[(size_t) pad].store (velocity, std::memory_order_relaxed);
    if (s == nullptr) return;

    // choke: the closed hat cuts the open hat off
    const int choke = l.choke.load();
    int samePad = 0;
    for (auto& v : voices)
    {
        if (! v.active) continue;
        if (choke > 0 && v.pad != pad && live[(size_t) v.pad].choke.load() == choke) v.releasing = true;
        if (v.pad == pad && ! v.releasing) ++samePad;
    }
    if (samePad >= 4)   // four of the same pad at once is plenty: let the oldest go
    {
        Voice* oldest = nullptr;
        for (auto& v : voices) if (v.active && v.pad == pad && ! v.releasing && (oldest == nullptr || v.age < oldest->age)) oldest = &v;
        if (oldest != nullptr) oldest->releasing = true;
    }

    Voice* slot = nullptr;
    for (auto& v : voices) if (! v.active) { slot = &v; break; }
    if (slot == nullptr)
    {
        slot = &voices[0];
        for (auto& v : voices) if (v.age < slot->age) slot = &v;
        endVoice (*slot);
    }
    auto& v = *slot;
    v.active = true;
    v.pad = pad;
    v.s = s;
    s->voices.fetch_add (1);
    v.pos = 0.0;
    v.step = (s->rate / sr) * std::pow (2.0, (double) l.tune.load() / 12.0);
    const float vel = juce::jlimit (0.0f, 1.0f, (float) velocity / 127.0f);
    const float lvl = l.level.load();
    const float gain = lvl * lvl * 1.6f * (0.16f + 0.84f * std::pow (vel, 1.4f));
    const float pan = juce::jlimit (-1.0f, 1.0f, l.pan.load());
    const float ang = (pan + 1.0f) * juce::MathConstants<float>::pi * 0.25f;
    v.gl = gain * std::cos (ang) * juce::MathConstants<float>::sqrt2;
    v.gr = gain * std::sin (ang) * juce::MathConstants<float>::sqrt2;
    v.env = 1.0f;
    const float d = l.decay.load();
    if (d >= 0.99f) v.decayMul = 1.0f;
    else
    {
        const double seconds = 0.03 + (double) (d * d) * 2.5;            // to -60 dB
        v.decayMul = (float) std::exp (std::log (0.001) / (seconds * sr));
    }
    v.hold = (float) (0.004 * sr);
    v.releasing = false;
    v.age = ++voiceAge;
    v.startOffset = offset;
}

void DrumProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    buffer.clear();
    const int n = buffer.getNumSamples();

    double bpm = 120.0, ppq = 0.0;
    bool playing = false, hostRec = false, ppqValid = false;
    if (auto* ph = getPlayHead())
        if (auto pos = ph->getPosition())
        {
            if (auto b = pos->getBpm()) bpm = *b;
            playing = pos->getIsPlaying();
            hostRec = pos->getIsRecording();
            if (auto p = pos->getPpqPosition()) { ppq = *p; ppqValid = true; }
        }
    if (bpm < 20.0 || bpm > 999.0) bpm = 120.0;
    const double spb = sr * 60.0 / bpm;
    const bool synced = playing && ppqValid;
    const double blockBeat = synced ? ppq : freeBeat;
    freeBeat += n / spb;

    if (autoRec.load())
    {
        if (hostRec && ! lastHostRec) { recCount.store (0); recording.store (true); }
        else if (! hostRec && lastHostRec) recording.store (false);
    }
    lastHostRec = hostRec;
    if (clearRequested.exchange (false)) recCount.store (0);

    auto record = [&] (int pad, int vel, int pos)
    {
        if (! recording.load()) return;
        const int i = recCount.load (std::memory_order_relaxed);
        if (i >= (int) rec.size()) return;
        auto& e = rec[(size_t) i];
        e.beat = blockBeat + pos / spb;
        e.pad = (uint8_t) pad;
        e.vel = (uint8_t) juce::jlimit (1, 127, vel);
        e.synced = synced ? 1 : 0;
        recCount.store (i + 1, std::memory_order_release);
    };

    // clicks on the pads
    {
        int s1, z1, s2, z2;
        hitFifo.prepareToRead (hitFifo.getNumReady(), s1, z1, s2, z2);
        for (int i = 0; i < z1; ++i) { const auto h = hitQueue[(size_t) (s1 + i)]; trigger (h.first, h.second, 0); record (h.first, h.second, 0); }
        for (int i = 0; i < z2; ++i) { const auto h = hitQueue[(size_t) (s2 + i)]; trigger (h.first, h.second, 0); record (h.first, h.second, 0); }
        hitFifo.finishedRead (z1 + z2);
    }

    // MIDI: VESPER's drums, your keyboard, FL's piano roll
    struct Pending { int pad, vel, pos; };
    Pending pend[256];
    int np = 0;
    for (const auto meta : midi)
    {
        const auto m = meta.getMessage();
        const int pos = juce::jlimit (0, juce::jmax (0, n - 1), meta.samplePosition);
        if (m.isNoteOn())
        {
            const int pad = noteToPad[(size_t) m.getNoteNumber()].load();
            if (pad >= 0 && np < 256) pend[np++] = { pad, m.getVelocity(), pos };
        }
        else if (m.isAllNotesOff() || m.isAllSoundOff())
            for (auto& v : voices) if (v.active) v.releasing = true;
    }
    midi.clear();

    // render, starting each new hit exactly where it lands in the block
    float* L = buffer.getWritePointer (0);
    float* R = buffer.getNumChannels() > 1 ? buffer.getWritePointer (1) : nullptr;
    auto render = [&] (int from, int to)
    {
        for (auto& v : voices)
        {
            if (! v.active) continue;
            const int len = v.s->data.getNumSamples() - 1;
            const float* sl = v.s->data.getReadPointer (0);
            const float* srr = v.s->data.getReadPointer (1);
            const float relMul = (float) std::exp (std::log (0.001) / (0.006 * sr));
            for (int i = juce::jmax (from, v.startOffset); i < to; ++i)
            {
                const int idx = (int) v.pos;
                if (idx >= len) { endVoice (v); break; }
                const float fr = (float) (v.pos - idx);
                const float a = sl[idx] + fr * (sl[idx + 1] - sl[idx]);
                const float b = srr[idx] + fr * (srr[idx + 1] - srr[idx]);
                L[i] += a * v.gl * v.env;
                if (R != nullptr) R[i] += b * v.gr * v.env;
                else L[i] += b * v.gr * v.env;
                v.pos += v.step;
                if (v.releasing) v.env *= relMul;
                else if (v.hold > 0.0f) v.hold -= 1.0f;
                else v.env *= v.decayMul;
                if (v.env < 0.0005f) { endVoice (v); break; }
            }
            if (v.active) v.startOffset = 0;
        }
    };
    int cursor = 0;
    for (int i = 0; i < np; ++i)
    {
        if (pend[i].pos > cursor) { render (cursor, pend[i].pos); cursor = pend[i].pos; }
        trigger (pend[i].pad, pend[i].vel, pend[i].pos);
        record (pend[i].pad, pend[i].vel, pend[i].pos);
        // the new voice starts at its position: render from there (the others continue from cursor)
    }
    render (cursor, n);

    const float master = juce::Decibels::decibelsToGain (apvts.getRawParameterValue ("master")->load(), -48.0f);
    buffer.applyGain (master);
}

//==============================================================================
// recording -> MIDI files
int DrumProcessor::recordedHitsOn (int pad) const
{
    const int total = recCount.load (std::memory_order_acquire);
    int c = 0;
    for (int i = 0; i < total; ++i) if (rec[(size_t) i].pad == pad) ++c;
    return c;
}

bool DrumProcessor::writeTake (const juce::File& f, int onlyPad, bool asC5)
{
    const int total = recCount.load (std::memory_order_acquire);
    if (total == 0) return false;
    const bool synced = rec[0].synced != 0;
    const double start = synced ? 0.0 : std::floor (rec[0].beat);
    juce::MidiFile mf;
    mf.setTicksPerQuarterNote (960);
    int notes = 0;
    for (int pad = 0; pad < numPads; ++pad)
    {
        if (onlyPad >= 0 && pad != onlyPad) continue;
        juce::MidiMessageSequence seq;
        auto name = juce::MidiMessage::textMetaEvent (3, current.pads[(size_t) pad].label);
        name.setTimeStamp (0);
        seq.addEvent (name);
        const int note = asC5 ? 60 : juce::jlimit (0, 127, current.pads[(size_t) pad].note);
        const int ch = asC5 ? 1 : 10;
        double lastOn = -1.0;
        int here = 0;
        for (int i = 0; i < total; ++i)
        {
            const auto& e = rec[(size_t) i];
            if (e.pad != pad) continue;
            const double t = juce::jmax (0.0, std::round ((e.beat - start) * 960.0));
            if (t <= lastOn) continue;
            auto on = juce::MidiMessage::noteOn (ch, note, (juce::uint8) e.vel);
            on.setTimeStamp (t);
            auto off = juce::MidiMessage::noteOff (ch, note);
            off.setTimeStamp (t + 120.0);   // a 32nd: drums are one-shots
            seq.addEvent (on);
            seq.addEvent (off);
            lastOn = t;
            ++here;
        }
        if (here == 0) continue;
        seq.updateMatchedPairs();
        notes += here;
        mf.addTrack (seq);
    }
    if (notes == 0) return false;
    f.deleteFile();
    juce::FileOutputStream os (f);
    if (! os.openedOk()) return false;
    mf.writeTo (os, 1);
    os.flush();
    return true;
}

juce::File DrumProcessor::exportPad (int pad)
{
    if (pad < 0 || pad >= numPads || recordedHitsOn (pad) == 0) return {};
    auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("VESPER DRUMS");
    dir.createDirectory();
    const auto f = dir.getChildFile (juce::File::createLegalFileName (current.pads[(size_t) pad].label) + " "
                                     + juce::Time::getCurrentTime().formatted ("%H-%M-%S") + ".mid");
    return writeTake (f, pad, true) ? f : juce::File();
}

juce::File DrumProcessor::exportAll()
{
    auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("VESPER DRUMS");
    dir.createDirectory();
    const auto f = dir.getChildFile ("VESPER DRUMS all pads " + juce::Time::getCurrentTime().formatted ("%H-%M-%S") + ".mid");
    return writeTake (f, -1, false) ? f : juce::File();
}

juce::File DrumProcessor::savePadsFolder()
{
    if (recCount.load() == 0) return {};
    auto dir = Library::home().getChildFile ("Takes").getChildFile ("Take " + juce::Time::getCurrentTime().formatted ("%Y-%m-%d %H-%M-%S"));
    dir.createDirectory();
    int index = 1;
    for (int pad = 0; pad < numPads; ++pad)
    {
        if (recordedHitsOn (pad) == 0) continue;
        const auto base = juce::String (index++).paddedLeft ('0', 2) + " " + juce::File::createLegalFileName (current.pads[(size_t) pad].label);
        writeTake (dir.getChildFile (base + ".mid"), pad, true);
        const juce::File snd (current.pads[(size_t) pad].path);
        if (snd.existsAsFile()) snd.copyFileTo (dir.getChildFile (base + " - " + snd.getFileName()));
    }
    writeTake (dir.getChildFile ("All pads (one track each).mid"), -1, false);
    return dir;
}

//==============================================================================
void DrumProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    if (xml == nullptr) return;
    auto* u = xml->createNewChildElement ("VESPER_DRUMS_UI");
    u->setAttribute ("genre", genreNow);
    u->setAttribute ("follow", follow ? 1 : 0);
    u->setAttribute ("selected", selectedPad);
    u->setAttribute ("autoRec", autoRec.load() ? 1 : 0);
    u->setAttribute ("kitFile", kitFile);
    if (auto k = kitToXml (current)) u->addChildElement (k.release());
    copyXmlToBinary (*xml, dest);
}

void DrumProcessor::setStateInformation (const void* data, int size)
{
    std::unique_ptr<juce::XmlElement> xml (getXmlFromBinary (data, size));
    if (xml == nullptr) return;
    if (auto* u = xml->getChildByName ("VESPER_DRUMS_UI"))
    {
        genreNow = juce::jlimit (0, numGenres - 1, u->getIntAttribute ("genre", genreNow));
        follow = u->getIntAttribute ("follow", 1) != 0;
        selectedPad = juce::jlimit (0, numPads - 1, u->getIntAttribute ("selected", 0));
        autoRec.store (u->getIntAttribute ("autoRec", 1) != 0);
        kitFile = u->getStringAttribute ("kitFile");
        if (auto* k = u->getChildByName ("VESPER_DRUMS_KIT"))
        {
            Kit kit;
            if (kitFromXml (*k, kit))
            {
                for (auto& p : current.pads) p.locked = false;   // a saved project restores every pad
                loadKit (kit);
            }
        }
        xml->removeChildElement (u, true);
    }
    if (xml->hasTagName (apvts.state.getType()))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessorEditor* DrumProcessor::createEditor() { return new DrumEditor (*this); }
} // namespace drums

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new drums::DrumProcessor(); }
