// VESPER DRUMS: your drum folder, sorted. Scans every sound under the folders you point it at,
// files each one as a kick, snare, clap, hat... from its file and folder names, and remembers which
// genre it seems to belong to (a "Trap Kit" folder, "lofi snare 3.wav"...).
#pragma once

#include <juce_audio_formats/juce_audio_formats.h>
#include <juce_graphics/juce_graphics.h>

#include <atomic>
#include <functional>
#include <mutex>
#include <vector>

namespace drums
{
enum Cat
{
    CatKick = 0, CatSnare, CatClap, CatSnap, CatRim, CatClosedHat, CatOpenHat, CatRide, CatCrash, CatTom,
    CatPerc, CatShaker, CatTambourine, Cat808, CatFx, CatVox, CatOther, numCats
};
const char* catName (int cat);          // "KICK"
juce::Colour catColour (int cat);

// genre tags (bit per VESPER genre, same order as VESPER's genres)
static constexpr int numGenres = 19;
const char* genreName (int g);           // "TRAP"

// what a sound is, from its file name and the folders it lives in (nearest folder first)
int categorize (const juce::String& fileName, const juce::StringArray& folders);
uint32_t genreTags (const juce::String& fileName, const juce::StringArray& folders);

struct Entry
{
    juce::String path;
    int cat = CatOther;
    uint32_t genres = 0;
};

class Library : private juce::Thread
{
public:
    Library();
    ~Library() override;

    // scan in the background; replaces the library with what's under these folders
    void scan (const juce::StringArray& roots);
    bool scanning() const { return isThreadRunning(); }
    int scannedSoFar() const { return progress.load(); }
    std::atomic<uint32_t> changed { 0 };   // bumps when a scan finishes or the index loads

    juce::StringArray roots() const;
    int size() const;
    int count (int cat) const;
    std::vector<Entry> inCategory (int cat) const;       // sorted by path
    Entry entry (const juce::String& path) const;

    // a sound for a pad: this category, preferring sounds tagged with the genre; avoids `avoid`
    juce::String pick (int cat, int genre, juce::Random&, const juce::String& avoid = {}) const;
    // the next / previous sound in the category (for < >)
    juce::String step (int cat, const juce::String& from, int dir) const;

    bool loadIndex();                      // the last scan, saved next to the kits
    static juce::File home();              // Documents/VESPER DRUMS
    static bool isAudioFile (const juce::File&);

private:
    void run() override;
    void saveIndex() const;

    mutable std::mutex lock;
    std::vector<Entry> entries;
    juce::StringArray rootList, pendingRoots;
    std::atomic<int> progress { 0 };
};
} // namespace drums
