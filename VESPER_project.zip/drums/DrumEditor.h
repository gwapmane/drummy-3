#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "Look.h"
#include "DrumProcessor.h"

namespace drums
{
class DrumEditor;

// one MPC pad: click to play, drag it out to drop its sound into FL
class PadButton : public juce::Component, public juce::SettableTooltipClient
{
public:
    PadButton (DrumEditor& e, int i) : ed (e), index (i) {}
    void paint (juce::Graphics&) override;
    void mouseDown (const juce::MouseEvent&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override { dragged = false; }
    float glow = 0.0f;
    uint32_t lastHits = 0;

private:
    DrumEditor& ed;
    const int index;
    bool dragged = false;
};

// the dashed DRAG tile: a pad's MIDI (or all of them) out into FL
class MidiDrag : public juce::Component, public juce::SettableTooltipClient
{
public:
    MidiDrag (DrumEditor& e, int p) : ed (e), pad (p) {}
    void paint (juce::Graphics&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override;
    juce::String text;

private:
    juce::File make();
    DrumEditor& ed;
    const int pad;   // -1 = every pad
    bool started = false;
};

// the selected pad's sound: drag it out, see its waveform
class SoundTile : public juce::Component, public juce::SettableTooltipClient
{
public:
    explicit SoundTile (DrumEditor& e) : ed (e) {}
    void paint (juce::Graphics&) override;
    void mouseDrag (const juce::MouseEvent&) override;
    void mouseUp (const juce::MouseEvent&) override { started = false; }

private:
    DrumEditor& ed;
    bool started = false;
};

class DrumEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit DrumEditor (DrumProcessor&);
    ~DrumEditor() override;
    void paint (juce::Graphics&) override {}
    void resized() override {}

    DrumProcessor& proc;
    const Theme& theme() const { return look.theme(); }
    void selectPad (int i);
    static constexpr int baseW = 1060, baseH = 700;

private:
    struct Canvas : public juce::Component
    {
        std::function<void (juce::Graphics&)> painter;
        void paint (juce::Graphics& g) override { if (painter) painter (g); }
        std::function<void (const juce::MouseEvent&)> click;
        void mouseUp (const juce::MouseEvent& e) override { if (click) click (e); }
    };

    void timerCallback() override;
    void layout();
    void paintCanvas (juce::Graphics&);
    void refreshPad();                 // the right-hand panel follows the selected pad
    void changePad (std::function<void (PadSettings&)>);
    void showKitMenu();
    void askKitName (bool makeDefault);
    void addFolder();
    void applyScale (int s);
    juce::Rectangle<int> catRect (int cat) const;

    VesperLook look;
    Canvas canvas;
    std::array<std::unique_ptr<PadButton>, numPads> pads;
    std::array<std::unique_ptr<juce::TextButton>, numPads> padDice;
    std::array<std::unique_ptr<MidiDrag>, numPads> padDrag;

    // header
    juce::TextButton kitBtn, saveBtn { "SAVE KIT" }, diceAllBtn { "DICE KIT" };
    juce::ComboBox genreBox;
    juce::ToggleButton followBtn { "FOLLOW VESPER" };
    juce::Slider masterKnob;

    // selected pad
    juce::Label padName;
    juce::ComboBox catBox, chokeBox, noteBox;
    juce::ToggleButton lockBtn { "LOCK" };
    juce::TextButton prevBtn { "<" }, nextBtn { ">" }, diceBtn { "DICE" };
    SoundTile sound { *this };
    juce::Slider tuneKnob, decayKnob, levelKnob, panKnob;

    // library
    juce::TextButton addFolderBtn { "ADD DRUM FOLDER" }, rescanBtn { "RESCAN" };

    // footer
    juce::TextButton recBtn { "REC" }, clearBtn { "CLEAR" }, savePadsBtn { "SAVE PADS" };
    juce::ToggleButton autoRecBtn { "AUTO REC" };
    MidiDrag dragAll { *this, -1 };
    juce::TextButton sizeBtns[3];

    std::unique_ptr<juce::FileChooser> chooser;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> masterAtt;
    juce::TooltipWindow tooltips { this, 600 };
    uint32_t lastKit = 0, lastLib = 0;
    int lastRec = -1, lastScan = -1, uiScale = 1;
    bool lastAround = false;
    int ticks = 0;
    std::array<int, numCats> catCounts {};
    bool updating = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DrumEditor)
};
} // namespace drums
