// VESPER DRUMS: an MPC-style drum sampler for VESPER's grooves. 16 pads, your own sounds, every pad
// one DICE away from another sound of the same kind. Follows VESPER's genre.
#pragma once

#include <juce_audio_processors/juce_audio_processors.h>

#include "DrumKit.h"
#include "DrumLibrary.h"

#include <array>
#include <atomic>
#include <vector>

namespace drums
{
struct Sample
{
    juce::String path;
    juce::AudioBuffer<float> data;      // always two channels
    double rate = 44100.0;
    std::vector<float> peaks;           // 256 points, 0..1, for the waveform
    std::atomic<int> voices { 0 };      // voices playing it right now (it isn't freed while > 0)
};

class DrumProcessor : public juce::AudioProcessor, private juce::Timer
{
public:
    DrumProcessor();
    ~DrumProcessor() override;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    using AudioProcessor::processBlock;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "VESPER DRUMS"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 3.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return "Default"; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    //==============================================================================
    // message thread
    juce::AudioProcessorValueTreeState apvts;
    Library library;

    const Kit& kit() const { return current; }
    void setPadSettings (int pad, const PadSettings&);           // everything but the sound
    void setPadSample (int pad, const juce::String& path, bool audition);
    void dicePad (int pad, bool audition = true);
    void stepPad (int pad, int dir);                             // < > through the pad's kind of sound
    void diceAll();                                              // every pad that isn't locked
    void setGenre (int genre);                                   // the genre's default kit, or a fresh one from your folder
    int genre() const { return genreNow; }
    void buildKit (int genre, bool keepLocked = true);
    void loadKit (const Kit&);
    bool loadKitFile (const juce::File&);
    juce::File saveKit (const juce::String& name, bool makeDefault);
    juce::String kitFile;                                        // the kit file last loaded / saved
    bool follow = true;                                          // follow VESPER's genre
    int selectedPad = 0;

    const Sample* padSample (int pad) const;                     // what the pad holds (for the waveform)
    void hitPad (int pad, int velocity);                         // a click on a pad
    std::array<std::atomic<uint32_t>, numPads> padHits;          // bumps on every hit (pad lights)
    std::array<std::atomic<int>, numPads> padVel;

    // VESPER: the genre it's on, and whether one is around
    int vesperGenre() const { return linkGenre; }
    bool vesperAround() const;

    // recording: what the pads played, ready to drag into FL
    std::atomic<bool> recording { false }, autoRec { true };
    void clearRecording() { clearRequested.store (true); }
    int recordedHits() const { return recCount.load(); }
    int recordedHitsOn (int pad) const;
    juce::File exportPad (int pad);              // that pad's hits on C5 (note 60): drop it on an FL sampler channel
    juce::File exportAll();                      // every pad as its own track, on its GM note
    juce::File savePadsFolder();                 // each pad's MIDI + its sound, in Documents/VESPER DRUMS/Takes

    std::atomic<uint32_t> kitChanged { 0 };      // bumps when pads change (the editor refreshes)

private:
    void timerCallback() override;
    std::unique_ptr<Sample> loadSample (const juce::String& path);
    void installSample (int pad, std::unique_ptr<Sample>);
    void pushPad (int pad);                      // settings -> audio thread
    void rebuildNoteMap();
    juce::String pickFor (int pad, int genre, const juce::String& avoid);
    bool writeTake (const juce::File&, int onlyPad, bool asC5);

    Kit current = defaultKit();
    int genreNow = 6;
    juce::AudioFormatManager formats;

    // the audio thread's view of the pads
    struct PadLive
    {
        std::atomic<Sample*> sample { nullptr };
        std::atomic<float> level { 0.8f }, pan { 0.0f }, tune { 0.0f }, decay { 1.0f };
        std::atomic<int> choke { 0 };
    };
    std::array<PadLive, numPads> live;
    std::array<std::atomic<int>, 128> noteToPad;

    std::vector<std::unique_ptr<Sample>> owned;  // every sample a pad holds, or held a moment ago
    struct Retired { Sample* s; double at; };
    std::vector<Retired> retired;

    juce::AbstractFifo hitFifo { 256 };
    std::array<std::pair<int, int>, 256> hitQueue {};

    struct Voice
    {
        bool active = false;
        int pad = 0;
        Sample* s = nullptr;
        double pos = 0, step = 1;
        float gl = 1, gr = 1, env = 1, decayMul = 1, hold = 0;
        bool releasing = false;
        uint32_t age = 0;
        int startOffset = 0;
    };
    std::array<Voice, 64> voices;
    uint32_t voiceAge = 0;
    double sr = 44100.0;
    void trigger (int pad, int velocity, int offset);
    void endVoice (Voice&);

    // recording
    struct RecHit { double beat = 0; uint8_t pad = 0, vel = 0, synced = 0; };
    std::vector<RecHit> rec;
    std::atomic<int> recCount { 0 };
    std::atomic<bool> clearRequested { false };
    bool lastHostRec = false;
    double freeBeat = 0;

    // link to VESPER
    int linkGenre = -1;
    juce::Time linkFileTime;
    double linkSeenMs = -1e9;
    uint32_t libSeen = 0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DrumProcessor)
};
} // namespace drums
