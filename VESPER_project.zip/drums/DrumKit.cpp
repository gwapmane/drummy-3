#include "DrumKit.h"

namespace drums
{
Kit defaultKit()
{
    struct Row { const char* label; int cat; int note; int choke; float tune; };
    // MPC order: pad 1 is bottom-left
    static const Row rows[numPads] = {
        { "KICK", CatKick, 36, 0, 0.0f },        { "SNARE", CatSnare, 38, 0, 0.0f },      { "CLAP", CatClap, 39, 0, 0.0f },
        { "RIM", CatRim, 37, 0, 0.0f },          { "CLOSED HAT", CatClosedHat, 42, 1, 0.0f }, { "PEDAL HAT", CatClosedHat, 44, 1, -2.0f },
        { "OPEN HAT", CatOpenHat, 46, 1, 0.0f }, { "RIDE", CatRide, 51, 0, 0.0f },       { "CRASH", CatCrash, 49, 0, 0.0f },
        { "LOW TOM", CatTom, 45, 0, -3.0f },     { "MID TOM", CatTom, 47, 0, 0.0f },     { "HIGH TOM", CatTom, 50, 0, 3.0f },
        { "PERC 1", CatPerc, 63, 0, 0.0f },      { "PERC 2", CatPerc, 64, 0, 0.0f },     { "SHAKER", CatShaker, 70, 0, 0.0f },
        { "TAMBOURINE", CatTambourine, 54, 0, 0.0f } };
    Kit k;
    for (int i = 0; i < numPads; ++i)
    {
        auto& p = k.pads[(size_t) i];
        p.label = rows[i].label;
        p.cat = rows[i].cat;
        p.note = rows[i].note;
        p.choke = rows[i].choke;
        p.tune = rows[i].tune;
    }
    return k;
}

std::unique_ptr<juce::XmlElement> kitToXml (const Kit& k)
{
    auto x = std::make_unique<juce::XmlElement> ("VESPER_DRUMS_KIT");
    x->setAttribute ("name", k.name);
    x->setAttribute ("genre", k.genre);
    for (int i = 0; i < numPads; ++i)
    {
        const auto& p = k.pads[(size_t) i];
        auto* e = x->createNewChildElement ("PAD");
        e->setAttribute ("index", i);
        e->setAttribute ("label", p.label);
        e->setAttribute ("path", p.path);
        e->setAttribute ("cat", catName (p.cat));
        e->setAttribute ("note", p.note);
        e->setAttribute ("level", p.level);
        e->setAttribute ("pan", p.pan);
        e->setAttribute ("tune", p.tune);
        e->setAttribute ("decay", p.decay);
        e->setAttribute ("choke", p.choke);
        e->setAttribute ("locked", p.locked ? 1 : 0);
    }
    return x;
}

bool kitFromXml (const juce::XmlElement& x, Kit& k)
{
    if (! x.hasTagName ("VESPER_DRUMS_KIT")) return false;
    Kit out = defaultKit();
    out.name = x.getStringAttribute ("name", "KIT");
    out.genre = x.getIntAttribute ("genre", -1);
    for (auto* e : x.getChildWithTagNameIterator ("PAD"))
    {
        const int i = e->getIntAttribute ("index", -1);
        if (i < 0 || i >= numPads) continue;
        auto& p = out.pads[(size_t) i];
        p.label = e->getStringAttribute ("label", p.label);
        p.path = e->getStringAttribute ("path");
        const auto cn = e->getStringAttribute ("cat");
        for (int c = 0; c < numCats; ++c) if (cn == catName (c)) p.cat = c;
        p.note = juce::jlimit (0, 127, e->getIntAttribute ("note", p.note));
        p.level = (float) juce::jlimit (0.0, 1.0, e->getDoubleAttribute ("level", p.level));
        p.pan = (float) juce::jlimit (-1.0, 1.0, e->getDoubleAttribute ("pan", p.pan));
        p.tune = (float) juce::jlimit (-24.0, 24.0, e->getDoubleAttribute ("tune", p.tune));
        p.decay = (float) juce::jlimit (0.02, 1.0, e->getDoubleAttribute ("decay", p.decay));
        p.choke = juce::jlimit (0, 4, e->getIntAttribute ("choke", p.choke));
        p.locked = e->getIntAttribute ("locked", 0) != 0;
    }
    k = out;
    return true;
}

juce::File kitsFolder() { return Library::home().getChildFile ("Kits"); }

juce::File kitFolderFor (int genre)
{
    if (genre < 0) return kitsFolder().getChildFile ("MY KITS");
    return kitsFolder().getChildFile (juce::File::createLegalFileName (genreName (genre)));
}

juce::Array<juce::File> kitsFor (int genre)
{
    const auto dir = genre < 0 ? kitsFolder() : kitFolderFor (genre);
    auto files = dir.findChildFiles (juce::File::findFiles, genre < 0, "*.vdkit");
    files.sort();
    return files;
}

static juce::File defaultsFile() { return kitsFolder().getChildFile ("defaults.xml"); }

juce::File defaultKitFor (int genre)
{
    auto x = juce::XmlDocument::parse (defaultsFile());
    if (x == nullptr) return {};
    for (auto* e : x->getChildWithTagNameIterator ("DEFAULT"))
        if (e->getIntAttribute ("genre", -2) == genre)
        {
            const juce::File f (e->getStringAttribute ("kit"));
            return f.existsAsFile() ? f : juce::File();
        }
    return {};
}

void setDefaultKitFor (int genre, const juce::File& kit)
{
    auto x = juce::XmlDocument::parse (defaultsFile());
    if (x == nullptr) x = std::make_unique<juce::XmlElement> ("VESPER_DRUMS_DEFAULTS");
    for (auto* e : x->getChildWithTagNameIterator ("DEFAULT"))
        if (e->getIntAttribute ("genre", -2) == genre) { x->removeChildElement (e, true); break; }
    if (kit != juce::File())
    {
        auto* e = x->createNewChildElement ("DEFAULT");
        e->setAttribute ("genre", genre);
        e->setAttribute ("kit", kit.getFullPathName());
    }
    defaultsFile().getParentDirectory().createDirectory();
    x->writeTo (defaultsFile());
}
} // namespace drums
