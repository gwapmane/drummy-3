// VESPER chord engine self-test: builds with plain g++, no JUCE.
#include "../core/Theory.h"
#include "../core/Voicing.h"
#include "../core/Guitar.h"
#include "../core/Perform.h"
#include "../core/Band.h"

#include <cstdio>
#include <cstdlib>
#include <set>
#include <string>

using namespace vesper;

static int failures = 0;
#define CHECK(cond, ...) do { if (! (cond)) { ++failures; if (failures < 40) { std::printf ("FAIL: "); std::printf (__VA_ARGS__); std::printf ("\n"); } } } while (0)

static std::string notesStr (const Notes& n)
{
    std::string s;
    for (int i = 0; i < n.size(); ++i) s += midiName (n[i], false) + " ";
    return s;
}

int main()
{
    // 1. qualities
    CHECK (numQualities() >= 75, "only %d chord types", numQualities());
    for (int q = 0; q < numQualities(); ++q)
    {
        CHECK (! qualities()[(size_t) q].iv.empty(), "empty quality %d", q);
        for (int q2 = q + 1; q2 < numQualities(); ++q2)
            CHECK (qualities()[(size_t) q].suffix != qualities()[(size_t) q2].suffix, "duplicate suffix %s", qualities()[(size_t) q].suffix.c_str());
    }

    // 2. voicings: every chord, every root, every style, every variant
    long voicings = 0, missingThird = 0;
    for (int q = 0; q < numQualities(); ++q)
        for (int r = 0; r < 12; ++r)
        {
            Chord c; c.root = r; c.quality = q;
            const int mask = pcMask (c);
            const int rel = tonesMask (c);
            int third = -1;
            for (int x : { 4, 3, 5, 2 }) if ((rel >> x) & 1) { third = (x + r) % 12; break; }
            for (int s = 0; s < numStyles; ++s)
            {
                const int nv = numVariants (c, s);
                CHECK (nv >= 1, "no variants");
                for (int v = 0; v < nv; ++v)
                {
                    const Notes n = fitToCenter (buildVoicing (c, s, v), 60);
                    ++voicings;
                    CHECK (n.size() >= 2, "%s %s v%d: too few notes", chordName (c, false).c_str(), styleName (s), v);
                    bool hasThird = third < 0;
                    for (int i = 0; i < n.size(); ++i)
                    {
                        CHECK (n[i] >= 0 && n[i] <= 127, "note out of range");
                        CHECK ((mask >> (n[i] % 12)) & 1, "%s %s v%d: wrong note %s", chordName (c, false).c_str(), styleName (s), v, midiName (n[i], false).c_str());
                        if (n[i] % 12 == third) hasThird = true;
                        for (int j = i + 1; j < n.size(); ++j) CHECK (n[i] != n[j], "duplicate note");
                    }
                    if (! hasThird && s != PowerRock && s != Quartal) ++missingThird;
                    if (s == Close || s == Open)
                        for (int pc = 0; pc < 12; ++pc)
                            if ((mask >> pc) & 1)
                            {
                                bool found = false;
                                for (int i = 0; i < n.size(); ++i) if (n[i] % 12 == pc) found = true;
                                CHECK (found, "%s %s missing a chord tone", chordName (c, false).c_str(), styleName (s));
                            }
                }
            }
        }
    CHECK (missingThird == 0, "%ld voicings lost their 3rd", missingThird);
    std::printf ("voicings checked: %ld\n", voicings);

    // 3. guitar shapes
    int noShape = 0, shapes = 0;
    for (int q = 0; q < numQualities(); ++q)
        for (int r = 0; r < 12; ++r)
        {
            Chord c; c.root = r; c.quality = q;
            Shape s[maxShapes];
            const int n = findShapes (c, s, maxShapes);
            shapes += n;
            if (n == 0) { ++noShape; std::printf ("  no guitar shape: %s\n", chordName (c, false).c_str()); }
            for (int i = 0; i < n; ++i)
            {
                const Notes notes = shapeNotes (s[i]);
                CHECK (notes.size() >= 3, "guitar shape too thin");
                CHECK (notes[0] % 12 == r, "%s guitar shape bass is not the root", chordName (c, false).c_str());
                for (int k = 0; k < notes.size(); ++k) CHECK ((pcMask (c) >> (notes[k] % 12)) & 1, "guitar wrong note");
                CHECK (s[i].highestFret() - s[i].lowestFret() <= 3 || s[i].lowestFret() == 0, "guitar stretch too wide");
            }
        }
    CHECK (noShape == 0, "%d chords with no guitar shape", noShape);
    std::printf ("guitar shapes: %d\n", shapes);

    // slash chord guitar shape
    {
        const Chord ce = makeChord (0, "", 4);
        Shape s[maxShapes];
        const int n = findShapes (ce, s, maxShapes);
        CHECK (n > 0 && shapeNotes (s[0])[0] % 12 == 4, "C/E guitar shape should have E in the bass");
    }

    // 4. scale maps
    for (int sc = 0; sc < numScales(); ++sc)
        for (int key = 0; key < 12; ++key)
            for (int g = 0; g < numGenres; ++g)
            {
                const ScaleMap m = buildScaleMap (key, sc, g);
                int white = 0, filled = 0;
                const auto& iv = scales()[(size_t) sc].iv;
                const int whitePos[] = { 0, 2, 4, 5, 7, 9, 11 };
                for (int note = 0; note < 128; ++note)
                {
                    const int pc = note % 12;
                    const bool isWhite = pc == 0 || pc == 2 || pc == 4 || pc == 5 || pc == 7 || pc == 9 || pc == 11;
                    const auto& slot = m.keys[(size_t) note];
                    if (isWhite)
                    {
                        // a white key may only be empty when no chord type at all fits on that degree
                        int w = 0;
                        while (whitePos[w] != pc) ++w;
                        const int degreeRoot = key + iv[(size_t) (w % (int) iv.size())];
                        bool anyFits = false;
                        for (int q = 0; q < numQualities(); ++q) { Chord c; c.root = degreeRoot % 12; c.quality = q; if (fitsScale (c, key, sc)) anyFits = true; }
                        ++white;
                        if (slot.chord.valid() || ! anyFits) ++filled;
                    }
                    if (slot.chord.valid() && ! slot.outside)
                        CHECK (fitsScale (slot.chord, key, sc), "%s key %d: %s on note %d isn't in the scale", scales()[(size_t) sc].name.c_str(), key, chordName (slot.chord, false).c_str(), note);
                }
                CHECK (filled == white, "%s key %d: %d of %d white keys empty", scales()[(size_t) sc].name.c_str(), key, white - filled, white);
            }

    {
        const ScaleMap m = buildScaleMap (0, 0, Soul);
        std::printf ("C major, scale map:\n");
        for (int row = 0; row < numRows; ++row)
        {
            std::printf ("  %-7s ", rowName (row));
            for (int p = 0; p < 12; ++p)
            {
                const int note = rowBaseNote (row) + p;
                if (note > 127) break;
                const auto& s = m.keys[(size_t) note];
                std::printf ("%-10s", s.chord.valid() ? (chordName (s.chord, false) + (s.outside ? "*" : "")).c_str() : "-");
            }
            std::printf (" (+%d more)\n", (int) m.overflow[(size_t) row].size());
        }
        std::printf ("  every chord in C major: %d\n", (int) m.allInKey.size());
    }

    // 5. palettes
    for (int g = 0; g < numGenres; ++g)
        for (int sc = 0; sc < numScales(); ++sc)
            for (int key = 0; key < 12; ++key)
                for (uint32_t seed = 0; seed < 4; ++seed)
                {
                    const Palette p = buildPalette (key, sc, g, seed);
                    for (int i = 0; i < paletteSize; ++i)
                        CHECK (p[(size_t) i].chord.valid(), "%s palette slot %d invalid", genreShort (g), i);
                }
    {
        const Palette p = buildPalette (0, 0, Soul, 0);
        std::printf ("Soul palette in C: ");
        for (const auto& c : p) std::printf ("%s ", chordName (c.chord, false).c_str());
        std::printf ("\n");
    }

    // 6. triads
    {
        const Chord c = makeChord (0, "maj9");
        const auto t = triadsIn (c, false);
        std::printf ("Triads in Cmaj9: ");
        for (const auto& x : t) std::printf ("%s ", x.name.c_str());
        std::printf ("\n");
        CHECK (t.size() >= 3, "Cmaj9 should hold C, Em, G triads");
        const Notes inv1 = triadNotes (t[0], 1, 4);
        CHECK (inv1.size() == 3 && inv1[0] == 52 && inv1[1] == 55 && inv1[2] == 60, "C triad 1st inversion octave 4 should be E4 G4 C5, got %s", notesStr (inv1).c_str());
    }

    // 7. suggestions
    {
        const ScaleMap m = buildScaleMap (0, 0, Soul);
        const auto s = suggestNext (makeChord (7, "7"), 0, 0, m.allInKey);
        CHECK (! s.empty() && s[0].chord.root == 0, "G7 should resolve to C");
        std::printf ("After G7: ");
        for (const auto& x : s) std::printf ("%s (%s)  ", chordName (x.chord, false).c_str(), x.why.c_str());
        std::printf ("\n");
    }

    // 8. names and numerals
    CHECK (chordName (makeChord (10, "m7b5"), true) == "Bbm7b5", "name");
    CHECK (romanNumeral (makeChord (11, "m7b5"), 0) == "viiø", "numeral %s", romanNumeral (makeChord (11, "m7b5"), 0).c_str());
    CHECK (romanNumeral (makeChord (10, "7"), 0) == "bVII", "numeral bVII");
    CHECK (midiName (60, false) == "C5", "FL naming");

    // 9. vary always changes the voicing, smooth moves little
    {
        Rng rng;
        const Chord c = makeChord (2, "m9");
        Notes last = chooseVoicing (c, Lush, -1, 60, false, Notes(), false, Notes(), Soul, rng).notes;
        for (int i = 0; i < 50; ++i)
        {
            const auto p = chooseVoicing (c, Lush, -1, 60, i % 2 == 0, last, true, last, Soul, rng);
            CHECK (! p.notes.sameAs (last), "vary repeated the same voicing");
            last = p.notes;
        }
        const Notes a = chooseVoicing (makeChord (0, "maj7"), Close, -1, 60, false, Notes(), false, Notes(), Soul, rng).notes;
        const Notes b = chooseVoicing (makeChord (5, "maj7"), Close, -1, 60, true, a, false, Notes(), Soul, rng).notes;
        int move = 0;
        for (int i = 0; i < a.size() && i < b.size(); ++i) move += std::abs (a[i] - b[i]);
        std::printf ("Cmaj7 %s-> Fmaj7 %s(moved %d)\n", notesStr (a).c_str(), notesStr (b).c_str(), move);
        CHECK (move <= 8, "smooth voice leading moved too far");
        const Notes v = buildVoicing (makeChord (0, "13"), UpperStructure, 0);
        std::printf ("C13 upper structure: %s\n", notesStr (v).c_str());
    }

    // 10. playing styles: every rhythm plays sensible notes for a whole cycle
    {
        Rng rng;
        for (int withBass = 0; withBass < 2; ++withBass)
            for (int r = 0; r < numRhythms; ++r)
            {
                PatternInput in;
                in.upper.add (60); in.upper.add (64); in.upper.add (67); in.upper.add (71);
                in.bass = withBass ? 36 : -1;
                in.poolMask = scaleMask (0, 0);
                if (rhythmNeedsBass (r) && in.bass < 0) in.bass = 36;
                const int len = rhythmLength (r, in);
                CHECK (len >= 1 && len <= 64, "%s: odd length %d", rhythmInfo (r).name, len);
                int hits = 0, memory = -1;
                for (int k = 0; k < 64; ++k)
                {
                    const Hit h = rhythmStep (r, k, in, rng, memory);
                    if (! h.rest) ++hits;
                    for (int i = 0; i < h.notes.size(); ++i) CHECK (h.notes[i] >= 0 && h.notes[i] <= 127, "%s note out of range", rhythmInfo (r).name);
                    if (rhythmOneShot (r) && k >= len) CHECK (h.rest, "%s should stop after one pass", rhythmInfo (r).name);
                }
                CHECK (hits > 0, "%s never plays", rhythmInfo (r).name);
            }
        // waterfall goes down, rising goes up
        PatternInput in;
        for (int x : { 60, 64, 67, 71 }) in.upper.add (x);
        int mem = -1;
        const int w0 = rhythmStep (RWaterfall, 0, in, rng, mem).notes[0], w1 = rhythmStep (RWaterfall, 1, in, rng, mem).notes[0];
        const int r0 = rhythmStep (RRising, 0, in, rng, mem).notes[0], r1 = rhythmStep (RRising, 1, in, rng, mem).notes[0];
        CHECK (w0 > w1 && w0 > 71, "waterfall should start above the chord and fall (%d, %d)", w0, w1);
        CHECK (r1 > r0, "rising should climb");
        std::printf ("waterfall over Cmaj7: ");
        for (int k = 0; k < rhythmLength (RWaterfall, in); ++k) std::printf ("%s ", midiName (rhythmStep (RWaterfall, k, in, rng, mem).notes[0], false).c_str());
        std::printf ("\n");
    }

    // 11. upper extensions stay above the chord and in the key
    {
        const char* chords[][2] = { { "0", "maj7" }, { "2", "m7" }, { "4", "m7" }, { "5", "maj7" }, { "7", "7" }, { "9", "m7" }, { "11", "m7b5" } };
        for (int type = 0; type < numExtTypes; ++type)
            for (auto& cs : chords)
            {
                const Chord c = makeChord (std::atoi (cs[0]), cs[1]);
                Rng rr;
                const Notes v = chooseVoicing (c, Lush, -1, 60, false, Notes(), false, Notes(), Soul, rr).notes;
                const Notes e = upperExtension (c, v, type, 0, 0);
                CHECK (! e.empty(), "%s %s: no extension", chordName (c, false).c_str(), extTypeName (type));
                for (int i = 0; i < e.size(); ++i)
                {
                    CHECK (e[i] > v.highest(), "%s %s: extension below the chord", chordName (c, false).c_str(), extTypeName (type));
                    CHECK ((scaleMask (0, 0) >> (e[i] % 12)) & 1, "%s %s: %s is outside C major", chordName (c, false).c_str(), extTypeName (type), midiName (e[i], false).c_str());
                }
                if (type == ExtTensions)
                {
                    std::printf ("  %s + ", chordName (c, false).c_str());
                    for (int i = 0; i < e.size(); ++i) std::printf ("%s ", noteName (e[i], false).c_str());
                    std::printf ("\n");
                }
            }
    }

    // 12. band: every genre, every part, every style
    {
        const Chord prog[4] = { makeChord (2, "m7"), makeChord (7, "7"), makeChord (0, "maj7"), makeChord (9, "m7") };
        const int key = scaleMask (0, 0);
        long total = 0;
        for (int part = 0; part < numBandTypes; ++part)
            for (int style = 0; style < bandNumStyles (part); ++style)
                for (uint32_t seed = 1; seed <= 3; ++seed)
                {
                    Band band;
                    BandConfig bc;
                    bc.phraseBars = 4;
                    bc.numTracks = maxBandTracks;
                    for (int t = 0; t < maxBandTracks; ++t) { bc.part[(size_t) t].type = bandDefaultType (t); bc.part[(size_t) t].channel = bandDefaultChannel (t); }
                    const int track = 7;   // any slot can be any type
                    auto& pc = bc.part[(size_t) track];
                    pc.type = part; pc.on = true; pc.style = style; pc.seed = seed; pc.channel = 9;
                    if (part == BCounter) { bc.part[0].type = BMelody; bc.part[0].on = true; bc.part[0].seed = seed; bc.part[0].channel = 3; }
                    int notes = 0, inKey = 0, firstOnsets = 0, againOnsets = 0;
                    bool onsets[2][16] = {};
                    for (int64_t stp = 0; stp < 16 * 16; ++stp)
                    {
                        const int bar = (int) (stp / 16);
                        Harmony h;
                        h.chord = prog[bar % 4];
                        h.id = bar;
                        BandEvent ev[Band::maxEventsPerStep];
                        const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                        CHECK (n >= 0 && n <= Band::maxEventsPerStep, "too many events");
                        for (int i = 0; i < n; ++i)
                        {
                            const auto& e = ev[i];
                            if (e.part != track) continue;
                            CHECK (e.channel == pc.channel, "%s: wrong channel", bandPartName (part));
                            if (e.isCC) { CHECK (e.note == 11 && e.velocity >= 0 && e.velocity <= 127, "bad CC"); continue; }
                            ++notes; ++total;
                            CHECK (e.note >= 0 && e.note <= 127 && e.velocity >= 1 && e.velocity <= 127, "%s %s: bad note", bandPartName (part), bandStyleName (part, style));
                            CHECK (e.length > 0.0f || e.length == -1.0f, "%s %s: bad length", bandPartName (part), bandStyleName (part, style));
                            CHECK (e.offset >= 0.0f && e.offset < 4.0f, "%s %s: bad offset %f", bandPartName (part), bandStyleName (part, style), e.offset);
                            if (bandTypeIsDrums (part)) CHECK (Band::isDrumNote (e.note), "%s %s: %d isn't a GM drum", bandPartName (part), bandStyleName (part, style), e.note);
                            else
                            {
                                if (e.length > 0.0f && e.length < 0.3f) --notes;   // grace notes may be chromatic
                                else if ((key >> (e.note % 12)) & 1 || (pcMask (prog[bar % 4]) >> (e.note % 12)) & 1) ++inKey;
                                if (part == BBass) CHECK (e.note >= 20 && e.note <= 64, "BASS %s: note %d out of range", bandStyleName (part, style), e.note);
                                if (part == BMelody) CHECK (e.note >= 48 && e.note <= 100, "MELODY %s: note %d out of range", bandStyleName (part, style), e.note);
                                if (part == BGuitar) CHECK (e.note >= 38 && e.note <= 80, "GUITAR %s: note %d out of range", bandStyleName (part, style), e.note);
                                if (part == BKeys || part == BPad || part == BArp) CHECK (e.note >= 40 && e.note <= 100, "%s %s: note %d out of range", bandPartName (part), bandStyleName (part, style), e.note);
                            }
                            if (part == BMelody && (bar == 0 || bar == 4) && e.offset < 0.01f) onsets[bar == 4][stp % 16] = true;
                        }
                    }
                    const bool needsMelody = part == BCounter && (style == 0 || style == 1 || style == 5);
                    const bool sparsePiece = bandTypePiece (part) >= 0 && part != BKick && part != BHats;   // a groove may not use this piece
                    CHECK (notes > 4 || (needsMelody && notes > 0) || sparsePiece, "%s %s seed %u: only %d notes", bandPartName (part), bandStyleName (part, style), seed, notes);
                    if (! bandTypeIsDrums (part) && notes > 0)
                    {
                        const float frac = (float) inKey / (float) notes;
                        const bool bluesy = (part == BMelody && (style == 2 || style == 3 || style == 5 || style == 9)) || (part == BHorns && style == 2);
                        CHECK (frac >= (bluesy ? 0.6f : 0.8f), "%s %s seed %u: only %.0f%% of notes in key", bandPartName (part), bandStyleName (part, style), seed, frac * 100.0f);
                    }
                    (void) firstOnsets; (void) againOnsets; (void) onsets;
                }

        // the phrase library: every phrase parses, lines up with its bar lines, and plays in range
        {
            const auto& lib = phraseLibrary();
            CHECK (lib.size() >= 130, "phrase library has %d phrases", (int) lib.size());
            for (int set = 0; set < numPhraseSets; ++set)
                CHECK (phrasesInSet (set).size() >= 4, "phrase set %s has only %d phrases", phraseSetName (set), (int) phrasesInSet (set).size());
            // a hook comes back: the melody's opening phrase returns within 8 bars
            for (int style = 0; style < bandNumStyles (BMelody); ++style)
            {
                Band band;
                BandConfig bc;
                bc.part[BMelody].on = true; bc.part[BMelody].style = style; bc.part[BMelody].seed = 3; bc.part[BMelody].density = 0.8f;
                std::vector<std::string> barRhythm;
                for (int64_t stp = 0; stp < 16 * 12; ++stp)
                {
                    if (stp % 16 == 0) barRhythm.push_back ("");
                    Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                    BandEvent ev[Band::maxEventsPerStep];
                    const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                    for (int i = 0; i < n; ++i) if (! ev[i].isCC) barRhythm.back() += std::to_string (stp % 16) + ",";
                }
                bool repeats = false;
                for (size_t a = 0; a < barRhythm.size(); ++a)
                    for (size_t b = a + 1; b < barRhythm.size(); ++b)
                        if (! barRhythm[a].empty() && barRhythm[a] == barRhythm[b]) repeats = true;
                CHECK (repeats, "MELODY %s: no phrase ever comes back", bandStyleName (BMelody, style));
            }
        }

        // different seeds = different lines; same seed = the same line
        auto melody = [&] (uint32_t seed)
        {
            Band band;
            BandConfig bc;
            bc.part[BMelody].on = true;
            bc.part[BMelody].seed = seed;
            std::string out;
            for (int64_t stp = 0; stp < 64; ++stp)
            {
                Harmony h;
                h.chord = prog[(stp / 16) % 4];
                h.id = (int) (stp / 16);
                BandEvent ev[Band::maxEventsPerStep];
                const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                for (int i = 0; i < n; ++i) out += std::to_string (stp) + ":" + std::to_string (ev[i].note) + " ";
            }
            return out;
        };
        CHECK (melody (7) == melody (7), "same seed should give the same melody");
        CHECK (melody (7) != melody (8), "different seeds should give different melodies");

        for (int g = 0; g < numGenres; ++g)
        {
            const BandGenrePreset bp = bandGenrePreset (g);
            CHECK (bp.lineup != 0, "%s: empty band lineup", genreShort (g));
            for (int part = 0; part < numBandTypes; ++part)
                CHECK (bp.style[part] >= 0 && bp.style[part] < bandNumStyles (part), "%s preset style out of range", genreShort (g));
        }

        // GROOVES: 50 per genre, all different, simple to busy; a kick and a backbeat; a split kit plays
        // exactly what the full kit plays
        {
            int totalHits = 0;
            for (int g = 0; g < numGenres; ++g)
            {
                std::set<std::string> names, shapes;
                int lastBusy = -1;
                for (int i = 0; i < groovesPerGenre; ++i)
                {
                    const Groove& gr = groove (g, i);
                    names.insert (gr.name);
                    CHECK (gr.bars == 1 || gr.bars == 2, "%s groove %d: %d bars", genreShort (g), i, gr.bars);
                    CHECK (gr.busy >= lastBusy, "%s grooves should go from simple to busy", genreShort (g));
                    lastBusy = gr.busy;
                    std::string shape;
                    bool kick = false, back = false;
                    for (const auto& h : gr.hits)
                    {
                        CHECK (h.step >= 0 && h.step < gr.bars * 16 && h.off >= 0.0f && h.off < 2.0f, "%s groove %d: bad step", genreShort (g), i);
                        CHECK (Band::isDrumNote (h.note) && h.vel >= 1 && h.vel <= 127, "%s groove %d: bad note %d", genreShort (g), i, h.note);
                        shape += std::to_string (h.step) + ":" + std::to_string (h.note) + ":" + std::to_string (h.vel) + ",";
                        kick |= h.piece == PieceKick;
                        back |= (h.piece == PieceSnare || h.piece == PieceClap || h.note == gm::Rim) && h.vel >= 60;
                        ++totalHits;
                    }
                    shapes.insert (shape);
                    const bool loose = g == Jazz || g == Latin || g == Cinematic || g == Reggae;
                    CHECK (loose || (kick && back), "%s groove %d (%s): needs a kick and a backbeat", genreShort (g), i, gr.name.c_str());
                }
                CHECK ((int) shapes.size() == groovesPerGenre, "%s: only %d different grooves", genreShort (g), (int) shapes.size());
                CHECK (! grooveLabel (g, 0).empty() && grooveLabel (g, 6).substr (0, 3) == "07 ", "groove labels");
            }
            std::printf ("Grooves: %d genres x %d grooves, %d hits written\n", (int) numGenres, groovesPerGenre, totalHits);

            for (int g : { (int) Trap, (int) Soul, (int) Afro, (int) Cinematic })
                for (int gi : { 0, 17, 49 })
                {
                    auto collect = [&] (bool split)
                    {
                        Band band;
                        BandConfig bc;
                        bc.genre = g; bc.groove = gi; bc.phraseBars = 4;
                        if (split)
                        {
                            bc.numTracks = 8;
                            for (int t = 0; t < 8; ++t) { auto& c = bc.part[(size_t) t]; c.type = BKick + t; c.on = true; c.channel = 10; c.style = 0; }
                        }
                        else
                        {
                            bc.numTracks = 1;
                            auto& c = bc.part[0]; c.type = BDrums; c.on = true; c.channel = 10; c.style = drumGrooveStyle;
                        }
                        std::multiset<std::string> hits;
                        for (int64_t stp = 0; stp < 16 * 8; ++stp)
                        {
                            Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                            BandEvent ev[Band::maxEventsPerStep];
                            const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                            for (int k = 0; k < n; ++k)
                                if (! ev[k].isCC) hits.insert (std::to_string (stp) + ":" + std::to_string (ev[k].note) + ":" + std::to_string ((int) (ev[k].offset * 100)));
                        }
                        return hits;
                    };
                    const auto full = collect (false), split = collect (true);
                    CHECK (full == split && full.size() > 30, "%s groove %d: the split kit should play exactly what the full kit plays (%d vs %d hits)",
                           genreShort (g), gi, (int) full.size(), (int) split.size());
                }
        }

        // drum patterns are straight: with SWING at 0 nothing is pushed late (rolls and the neo-soul
        // lazy snare are part of the pattern); with SWING up, the off-beats move
        for (int style = 0; style < bandNumStyles (BDrums); ++style)
            for (int swingOn = 0; swingOn < 2; ++swingOn)
            {
                Band band;
                BandConfig bc;
                bc.part[0].type = BDrums; bc.part[0].on = true; bc.part[0].style = style; bc.part[0].channel = 10;
                bc.part[0].density = 0.8f; bc.part[0].complexity = 0.8f;
                bc.swing = swingOn ? 0.25f : 0.0f;
                int late = 0, offbeats = 0, swung = 0;
                for (int64_t stp = 0; stp < 16 * 8; ++stp)
                {
                    Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                    BandEvent ev[Band::maxEventsPerStep];
                    const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                    for (int i = 0; i < n; ++i)
                    {
                        const float o = ev[i].offset;
                        const bool roll = std::abs (o - 0.333f) < 0.01f || std::abs (o - 0.666f) < 0.01f;
                        const bool lazy = style == 9 && std::abs (o - 0.12f) < 0.01f;
                        if (! swingOn && o > 0.001f && ! roll && ! lazy) ++late;
                        if (stp % 4 == 2) { ++offbeats; if (o >= 0.49f) ++swung; }
                    }
                }
                if (! swingOn) CHECK (late == 0, "DRUMS %s: %d hits swung with SWING at 0", bandStyleName (BDrums, style), late);
                else CHECK (offbeats == 0 || swung == offbeats, "DRUMS %s: SWING didn't move the off-beats (%d of %d)", bandStyleName (BDrums, style), swung, offbeats);
            }

        // every track full: 15 tracks never overflow a step, and two tracks of one type both play
        {
            Band band;
            BandConfig bc;
            bc.numTracks = maxBandTracks;
            for (int t = 0; t < maxBandTracks; ++t)
            {
                auto& c = bc.part[(size_t) t];
                c.type = bandDefaultType (t); c.on = true; c.channel = bandDefaultChannel (t); c.seed = (uint32_t) (t + 3); c.density = 1.0f; c.complexity = 1.0f;
                c.style = bandNumStyles (c.type) - 1;
            }
            int perTrack[maxBandTracks] = {};
            for (int64_t stp = 0; stp < 16 * 8; ++stp)
            {
                Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                BandEvent ev[Band::maxEventsPerStep];
                const int n = band.step (bc, h, stp, ev, Band::maxEventsPerStep);
                CHECK (n < Band::maxEventsPerStep, "15 tracks filled a whole step (%d events)", n);
                for (int i = 0; i < n; ++i)
                {
                    CHECK (ev[i].part >= 0 && ev[i].part < maxBandTracks, "bad track index");
                    CHECK (ev[i].channel == bc.part[(size_t) ev[i].part].channel, "track %d: wrong channel", ev[i].part);
                    if (! ev[i].isCC) ++perTrack[ev[i].part];
                }
            }
            for (int t = 0; t < maxBandTracks; ++t) CHECK (perTrack[t] > 0, "track %d (%s) never played", t + 1, bandTypeName (bc.part[(size_t) t].type));
            // HOLD / RING tracks don't jam
            bc.part[2].mode = ModeHold;
            bc.part[6].mode = ModeRing;
            Band b2;
            int held = 0;
            for (int64_t stp = 0; stp < 32; ++stp)
            {
                Harmony h; h.chord = prog[(stp / 16) % 4]; h.id = (int) (stp / 16);
                BandEvent ev[Band::maxEventsPerStep];
                const int n = b2.step (bc, h, stp, ev, Band::maxEventsPerStep);
                for (int i = 0; i < n; ++i) if (ev[i].part == 2 || ev[i].part == 6) ++held;
            }
            CHECK (held == 0, "HOLD / RING tracks shouldn't play patterns");
        }

        // HOLD notes: bass takes the bottom (down low), melody the top, pads everything
        {
            Notes played; played.add (60); played.add (64); played.add (67); played.add (71);
            const Chord cm = makeChord (0, "maj7");
            BandPartConfig c;
            c.type = BBass;
            Notes b = bandHoldNotes (c, played, cm);
            CHECK (b.size() == 1 && b[0] % 12 == 0 && b[0] >= 28 && b[0] <= 52, "HOLD bass should be a low C");
            c.type = BMelody;
            b = bandHoldNotes (c, played, cm);
            CHECK (b.size() == 1 && b[0] == 71, "HOLD melody should be the top note");
            c.type = BPad; c.octave = 1;
            b = bandHoldNotes (c, played, cm);
            CHECK (b.size() == 4 && b[0] == 72, "HOLD pad should be the whole chord, an octave up");
            c.type = BDrums;
            CHECK (bandHoldNotes (c, played, cm).empty(), "drums don't HOLD");
            Harmony h; h.key = 4;
            BandPartConfig k; k.keyMask = 1u << 4;
            CHECK (h.sitsOut (k), "key strip: E is muted");
            h.key = -1;
            CHECK (! h.sitsOut (k), "mouse clicks always play");
        }
        int styles = 0;
        for (int t = 0; t < numBandTypes; ++t) styles += bandNumStyles (t);
        std::printf ("Band: %d genres, %d types, %d styles, %ld notes generated in the test\n", numGenres, (int) numBandTypes, styles, total);
    }

    std::printf (failures == 0 ? "ALL TESTS PASSED\n" : "%d FAILURES\n", failures);
    return failures == 0 ? 0 : 1;
}
