// Developer test (Linux compile check only): drives the real processor with MIDI and
// snapshots the editor to PNG files.
#include "../plugin/PluginProcessor.h"
#include "../plugin/PluginEditor.h"

#include <juce_gui_basics/juce_gui_basics.h>
#include <cstdio>
#include <cstdlib>
#include <functional>
#include <map>

using namespace vesper;

static int failures = 0;
#define CHECK(c, ...) do { if (! (c)) { ++failures; std::printf ("FAIL: "); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)

struct Out { std::vector<juce::MidiMessage> msgs; std::vector<int> pos; float peak = 0; };

static Out run (VesperProcessor& p, juce::MidiBuffer in, int blocks = 1)
{
    Out o;
    for (int b = 0; b < blocks; ++b)
    {
        juce::AudioBuffer<float> buf (2, 512);
        juce::MidiBuffer m;
        if (b == 0) m = in;
        p.processBlock (buf, m);
        for (const auto meta : m) { o.msgs.push_back (meta.getMessage()); o.pos.push_back (meta.samplePosition + b * 512); }
        o.peak = juce::jmax (o.peak, buf.getMagnitude (0, 512));
    }
    return o;
}

struct FakeHead : public juce::AudioPlayHead
{
    double ppq = 0;
    bool playing = false, rec = false;
    juce::Optional<PositionInfo> getPosition() const override
    {
        PositionInfo i;
        i.setBpm (120.0);
        i.setIsPlaying (playing);
        i.setIsRecording (rec);
        i.setPpqPosition (ppq);
        return i;
    }
};

static juce::MidiBuffer note (int n, bool on, int vel = 100, int pos = 0)
{
    juce::MidiBuffer b;
    b.addEvent (on ? juce::MidiMessage::noteOn (1, n, (juce::uint8) vel) : juce::MidiMessage::noteOff (1, n), pos);
    return b;
}

static Notes onsOf (const Out& o, int channel = 1)
{
    Notes n;
    for (auto& m : o.msgs) if (m.isNoteOn() && m.getChannel() == channel) n.add (m.getNoteNumber());
    n.sort();
    return n;
}

static void setParam (VesperProcessor& p, const char* id, float value)
{
    auto* prm = p.apvts.getParameter (id);
    prm->setValueNotifyingHost (prm->convertTo0to1 (value));
}

int main()
{
    juce::ScopedJuceInitialiser_GUI gui;
    std::unique_ptr<juce::AudioProcessor> base (createPluginFilter());
    auto& p = dynamic_cast<VesperProcessor&> (*base);
    p.setPlayConfigDetails (0, 2, 48000.0, 512);
    p.prepareToPlay (48000.0, 512);
    run (p, {});

    // 1. SCALE mode: middle C (MIDI 60) = the 7ths row, I chord = Cmaj7 in C major
    setParam (p, ids::humanize, 0.0f);
    auto o = run (p, note (60, true));
    Notes n = onsOf (o);
    const Chord cmaj7 = makeChord (0, "maj7");
    CHECK (n.size() >= 3, "key 60 should play a chord, got %d notes", n.size());
    for (int i = 0; i < n.size(); ++i) CHECK ((pcMask (cmaj7) >> (n[i] % 12)) & 1, "note %d is not in Cmaj7", n[i]);
    CHECK (o.peak > 0.001f, "built-in keys should make sound");
    std::printf ("key C5 (60) -> ");
    for (int i = 0; i < n.size(); ++i) std::printf ("%s ", midiName (n[i], true).c_str());
    std::printf ("\n");

    o = run (p, note (60, false));
    int offs = 0;
    for (auto& m : o.msgs) if (m.isNoteOff()) ++offs;
    CHECK (offs == n.size(), "release should turn off every note (%d of %d)", offs, n.size());

    // D on the 7ths row (62) = Dm7, G (67) = G7
    o = run (p, note (67, true));
    n = onsOf (o);
    for (int i = 0; i < n.size(); ++i) CHECK ((pcMask (makeChord (7, "7")) >> (n[i] % 12)) & 1, "key 67 should be G7");
    run (p, note (67, false));

    // 2. VARY: same key three times gives a new voicing each time
    setParam (p, ids::vary, 1.0f);
    Notes last;
    for (int k = 0; k < 6; ++k)
    {
        o = run (p, note (62, true));
        n = onsOf (o);
        if (k > 0) CHECK (! n.sameAs (last), "VARY repeated the same voicing on hit %d", k);
        last = n;
        run (p, note (62, false));
    }
    setParam (p, ids::vary, 0.0f);

    // 3. Strum spreads the notes out
    setParam (p, ids::strum, 60.0f);
    o = run (p, note (48, true), 24);
    int first = 1 << 30, lastPos = 0;
    for (size_t i = 0; i < o.msgs.size(); ++i)
        if (o.msgs[i].isNoteOn()) { first = juce::jmin (first, o.pos[i]); lastPos = juce::jmax (lastPos, o.pos[i]); }
    CHECK (lastPos - first > 2000, "strum should spread notes (spread %d samples)", lastPos - first);
    std::printf ("strum spread: %d samples\n", lastPos - first);
    run (p, note (48, false));
    setParam (p, ids::strum, 0.0f);

    // 4. Bass on channel 2
    setParam (p, ids::bassMode, 2.0f);
    o = run (p, note (60, true));
    CHECK (onsOf (o, 2).size() == 1 && onsOf (o, 2)[0] % 12 == 0, "bass C should go out on channel 2");
    run (p, note (60, false));
    setParam (p, ids::bassMode, 0.0f);

    // 5. HOLD keeps the chord after release, next chord replaces it
    setParam (p, ids::hold, 1.0f);
    run (p, note (60, true));
    o = run (p, note (60, false));
    int offsHold = 0;
    for (auto& m : o.msgs) if (m.isNoteOff()) ++offsHold;
    CHECK (offsHold == 0, "HOLD should keep the chord ringing");
    o = run (p, note (65, true));
    int offsNext = 0;
    for (auto& m : o.msgs) if (m.isNoteOff()) ++offsNext;
    CHECK (offsNext > 0, "next chord should release the held one");
    run (p, note (65, false));
    setParam (p, ids::hold, 0.0f);
    p.panic();
    run (p, {});

    // 6. PADS mode: key 48 plays pad 1, notes above pass through untouched
    p.ui.keysMode = 1;
    p.applyUiState();
    o = run (p, note (48, true));
    n = onsOf (o);
    const Chord pad1 = p.ui.palette[0].chord;
    CHECK (n.size() >= 3, "pad 1 should play");
    for (int i = 0; i < n.size(); ++i) CHECK ((pcMask (pad1) >> (n[i] % 12)) & 1, "pad 1 wrong note");
    run (p, note (48, false));
    o = run (p, note (84, true));
    CHECK (onsOf (o).size() == 1 && onsOf (o)[0] == 84, "melody note should pass through");
    run (p, note (84, false));

    // 7. Recording -> MIDI file
    p.recording = true;
    for (int k : { 48, 52, 55 })
    {
        run (p, note (k, true), 20);
        run (p, note (k, false), 2);
    }
    p.recording = false;
    const auto f = p.exportRecording();
    CHECK (f.existsAsFile(), "recording should export a MIDI file");
    {
        juce::FileInputStream in (f);
        juce::MidiFile mf;
        CHECK (mf.readFrom (in), "exported MIDI should be readable");
        int ons = 0;
        if (mf.getNumTracks() > 0)
            for (auto* e : *mf.getTrack (0)) if (e->message.isNoteOn()) ++ons;
        CHECK (ons >= 9, "recorded MIDI should hold 3 chords, got %d note-ons", ons);
        std::printf ("recorded %d note-ons to %s\n", ons, f.getFullPathName().toRawUTF8());
    }
    CHECK (p.exportChord (makeChord (2, "m9"), Lush, -1).existsAsFile(), "single chord MIDI export");

    // 7b. MIDI loop: VESPER's output routed straight back into its input (bad FL port setup)
    for (int mode = 0; mode < 4; ++mode)
    {
        std::unique_ptr<juce::AudioProcessor> lb (createPluginFilter());
        auto& lp = dynamic_cast<VesperProcessor&> (*lb);
        lp.setPlayConfigDetails (0, 2, 48000.0, 512);
        lp.prepareToPlay (48000.0, 512);
        if (mode >= 2) { setParam (lp, ids::strum, 80.0f); setParam (lp, ids::vary, 1.0f); setParam (lp, ids::bassMode, 2.0f); }
        mode %= 2;
        lp.ui.keysMode = mode;
        lp.applyUiState();
        juce::MidiBuffer feed;
        juce::AudioBuffer<float> buf (2, 512);
        { juce::MidiBuffer m; lp.processBlock (buf, m); }
        feed.addEvent (juce::MidiMessage::noteOn (1, mode == 0 ? 60 : 84, (juce::uint8) 100), 0);
        int totalOns = 0;
        uint32_t chordsBefore = 0;
        for (int b = 0; b < 400; ++b)   // ~4 seconds
        {
            juce::MidiBuffer m = feed;
            if (b == 200) m.addEvent (juce::MidiMessage::noteOff (1, mode == 0 ? 60 : 84), 10);
            if (b == 250 && mode == 0) { chordsBefore = lp.playedCounter(); m.addEvent (juce::MidiMessage::noteOn (1, 65, (juce::uint8) 90), 30); }
            if (b == 300 && mode == 0) m.addEvent (juce::MidiMessage::noteOff (1, 65), 30);
            lp.processBlock (buf, m);
            for (const auto meta : m) if (meta.getMessage().isNoteOn()) ++totalOns;
            feed = m;                    // what went out comes back in next block
        }
        std::printf ("loop test (%s mode): %d note-ons in 4 s, loop caught %u time(s)\n", mode == 0 ? "SCALE" : "PADS", totalOns, lp.loopEvents.load());
        CHECK (totalOns < 40, "MIDI loop should be contained, got %d note-ons", totalOns);
        CHECK (lp.loopEvents.load() > 0, "loop should be reported");
        if (mode == 0) CHECK (lp.playedCounter() - chordsBefore == 1, "with the loop blocked, a new key should play exactly one chord (%u)", lp.playedCounter() - chordsBefore);
        if (lp.apvts.getRawParameterValue (ids::strum)->load() > 1.0f) mode += 2;
    }

    // 7b2. MIDI loop with HOLD tracks: play a few chords hard, let go - nothing may keep ringing
    for (int variant = 0; variant < 3; ++variant)
    {
        std::unique_ptr<juce::AudioProcessor> lb (createPluginFilter());
        auto& lp = dynamic_cast<VesperProcessor&> (*lb);
        lp.setPlayConfigDetails (0, 2, 48000.0, 512);
        lp.prepareToPlay (48000.0, 512);
        lp.applyBandGenre (House);
        for (int t = 0; t < numBandParts; ++t) lp.setTrackValue (t, TpOn, 1.0f);
        if (variant >= 1) lp.setAllHold (true);
        if (variant == 2) lp.setTrackValue (2, TpMode, (float) ModeRing);
        juce::MidiBuffer feed;
        juce::AudioBuffer<float> buf (2, 512);
        int on[16][128] = {};
        static const int keys[5] = { 60, 65, 67, 69, 62 };
        for (int b = 0; b < 700; ++b)
        {
            juce::MidiBuffer m = feed;   // what went out comes back in
            const int c = b / 60;
            if (c < 5 && b % 60 == 2) m.addEvent (juce::MidiMessage::noteOn (1, keys[c], (juce::uint8) 127), 20);
            if (c < 5 && b % 60 == 50) m.addEvent (juce::MidiMessage::noteOff (1, keys[c]), 40);
            lp.processBlock (buf, m);
            for (const auto meta : m)
            {
                const auto e = meta.getMessage();
                if (e.isNoteOn()) on[e.getChannel() - 1][e.getNoteNumber()] = 1;
                else if (e.isNoteOff()) on[e.getChannel() - 1][e.getNoteNumber()] = 0;
                else if (e.isAllNotesOff()) for (int n = 0; n < 128; ++n) on[e.getChannel() - 1][n] = 0;
            }
            feed = m;
        }
        int ringing = 0, ringBass = 0;
        for (int ch = 0; ch < 16; ++ch) for (int v : on[ch]) { if (variant == 2 && ch == 1) ringBass += v; else ringing += v; }
        std::printf ("loop + HOLD (variant %d): loop caught %u time(s), %d notes still ringing after letting go\n", variant, lp.loopEvents.load(), ringing);
        CHECK (ringing == 0, "loop + HOLD variant %d: %d notes left ringing", variant, ringing);
        if (variant == 2) CHECK (ringBass == 1, "RING bass should keep exactly its last note until the next key (%d)", ringBass);
    }

    // 7c. no loop: two fast chords at the same velocity both still play
    {
        std::unique_ptr<juce::AudioProcessor> nb (createPluginFilter());
        auto& np = dynamic_cast<VesperProcessor&> (*nb);
        np.setPlayConfigDetails (0, 2, 48000.0, 512);
        np.prepareToPlay (48000.0, 512);
        setParam (np, ids::humanize, 0.0f);
        run (np, {});
        const auto before = np.playedCounter();
        run (np, note (60, true));
        run (np, note (64, true));   // E on the 7ths row, its note 64 was just sent by the Cmaj7 above
        run (np, note (67, true));
        CHECK (np.playedCounter() - before == 3, "fast playing without a loop must not be filtered (%u chords)", np.playedCounter() - before);
        CHECK (np.loopEvents.load() == 0, "no loop should be reported in normal playing");
        // stabbing the same chord 16 times, 8th notes at 120 bpm, same velocity every time
        const auto before2 = np.playedCounter();
        for (int k = 0; k < 16; ++k)
        {
            run (np, note (64, true));
            for (int b = 0; b < 10; ++b) run (np, {});
            run (np, note (64, false));
            for (int b = 0; b < 10; ++b) run (np, {});
        }
        CHECK (np.playedCounter() - before2 == 16, "repeated stabs must all play (%u of 16)", np.playedCounter() - before2);
        CHECK (np.loopEvents.load() == 0, "stabs must not look like a loop");
    }

    // 7d. AUTO REC follows FL's record button and keeps the song position
    {
        std::unique_ptr<juce::AudioProcessor> ab (createPluginFilter());
        auto& ap = dynamic_cast<VesperProcessor&> (*ab);
        ap.setPlayConfigDetails (0, 2, 48000.0, 512);
        ap.prepareToPlay (48000.0, 512);
        FakeHead head;
        ap.setPlayHead (&head);
        // an old manual take that should be replaced
        ap.recording = true;
        run (ap, note (60, true));
        run (ap, note (60, false));
        ap.recording = false;
        const double beatsPerBlock = 512.0 / (48000.0 * 60.0 / 120.0);
        auto step = [&] (juce::MidiBuffer m) { run (ap, m); head.ppq += beatsPerBlock; };
        head.playing = head.rec = true;
        head.ppq = 0;
        step ({});
        CHECK (ap.recording.load(), "AUTO REC should start when FL records");
        while (head.ppq < 8.0) step ({});            // bar 3
        const double chordAt = head.ppq;
        step (note (64, true));
        for (int b = 0; b < 40; ++b) step ({});
        step (note (64, false));
        head.rec = false;
        step ({});
        CHECK (! ap.recording.load(), "AUTO REC should stop when FL stops recording");
        CHECK (ap.takeSynced.load(), "take should be marked as synced to the song");
        const auto f = ap.exportRecording();
        juce::FileInputStream in (f);
        juce::MidiFile mf;
        mf.readFrom (in);
        double firstTick = -1;
        int ons = 0;
        for (int tr = 0; tr < mf.getNumTracks(); ++tr)
            for (auto* e : *mf.getTrack (tr))
                if (e->message.isNoteOn()) { if (firstTick < 0 || e->message.getTimeStamp() < firstTick) firstTick = e->message.getTimeStamp(); ++ons; }
        std::printf ("auto-rec take: %d note-ons, first at tick %.0f (chord played at beat %.3f = tick %.0f)\n", ons, firstTick, chordAt, chordAt * 960.0);
        CHECK (std::abs (firstTick - chordAt * 960.0) < 30.0, "synced take should keep the song position");
        CHECK (ons >= 3 && ons <= 6, "only the new take should be in the file (%d)", ons);
        ap.setPlayHead (nullptr);
    }

    // 7e. PLAYING STYLES: every style, synced to a fake FL transport at 120 bpm
    {
        struct Ev { int64_t t; juce::MidiMessage m; };
        auto session = [&] (std::function<void (VesperProcessor&)> setup, std::function<void (VesperProcessor&, int, juce::MidiBuffer&)> perBlock,
                            int blocks, std::vector<Ev>& evs, bool playingHost = true)
        {
            std::unique_ptr<juce::AudioProcessor> b (createPluginFilter());
            auto& sp = dynamic_cast<VesperProcessor&> (*b);
            sp.setPlayConfigDetails (0, 2, 48000.0, 512);
            sp.prepareToPlay (48000.0, 512);
            FakeHead head;
            head.playing = playingHost;
            sp.setPlayHead (&head);
            setParam (sp, ids::humanize, 0.0f);
            setup (sp);
            for (int blk = 0; blk < blocks; ++blk)
            {
                juce::MidiBuffer m;
                perBlock (sp, blk, m);
                juce::AudioBuffer<float> buf (2, 512);
                sp.processBlock (buf, m);
                for (const auto meta : m) evs.push_back ({ (int64_t) blk * 512 + meta.samplePosition, meta.getMessage() });
                head.ppq += 512.0 / 24000.0;
            }
            sp.setPlayHead (nullptr);
        };
        auto stuck = [] (const std::vector<Ev>& evs)
        {
            int on[16][128] = {};
            for (auto& e : evs)
            {
                if (e.m.isNoteOn()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 1;
                else if (e.m.isNoteOff()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 0;
            }
            int n = 0;
            for (auto& ch : on) for (int v : ch) n += v;
            return n;
        };
        auto holdChord = [] (int key, int pressAt, int releaseAt)
        {
            return [key, pressAt, releaseAt] (VesperProcessor&, int blk, juce::MidiBuffer& m)
            {
                if (blk == pressAt) m.addEvent (juce::MidiMessage::noteOn (1, key, (juce::uint8) 100), 100);
                if (blk == releaseAt) m.addEvent (juce::MidiMessage::noteOff (1, key), 100);
            };
        };

        int okStyles = 0;
        for (int r = 0; r < numRhythms; ++r)
        {
            std::vector<Ev> evs;
            session ([r] (VesperProcessor& sp) { setParam (sp, rhythmInfo (r).id, 1.0f); }, holdChord (60, 10, 200), 260, evs);
            int ons = 0;
            std::vector<int64_t> hitTimes;
            for (auto& e : evs)
                if (e.m.isNoteOn())
                {
                    ++ons;
                    if (hitTimes.empty() || e.t - hitTimes.back() > 50) hitTimes.push_back (e.t);
                }
            const int left = stuck (evs);
            CHECK (ons >= 3, "%s: only %d notes", rhythmInfo (r).name, ons);
            CHECK (left == 0, "%s: %d stuck notes after release", rhythmInfo (r).name, left);
            // after the first hit, every hit sits on the style's grid (straight styles)
            const double stepSamples = rateBeats (rhythmDefaultRate (r)) * 24000.0;
            int offGrid = 0;
            for (size_t i = 1; i < hitTimes.size(); ++i)
            {
                const double rel = (double) hitTimes[i] / stepSamples;
                if (std::abs (rel - std::round (rel)) * stepSamples > 3.0) ++offGrid;
            }
            CHECK (offGrid == 0, "%s: %d hits off the grid", rhythmInfo (r).name, offGrid);
            if (ons >= 3 && left == 0 && offGrid == 0) ++okStyles;
        }
        std::printf ("playing styles: %d of %d play in time with no stuck notes\n", okStyles, (int) numRhythms);

        // pulse at 1/8 for two beats holds exactly 4 hits; SOFT is quieter; STACCATO is shorter
        auto pulseStats = [&] (std::function<void (VesperProcessor&)> extra, int& hits, double& avgVel, double& avgLen)
        {
            std::vector<Ev> evs;
            session ([&extra] (VesperProcessor& sp) { setParam (sp, rhythmInfo (RPulse).id, 1.0f); extra (sp); },
                     holdChord (60, 0, 94), 140, evs);
            std::map<int, int64_t> start;
            hits = 0; avgVel = 0; avgLen = 0;
            int lens = 0, ons = 0;
            int64_t lastHit = -1000;
            for (auto& e : evs)
            {
                const int n = e.m.getNoteNumber();
                if (e.m.isNoteOn()) { start[n] = e.t; avgVel += e.m.getVelocity(); ++ons; if (e.t - lastHit > 50) { ++hits; lastHit = e.t; } }
                else if (e.m.isNoteOff() && start.count (n)) { avgLen += (double) (e.t - start[n]); ++lens; start.erase (n); }
            }
            avgVel /= juce::jmax (1, ons);
            avgLen /= juce::jmax (1, lens);
        };
        int h1, h2, h3; double v1, v2, v3, l1, l2, l3;
        pulseStats ([] (VesperProcessor&) {}, h1, v1, l1);
        pulseStats ([] (VesperProcessor& sp) { setParam (sp, feelInfo (FSoft).id, 1.0f); }, h2, v2, l2);
        pulseStats ([] (VesperProcessor& sp) { setParam (sp, feelInfo (FStaccato).id, 1.0f); }, h3, v3, l3);
        std::printf ("pulse: %d hits in 2 beats, vel %.0f (soft %.0f), length %.0f samples (staccato %.0f)\n", h1, v1, v2, l1, l3);
        CHECK (h1 == 4 || h1 == 5, "pulse at 1/8 should hit 4 times in 2 beats (%d)", h1);
        CHECK (v2 < v1 - 15, "SOFT should be clearly quieter");
        CHECK (l3 < l1 * 0.7, "STACCATO should be shorter");

        // SWING moves the off-beats later
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { setParam (sp, rhythmInfo (RPulse).id, 1.0f); setParam (sp, timingInfo (TSwing).id, 1.0f); },
                     holdChord (60, 0, 94), 120, evs);
            std::vector<int64_t> hits;
            for (auto& e : evs) if (e.m.isNoteOn() && (hits.empty() || e.t - hits.back() > 50)) hits.push_back (e.t);
            CHECK (hits.size() >= 3 && (hits[1] - hits[0]) > (hits[2] - hits[1]), "SWING should make the off-beat late");
        }

        // upper extension: hold a chord, press EXT (on-screen pad), notes appear above, release, they stop
        {
            std::vector<Ev> evs;
            int chordTop = 0;
            session ([] (VesperProcessor&) {},
                     [] (VesperProcessor& sp, int blk, juce::MidiBuffer& m)
                     {
                         if (blk == 2) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                         if (blk == 20) sp.uiExt (true);
                         if (blk == 60) sp.uiExt (false);
                         if (blk == 80) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                     }, 100, evs);
            std::vector<int> chord, ext;
            for (auto& e : evs)
                if (e.m.isNoteOn()) (e.t < 20 * 512 ? chord : ext).push_back (e.m.getNoteNumber());
            for (int n : chord) chordTop = juce::jmax (chordTop, n);
            bool above = ! ext.empty();
            for (int n : ext) above = above && n > chordTop;
            CHECK (above, "EXT should add notes above the chord (%d ext notes)", (int) ext.size());
            int extOffs = 0;
            for (auto& e : evs) if (e.m.isNoteOff() && e.t >= 60 * 512 && e.t < 61 * 512) ++extOffs;
            CHECK (extOffs == (int) ext.size(), "releasing EXT should stop just the extension (%d of %d)", extOffs, (int) ext.size());
            CHECK (stuck (evs) == 0, "EXT left stuck notes");
            std::printf ("EXT over Cmaj7: ");
            for (int n : ext) std::printf ("%s ", midiName (n, true).c_str());
            std::printf ("\n");
        }

        // EXT as a waterfall: cascades down in time
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { setParam (sp, ids::extMode, (float) ExtWaterfall); },
                     [] (VesperProcessor& sp, int blk, juce::MidiBuffer& m)
                     {
                         if (blk == 2) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                         if (blk == 20) sp.uiExt (true);
                         if (blk == 90) sp.uiExt (false);
                         if (blk == 100) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                     }, 120, evs);
            std::vector<int> cascade;
            for (auto& e : evs) if (e.m.isNoteOn() && e.t >= 20 * 512) cascade.push_back (e.m.getNoteNumber());
            bool falling = cascade.size() >= 4;
            for (size_t i = 1; i < cascade.size(); ++i) falling = falling && cascade[i] < cascade[i - 1];
            CHECK (falling, "EXT waterfall should fall note by note (%d notes)", (int) cascade.size());
            CHECK (stuck (evs) == 0, "EXT waterfall left stuck notes");
            std::printf ("EXT waterfall: ");
            for (int n : cascade) std::printf ("%s ", midiName (n, true).c_str());
            std::printf ("\n");
        }

        // STYLES ON EXT: the extension joins an arpeggio
        {
            std::vector<Ev> evs;
            int maxNote = 0, maxBefore = 0;
            session ([] (VesperProcessor& sp) { setParam (sp, rhythmInfo (RArpUp).id, 1.0f); setParam (sp, ids::extStyles, 1.0f); },
                     [] (VesperProcessor& sp, int blk, juce::MidiBuffer& m)
                     {
                         if (blk == 2) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                         if (blk == 60) sp.uiExt (true);
                         if (blk == 140) sp.uiExt (false);
                         if (blk == 150) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                     }, 170, evs);
            for (auto& e : evs)
                if (e.m.isNoteOn()) { if (e.t < 60 * 512) maxBefore = juce::jmax (maxBefore, e.m.getNoteNumber()); else if (e.t < 140 * 512) maxNote = juce::jmax (maxNote, e.m.getNoteNumber()); }
            CHECK (maxNote > maxBefore, "with STYLES ON EXT the arpeggio should climb into the extension");
            CHECK (stuck (evs) == 0, "STYLES ON EXT left stuck notes");
        }

        // learn a controller key as the EXT button, then use it
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { sp.learnArmed.store (true); },
                     [] (VesperProcessor&, int blk, juce::MidiBuffer& m)
                     {
                         if (blk == 1) m.addEvent (juce::MidiMessage::noteOn (1, 120, (juce::uint8) 100), 0);
                         if (blk == 2) m.addEvent (juce::MidiMessage::noteOff (1, 120), 0);
                         if (blk == 5) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                         if (blk == 10) m.addEvent (juce::MidiMessage::noteOn (1, 120, (juce::uint8) 100), 0);
                         if (blk == 30) m.addEvent (juce::MidiMessage::noteOff (1, 120), 0);
                         if (blk == 40) m.addEvent (juce::MidiMessage::noteOff (1, 60), 0);
                     }, 50, evs);
            int beforeExt = 0, withExt = 0;
            for (auto& e : evs) if (e.m.isNoteOn()) (e.t < 10 * 512 ? beforeExt : withExt) += 1;
            CHECK (beforeExt >= 3 && withExt >= 1, "learned key should trigger the extension (%d / %d)", beforeExt, withExt);
            CHECK (stuck (evs) == 0, "learned EXT left stuck notes");
        }

        // SWELL sends rising expression
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { setParam (sp, feelInfo (FSwell).id, 1.0f); }, holdChord (60, 2, 120), 130, evs);
            int first = -1, last = -1;
            for (auto& e : evs) if (e.m.isController() && e.m.getControllerNumber() == 11 && e.m.getChannel() == 1) { if (first < 0) first = e.m.getControllerValue(); last = e.m.getControllerValue(); }
            CHECK (first >= 0 && last > first + 60, "SWELL should ramp CC11 up (%d -> %d)", first, last);
        }

        // transport stopped: styles still run on VESPER's own clock
        {
            std::vector<Ev> evs;
            session ([] (VesperProcessor& sp) { setParam (sp, rhythmInfo (RArpUpDown).id, 1.0f); }, holdChord (60, 3, 100), 120, evs, false);
            int ons = 0;
            for (auto& e : evs) if (e.m.isNoteOn()) ++ons;
            CHECK (ons >= 8 && stuck (evs) == 0, "styles should play with FL stopped (%d notes)", ons);
        }
    }

    // 7f. BAND: in time with FL, on its own channels, follows the chords, stops cleanly, links to copies
    {
        struct Ev { int64_t t; juce::MidiMessage m; };
        struct Rig
        {
            std::unique_ptr<juce::AudioProcessor> base { createPluginFilter() };
            VesperProcessor& p = dynamic_cast<VesperProcessor&> (*base);
            FakeHead head;
            std::vector<Ev> evs;
            Rig (int genre, bool playing)
            {
                p.setPlayConfigDetails (0, 2, 48000.0, 512);
                p.prepareToPlay (48000.0, 512);
                head.playing = playing;
                p.setPlayHead (&head);
                setParam (p, ids::humanize, 0.0f);
                p.applyBandGenre (genre);
            }
            ~Rig() { p.setPlayHead (nullptr); }
            void block (int blk, juce::MidiBuffer m)
            {
                juce::AudioBuffer<float> buf (2, 512);
                p.processBlock (buf, m);
                for (const auto meta : m) evs.push_back ({ (int64_t) blk * 512 + meta.samplePosition, meta.getMessage() });
                head.ppq += 512.0 / 24000.0;
            }
        };
        auto stuckNotes = [] (const std::vector<Ev>& evs)
        {
            int on[16][128] = {};
            for (auto& e : evs)
            {
                if (e.m.isNoteOn()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 1;
                else if (e.m.isNoteOff()) on[e.m.getChannel() - 1][e.m.getNoteNumber()] = 0;
            }
            int n = 0;
            for (auto& ch : on) for (int v : ch) n += v;
            return n;
        };
        auto at = [] (int key, bool on, int pos = 0)
        {
            juce::MidiBuffer m;
            m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), pos);
            return m;
        };
        constexpr int beat = 24000;   // samples per beat at 120 bpm / 48 kHz

        // A. FL playing: drums on the grid, parts on their channels, a chord change moves the bass
        {
            Rig r (House, true);
            r.p.recording = true;
            for (int blk = 0; blk < 800; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                auto event = [&] (int64_t sample, int key, bool on) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                event (1124, 60, true);                 // Cmaj7, a hair after beat 1
                event (8 * beat, 69, true);             // Am7 on bar 3
                event (8 * beat + 10, 60, false);
                event (16 * beat, 69, false);           // let go on bar 5
                r.block (blk, m);
            }
            int kicks = 0, offGrid = 0, bassC = 0, bassA = 0, mel = 0, wrongCh = 0, keysCh2 = 0;
            for (auto& e : r.evs)
            {
                if (! e.m.isNoteOn()) continue;
                const int ch = e.m.getChannel(), n = e.m.getNoteNumber();
                if (ch == 10 && n == Band::Kick) { ++kicks; if (e.t > 2000 && e.t % beat != 0 && e.t % (16 * beat) < 15 * beat) ++offGrid; }   // fills live in the last beat of a phrase
                if (ch == 2) { if (e.t < 8 * beat && n % 12 == 0) ++bassC; if (e.t >= 8 * beat && e.t < 16 * beat && n % 12 == 9) ++bassA; }
                if (ch == 2 && e.t >= 8 * beat && e.t < 16 * beat && n % 12 != 9 && n % 12 != 4 && n % 12 != 0) ++keysCh2;
                if (ch == 3) ++mel;
                if (ch != 1 && ch != 2 && ch != 3 && ch != 10) ++wrongCh;
            }
            std::printf ("band (house): %d kicks, %d bass on C, %d bass on A, %d melody notes\n", kicks, bassC, bassA, mel);
            CHECK (kicks >= 15 && offGrid == 0, "house kicks should land on the beat (%d kicks, %d off grid)", kicks, offGrid);
            CHECK (bassC > 0 && bassA > 0 && keysCh2 == 0, "bass should follow the chords on channel 2 (C %d, A %d, other %d)", bassC, bassA, keysCh2);
            CHECK (mel > 4 && wrongCh == 0, "melody on channel 3 and nothing on stray channels (%d, %d)", mel, wrongCh);
            // the take: one named track per part, every part as its own file
            {
                const auto f = r.p.exportRecording();
                juce::FileInputStream in (f);
                juce::MidiFile mf;
                CHECK (in.openedOk() && mf.readFrom (in), "take file should read back");
                juce::StringArray names;
                int mixed = 0, overlaps = 0, total = 0;
                for (int tr = 1; tr < mf.getNumTracks(); ++tr)
                {
                    int ch = 0;
                    bool on[128] = {};
                    for (auto* e : *mf.getTrack (tr))
                    {
                        const auto& m = e->message;
                        if (m.isTrackNameEvent()) names.add (m.getTextFromTextMetaEvent());
                        if (! (m.isNoteOn() || m.isNoteOff())) continue;
                        if (ch == 0) ch = m.getChannel();
                        if (m.getChannel() != ch) ++mixed;
                        if (m.isNoteOn()) { if (on[m.getNoteNumber()]) ++overlaps; on[m.getNoteNumber()] = true; ++total; }
                        else on[m.getNoteNumber()] = false;
                    }
                }
                std::printf ("take file: %d tracks (%s), %d notes\n", mf.getNumTracks(), names.joinIntoString (", ").toRawUTF8(), total);
                CHECK (mf.getNumTracks() == 5 && names.contains ("Chords") && names.contains ("Bass") && names.contains ("Melody") && names.contains ("Drums"),
                       "take should have a track per part");
                CHECK (mixed == 0 && overlaps == 0 && total > 50, "tracks should be clean (%d mixed, %d overlapping)", mixed, overlaps);
                const auto dir = r.p.exportPartsFolder();
                const auto files = dir.findChildFiles (juce::File::findFiles, false, "*.mid");
                CHECK (files.size() == 5, "SAVE PARTS should write 4 parts + all parts (%d)", files.size());
                dir.deleteRecursively();
            }
            int late = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn() && e.t > 16 * beat + beat / 2) ++late;
            CHECK (late == 0 && stuckNotes (r.evs) == 0 && ! r.p.bandPlaying.load(), "band should stop cleanly after you let go (%d late, %d stuck)", late, stuckNotes (r.evs));
        }

        // B. a chord that lands just after a band step still makes that step
        {
            Rig r (House, true);
            const int64_t press = 8 * beat + 1200;   // 25 ms late
            for (int blk = 0; blk < 420; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                if (blk == 0) m.addEvent (juce::MidiMessage::noteOn (1, 60, (juce::uint8) 100), 0);
                if (press >= t0 && press < t0 + 512) m.addEvent (juce::MidiMessage::noteOn (1, 65, (juce::uint8) 100), (int) (press - t0));
                r.block (blk, m);
            }
            int64_t firstF = -1;
            for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 2 && e.t >= press && e.m.getNoteNumber() % 12 == 5) { firstF = e.t; break; }
            CHECK (firstF >= press && firstF < press + 600, "bass should catch a slightly late chord right away (%lld after)", (long long) (firstF - press));
        }

        // C. FL stopped: your first chord is bar 1, the band starts right there
        {
            Rig r (House, false);
            const int64_t press = 5 * 512 + 200;
            for (int blk = 0; blk < 200; ++blk) r.block (blk, blk == 5 ? at (60, true, 200) : juce::MidiBuffer());
            int64_t firstKick = -1;
            for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 10 && e.m.getNoteNumber() == Band::Kick) { firstKick = e.t; break; }
            CHECK (firstKick == press, "free-running band should start on the chord (kick at %lld, chord at %lld)", (long long) firstKick, (long long) press);
            int kicks = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 10 && e.m.getNoteNumber() == Band::Kick) { ++kicks; CHECK ((e.t - press) % beat == 0, "free kicks off the beat"); }
            CHECK (kicks >= 3, "free-running kicks (%d)", kicks);
        }

        // D. NEVER stop mode keeps going after you let go, STOP ends it
        {
            Rig r (Trap, true);
            setParam (r.p, ids::bandStop, 2.0f);
            for (int blk = 0; blk < 400; ++blk)
            {
                juce::MidiBuffer m;
                if (blk == 1) m = at (60, true);
                if (blk == 20) m = at (60, false);
                if (blk == 300) r.p.stopBandFromUi();
                r.block (blk, m);
            }
            int after = 0, afterStop = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn()) { if (e.t > 40 * 512 && e.t < 300 * 512) ++after; if (e.t > 301 * 512) ++afterStop; }
            CHECK (after > 20 && afterStop == 0 && stuckNotes (r.evs) == 0, "NEVER mode should keep playing until STOP (%d, %d, stuck %d)", after, afterStop, stuckNotes (r.evs));
        }

        // E. every genre, every part on: no stuck notes, nothing out of MIDI range
        for (int g = 0; g < numGenres; ++g)
        {
            Rig r (g, true);
            for (int part = 0; part < numBandParts; ++part) setParam (r.p, ids::track (part, "On").toRawUTF8(), 1.0f);
            static const int keys[4] = { 62, 67, 60, 69 };
            for (int blk = 0; blk < 820; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                for (int c = 0; c < 4; ++c)
                {
                    const int64_t on = (int64_t) c * 4 * beat + 300, off = (int64_t) (c + 1) * 4 * beat + 200;
                    if (on >= t0 && on < t0 + 512) m.addEvent (juce::MidiMessage::noteOn (1, keys[c], (juce::uint8) 100), (int) (on - t0));
                    if (off >= t0 && off < t0 + 512) m.addEvent (juce::MidiMessage::noteOff (1, keys[c]), (int) (off - t0));
                }
                r.block (blk, m);
            }
            int ons = 0, chans = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn()) { ++ons; chans |= 1 << (e.m.getChannel() - 1); }
            CHECK (stuckNotes (r.evs) == 0, "%s band: %d stuck notes", genreShort (g), stuckNotes (r.evs));
            CHECK (ons > 100, "%s band: only %d notes", genreShort (g), ons);
            CHECK ((chans & 0x23e) == 0x23e, "%s band: every part should play on its channel (0x%x)", genreShort (g), chans);
        }

        // G. HOLD: a track plays exactly what you press, on its own channel, and lets go with the key
        {
            Rig r (House, true);
            setParam (r.p, ids::track (3, "On").toRawUTF8(), 1.0f);              // strings, channel 5
            setParam (r.p, ids::track (3, "Mode").toRawUTF8(), (float) ModeHold);
            for (int blk = 0; blk < 200; ++blk)
                r.block (blk, blk == 2 ? at (60, true) : (blk == 120 ? at (60, false) : juce::MidiBuffer()));
            Notes chord, held;
            int heldOns = 0;
            for (auto& e : r.evs)
                if (e.m.isNoteOn())
                {
                    if (e.m.getChannel() == 1 && e.t < 3 * 512) chord.add (e.m.getNoteNumber());
                    if (e.m.getChannel() == 5) { held.add (e.m.getNoteNumber()); ++heldOns; }
                }
            chord.unique(); held.unique();
            CHECK (held.sameAs (chord) && heldOns == chord.size(), "HOLD strings should play the chord once, as pressed (%d notes, %d hits, chord %d)", held.size(), heldOns, chord.size());
            int offAt = -1;
            for (auto& e : r.evs) if (e.m.isNoteOff() && e.m.getChannel() == 5) { offAt = (int) (e.t / 512); break; }
            CHECK (offAt == 120 && stuckNotes (r.evs) == 0, "HOLD should let go with the key (block %d)", offAt);
        }

        // H. RING: one hit per key, ringing past the key-up until the next key; FL stopping ends it
        {
            Rig r (House, true);
            setParam (r.p, ids::track (2, "Mode").toRawUTF8(), (float) ModeRing);   // bass, channel 2
            for (int blk = 0; blk < 300; ++blk)
            {
                juce::MidiBuffer m;
                if (blk == 2) m = at (60, true);
                if (blk == 10) m = at (60, false);
                if (blk == 100) m = at (65, true);
                if (blk == 110) m = at (65, false);
                if (blk == 250) r.head.playing = false;
                r.block (blk, m);
            }
            int ons = 0, cOff = -1, fOff = -1;
            for (auto& e : r.evs)
            {
                if (e.m.getChannel() != 2) continue;
                if (e.m.isNoteOn()) ++ons;
                if (e.m.isNoteOff() && e.m.getNoteNumber() % 12 == 0 && cOff < 0) cOff = (int) (e.t / 512);
                if (e.m.isNoteOff() && e.m.getNoteNumber() % 12 == 5 && fOff < 0) fOff = (int) (e.t / 512);
            }
            CHECK (ons == 2 && cOff == 100 && fOff == 250 && stuckNotes (r.evs) == 0,
                   "RING bass: 2 hits, C rings until F (%d), F until FL stops (%d), %d hits", cOff, fOff, ons);
        }

        // I. key strips: the bass sits out on E, VESPER's own chords sit out on D (the band keeps going)
        {
            Rig r (House, true);
            r.p.trackKeys[2].store (1 << 4);
            r.p.chordKeys.store (1 << 2);
            for (int blk = 0; blk < 700; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                auto event = [&] (int64_t sample, int key, bool on) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                event (300, 60, true);   event (4 * beat, 60, false);
                event (4 * beat, 64, true);   event (8 * beat, 64, false);
                event (8 * beat, 62, true);   event (12 * beat, 62, false);
                r.block (blk, m);
            }
            int bassOnC = 0, bassOnE = 0, chordsOnD = 0, drumsOnD = 0, bassOnD = 0;
            for (auto& e : r.evs)
            {
                if (! e.m.isNoteOn()) continue;
                const bool inC = e.t < 4 * beat, inE = e.t >= 4 * beat + 200 && e.t < 8 * beat, inD = e.t >= 8 * beat + 200 && e.t < 12 * beat;
                if (e.m.getChannel() == 2) { if (inC) ++bassOnC; if (inE) ++bassOnE; if (inD) ++bassOnD; }
                if (e.m.getChannel() == 1 && inD) ++chordsOnD;
                if (e.m.getChannel() == 10 && inD) ++drumsOnD;
            }
            CHECK (bassOnC > 0 && bassOnE == 0 && bassOnD > 0, "key strip: bass should sit out on E only (C %d, E %d, D %d)", bassOnC, bassOnE, bassOnD);
            CHECK (chordsOnD == 0 && drumsOnD > 0, "chord key strip: no chords on D but the band plays (chords %d, drums %d)", chordsOnD, drumsOnD);
            CHECK (stuckNotes (r.evs) == 0, "key strips: stuck notes");
        }

        // J. STACK: one note per key in the key's own octave, stacked 3rds in the key, octaves
        {
            Rig r (House, false);
            r.p.apvts.getParameter (ids::bandOn)->setValueNotifyingHost (0.0f);
            auto play = [&] (int key)
            {
                r.evs.clear();
                r.block (0, at (key, true));
                r.block (1, at (key, false));
                Notes n;
                for (auto& e : r.evs) if (e.m.isNoteOn() && e.m.getChannel() == 1) n.add (e.m.getNoteNumber());
                n.unique();
                return n;
            };
            setParam (r.p, ids::stack, (float) StackSingle);
            Notes a = play (60), b = play (67), c = play (74);
            CHECK (a.size() == 1 && a[0] == 60 && b.size() == 1 && b[0] == 67 && c.size() == 1 && c[0] == 74,
                   "STACK single: keys should play themselves in C major (%d %d %d)", a.size() ? a[0] : -1, b.size() ? b[0] : -1, c.size() ? c[0] : -1);
            setParam (r.p, ids::stack, (float) Stack3rds);
            setParam (r.p, ids::stackNotes, 1.0f);   // 3 notes
            a = play (62);
            CHECK (a.size() == 3 && a[0] == 62 && a[1] == 65 && a[2] == 69, "STACK 3rds x3 on D should be D F A");
            setParam (r.p, ids::stack, (float) StackOctaves);
            setParam (r.p, ids::stackNotes, 0.0f);
            a = play (60);
            CHECK (a.size() == 2 && a[0] == 60 && a[1] == 72, "STACK octaves on C should be C + C an octave up");
            setParam (r.p, ids::stack, 0.0f);
            a = play (60);
            CHECK (a.size() >= 3, "STACK chord should be back to the whole chord");
        }

        // K. tracks: add one (it gets a new instrument and a free channel), remove one (the rest move up)
        {
            Rig r (House, true);
            CHECK (r.p.numTracks.load() == defaultBandTracks, "6 tracks to start");
            CHECK (r.p.addTrack(), "add a track");
            CHECK (r.p.numTracks.load() == 7 && r.p.trackType (6) == BKeys && (int) r.p.trackValue (6, TpCh) == 7 && r.p.trackValue (6, TpOn) > 0.5f,
                   "new track 7 should be KEYS on channel 7 (type %d ch %d)", r.p.trackType (6), (int) r.p.trackValue (6, TpCh));
            for (int i = 0; i < 20; ++i) r.p.addTrack();
            CHECK (r.p.numTracks.load() == maxBandTracks, "15 tracks at most");
            uint32_t chans = 1;
            for (int t = 0; t < maxBandTracks; ++t) chans |= 1u << ((int) r.p.trackValue (t, TpCh) - 1);
            CHECK (chans == 0xffff, "15 tracks + chords should use all 16 channels (0x%x)", chans);
            for (int t = 0; t < maxBandTracks; ++t) r.p.setTrackValue (t, TpOn, 1.0f);
            for (int blk = 0; blk < 300; ++blk) r.block (blk, blk == 2 ? at (60, true) : (blk == 250 ? at (60, false) : juce::MidiBuffer()));
            uint32_t played = 0;
            for (auto& e : r.evs) if (e.m.isNoteOn()) played |= 1u << (e.m.getChannel() - 1);
            CHECK ((played & 0xffff) == 0xffff, "every channel should play with 15 tracks on (0x%x)", played);
            CHECK (stuckNotes (r.evs) == 0, "15 tracks: stuck notes");
            r.p.setTrackType (7, BDrums);
            CHECK (r.p.trackType (7) == BDrums && (int) std::lround (r.p.trackValue (7, TpMode)) == ModeJam, "retype a track");
            const int ch2 = (int) r.p.trackValue (1, TpCh);
            r.p.removeTrack (0);
            CHECK (r.p.numTracks.load() == 14 && r.p.trackType (0) == BCounter && (int) r.p.trackValue (0, TpCh) == ch2,
                   "removing track 1 should move track 2 up");
            r.p.setAllHold (true);
            CHECK (r.p.allHold(), "ALL HOLD");
            r.p.setAllHold (false);
            CHECK (! r.p.allHold(), "ALL HOLD off");
        }

        // L. a project saved with VESPER 1.5 (six fixed parts) loads into tracks 1-6
        {
            juce::XmlElement old ("PARAMS");
            auto add = [&old] (const juce::String& id, double v) { auto* e = old.createNewChildElement ("PARAM"); e->setAttribute ("id", id); e->setAttribute ("value", v); };
            add ("bBassOn", 1.0); add ("bBassStyle", 7.0); add ("bBassCh", 9.0);
            add ("bDrmOn", 1.0); add ("bDrmStyle", 1.0);
            add ("bMelOn", 0.0); add ("bandRole", 0.0);
            auto* u = old.createNewChildElement ("VESPER_UI");
            u->setAttribute ("seedbBass", "12345");
            juce::MemoryBlock mb;
            juce::AudioProcessor::copyXmlToBinary (old, mb);
            Rig r (Soul, false);
            r.p.addTrack();
            r.p.setTrackType (2, BPad);
            r.p.setStateInformation (mb.getData(), (int) mb.getSize());
            CHECK (r.p.numTracks.load() == 6 && r.p.trackType (2) == BBass && r.p.trackValue (2, TpOn) > 0.5f
                   && (int) r.p.trackValue (2, TpStyle) == 7 && (int) r.p.trackValue (2, TpCh) == 9 && r.p.bandSeed[2].load() == 12345u
                   && r.p.trackType (5) == BDrums && (int) r.p.trackValue (5, TpStyle) == 1,
                   "old project: bass should be track 3 (808, ch 9), drums track 6");
        }

        // M. HOLD stress: real playing (legato overlaps, repeats, fast changes, mode clicks while holding).
        //    Whenever no key is down, nothing may be sounding on a HOLD channel.
        for (int scenario = 0; scenario < 6; ++scenario)
        {
            Rig r (House, true);
            r.p.setAllHold (true);                                   // melody 3, counter 4, bass 2, strings 5, horns 6 -> HOLD
            for (int t = 0; t < numBandParts; ++t) r.p.setTrackValue (t, TpOn, 1.0f);
            if (scenario == 1) r.p.setTrackValue (3, TpCh, 1.0f);   // a HOLD track sharing the chords' channel
            if (scenario == 2) setParam (r.p, ids::hold, 1.0f);       // VESPER's own HOLD too
            if (scenario == 3) setParam (r.p, ids::stack, (float) StackSingle);
            if (scenario == 4) { r.p.setTrackValue (1, TpCh, 5.0f); r.p.setTrackValue (4, TpCh, 5.0f); }   // two HOLD tracks on one channel
            if (scenario == 5) setParam (r.p, rhythmInfo (RArpUpDown).id, 1.0f);   // a playing style on the chords
            juce::Random rnd (1234 + scenario);
            std::map<int64_t, std::vector<std::pair<int, bool>>> plan;   // sample -> (key, down)
            int64_t tcur = 2000;
            int prevKey = -1;
            for (int i = 0; i < 160; ++i)
            {
                const int key = rnd.nextInt (5) == 0 && prevKey >= 0 ? prevKey : 48 + rnd.nextInt (36);
                plan[tcur].push_back ({ key, true });
                const int64_t len = 2000 + rnd.nextInt (30000);
                int64_t next = tcur + len;
                const int style = rnd.nextInt (3);                       // 0 legato overlap, 1 gap, 2 same time
                int64_t release = style == 0 ? next + rnd.nextInt (6000) : (style == 1 ? next - rnd.nextInt (1500) - 1 : next);
                if (key == prevKey) release = std::max<int64_t> (release, tcur + 10);
                plan[release].push_back ({ key, false });
                prevKey = key;
                tcur = next;
            }
            const int64_t end = tcur + 48000;
            std::map<int, int> down;   // key -> times down
            int on[16][128] = {};
            int orphanChecks = 0, orphans = 0;
            const int blocks = (int) (end / 512) + 1;
            for (int blk = 0; blk < blocks; ++blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                for (auto it = plan.lower_bound (t0); it != plan.end() && it->first < t0 + 512; ++it)
                    for (auto& ev : it->second)
                        m.addEvent (ev.second ? juce::MidiMessage::noteOn (1, ev.first, (juce::uint8) (scenario >= 3 ? 127 : 90 + rnd.nextInt (37))) : juce::MidiMessage::noteOff (1, ev.first),
                                    (int) (it->first - t0));
                if (scenario == 0 && blk % 97 == 50) r.p.setTrackValue (3, TpMode, (float) ((blk / 97) % 3));   // click JAM / HOLD / RING while playing
                const size_t before = r.evs.size();
                for (const auto meta : m)
                {
                    const auto mm = meta.getMessage();
                    if (mm.isNoteOn()) ++down[mm.getNoteNumber()];
                    else if (mm.isNoteOff()) down[mm.getNoteNumber()] = 0;
                }
                r.block (blk, m);
                for (size_t i = before; i < r.evs.size(); ++i)
                {
                    const auto& e = r.evs[i].m;
                    if (e.isNoteOn()) on[e.getChannel() - 1][e.getNoteNumber()] = 1;
                    else if (e.isNoteOff()) on[e.getChannel() - 1][e.getNoteNumber()] = 0;
                }
                bool anyDown = false;
                for (auto& d : down) if (d.second > 0) anyDown = true;
                if (! anyDown && scenario != 2 && scenario != 0)
                {
                    ++orphanChecks;
                    int sounding = 0;
                    for (int ch : { 2, 3, 4, 5, 6 }) for (int n = 0; n < 128; ++n) sounding += on[ch - 1][n];
                    if (sounding > 0) { ++orphans; if (orphans < 4) std::printf ("  scenario %d block %d: %d HOLD notes still on with no key down\n", scenario, blk, sounding); }
                }
            }
            if (scenario == 2)
            {
                // VESPER's own HOLD keeps the last chord on purpose: the next chord or PANIC ends it
                r.p.panic();
                r.block (blocks, {});
            }
            std::printf ("HOLD stress %d: %d checks, %d with notes left ringing, %d stuck at the end, loop guard tripped %u times\n", scenario, orphanChecks, orphans, stuckNotes (r.evs), r.p.loopEvents.load());
            CHECK (r.p.loopEvents.load() == 0, "HOLD stress %d: the loop guard tripped without a loop", scenario);
            CHECK (orphans == 0 && stuckNotes (r.evs) == 0, "HOLD stress %d: notes left ringing (%d) / stuck (%d)", scenario, orphans, stuckNotes (r.evs));
        }

        // F. a band copy set to ONLY BASS plays the exact same bass line; the main VESPER leaves it out
        {
            auto script = [&] (int blk)
            {
                juce::MidiBuffer m;
                const int64_t t0 = (int64_t) blk * 512;
                auto event = [&] (int64_t sample, int key, bool on) { if (sample >= t0 && sample < t0 + 512) m.addEvent (on ? juce::MidiMessage::noteOn (1, key, (juce::uint8) 100) : juce::MidiMessage::noteOff (1, key), (int) (sample - t0)); };
                event (0, 60, true);
                event (8 * beat, 69, true);
                event (8 * beat + 5, 60, false);
                event (12 * beat, 65, true);
                event (12 * beat + 5, 69, false);
                event (16 * beat, 65, false);
                return m;
            };
            auto bassOf = [] (const std::vector<Ev>& evs)
            {
                std::vector<std::pair<int64_t, int>> v;
                for (auto& e : evs) if (e.m.isNoteOn() && e.m.getChannel() == 2) v.push_back ({ e.t, e.m.getNoteNumber() });
                return v;
            };
            std::vector<std::pair<int64_t, int>> reference;
            {
                Rig solo (Funk, true);
                for (int blk = 0; blk < 800; ++blk) solo.block (blk, script (blk));
                reference = bassOf (solo.evs);
            }
            for (int order = 0; order < 2; ++order)
            {
                Rig lead (Funk, true), copy (Funk, true);
                setParam (copy.p, ids::bandRole, 3.0f);   // ONLY BASS
                for (int blk = 0; blk < 800; ++blk)
                {
                    if (order == 0) { lead.block (blk, script (blk)); copy.block (blk, {}); }
                    else            { copy.block (blk, {}); lead.block (blk, script (blk)); }
                }
                const auto leadBass = bassOf (lead.evs), copyBass = bassOf (copy.evs);
                int copyOther = 0;
                for (auto& e : copy.evs) if (e.m.isNoteOn() && e.m.getChannel() != 2) ++copyOther;
                int matched = 0;
                for (auto& ref : reference)
                    for (auto& c : copyBass)
                        if (c.second == ref.second && c.first >= ref.first && c.first - ref.first <= (order == 0 ? 0 : 512)) { ++matched; break; }
                if (std::getenv ("VDEBUG"))
                {
                    for (auto& ref : reference) std::printf ("  ref %lld %d\n", (long long) ref.first, ref.second);
                    for (auto& c : copyBass) std::printf ("  copy %lld %d\n", (long long) c.first, c.second);
                }
                std::printf ("band copy (%s first): %d of %d bass notes match, main VESPER bass notes: %d\n",
                             order == 0 ? "main" : "copy", matched, (int) reference.size(), (int) leadBass.size());
                CHECK (reference.size() > 10 && matched == (int) reference.size(), "band copy should play the same bass line (%d of %d)", matched, (int) reference.size());
                CHECK (leadBass.size() <= 1 && copyOther == 0, "main VESPER should leave the bass to the copy (%d, %d)", (int) leadBass.size(), copyOther);
                CHECK (stuckNotes (lead.evs) == 0 && stuckNotes (copy.evs) == 0, "band copy: stuck notes");
            }
        }
    }

    // 8. state round trip
    p.ui.keyRoot = 7;
    p.ui.genre = Jazz;
    p.ui.palette[3].chord = makeChord (1, "7#9", 5);
    juce::MemoryBlock mb;
    p.getStateInformation (mb);
    std::unique_ptr<juce::AudioProcessor> base2 (createPluginFilter());
    auto& p2 = dynamic_cast<VesperProcessor&> (*base2);
    p2.setStateInformation (mb.getData(), (int) mb.getSize());
    CHECK (p2.ui.keyRoot == 7 && p2.ui.genre == Jazz && p2.ui.keysMode == 1, "state should restore key/genre/mode");
    CHECK (p2.ui.palette[3].chord == makeChord (1, "7#9", 5), "state should restore edited pads");

    // 9. editor screenshots (all three tabs, all themes)
    p.ui.keyRoot = 0;
    p.ui.genre = Soul;
    p.ui.keysMode = 0;
    p.setPalette (buildPalette (0, 0, Soul, 0));
    run (p, note (74, true));   // a 9th-row chord so the panels have something to show
    setParam (p, rhythmInfo (RArpUp).id, 1.0f);
    setParam (p, rhythmInfo (RWaterfall).id, 1.0f);
    setParam (p, feelInfo (FAccentTop).id, 1.0f);
    setParam (p, timingInfo (TSwing).id, 1.0f);
    p.extTrigType.store (2);
    p.extTrigNum.store (64);
    p.applyBandGenre (Trap);
    run (p, note (74, false));
    run (p, note (74, true));
    for (int tab = 0; tab < 5; ++tab)
    {
        p.ui.tab = tab;
        p.ui.theme = tab == 1 ? 1 : 0;
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_" + juce::String (tab) + ".png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
        std::printf ("editor tab %d -> %s (%dx%d)\n", tab, out.getFullPathName().toRawUTF8(), img.getWidth(), img.getHeight());
    }

    {
        p.ui.tab = 0;
        p.ui.theme = 2;
        p.ui.keysMode = 1;
        p.applyUiState();
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_pads.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
    }
    {
        // SPLIT: chords on the left, your own notes on the right
        std::unique_ptr<juce::AudioProcessor> sb (createPluginFilter());
        auto& sp = dynamic_cast<VesperProcessor&> (*sb);
        sp.setPlayConfigDetails (0, 2, 48000.0, 512);
        sp.prepareToPlay (48000.0, 512);
        setParam (sp, ids::humanize, 0.0f);
        sp.ui.split = true;
        sp.ui.splitNote = 60;
        sp.applyUiState();
        run (sp, {});

        auto so = run (sp, note (64, true, 90));
        int ons = 0, onNote = -1, onCh = -1, onVel = -1;
        for (auto& m : so.msgs) if (m.isNoteOn()) { ++ons; onNote = m.getNoteNumber(); onCh = m.getChannel(); onVel = m.getVelocity(); }
        CHECK (ons == 1 && onNote == 64 && onCh == 1 && onVel == 90, "split: right hand E should play just E (got %d notes, note %d ch %d vel %d)", ons, onNote, onCh, onVel);
        so = run (sp, note (48, true));
        Notes sn = onsOf (so);
        CHECK (sn.size() >= 3, "split: left hand C should play a chord, got %d notes", sn.size());
        for (int i = 0; i < sn.size(); ++i) CHECK ((pcMask (makeChord (0, "")) >> (sn[i] % 12)) & 1, "split: left C (triads row) should be C major");
        // settings change while the right-hand key is down: its note-off still lands
        sp.ui.split = false;
        sp.applyUiState();
        so = run (sp, note (64, false));
        int offs = 0;
        for (auto& m : so.msgs) if (m.isNoteOff() && m.getNoteNumber() == 64) ++offs;
        CHECK (offs == 1, "split: E must be released after split was switched off (%d offs)", offs);
        so = run (sp, note (48, false));
        offs = 0;
        for (auto& m : so.msgs) if (m.isNoteOff()) ++offs;
        CHECK (offs == sn.size(), "split: releasing the left key should end the chord (%d of %d)", offs, sn.size());

        // right hand on channel 5, an octave up, snapped into C major
        sp.ui.split = true;
        sp.ui.rightCh = 5;
        sp.ui.rightOct = 1;
        sp.ui.rightSnap = true;
        sp.applyUiState();
        so = run (sp, note (61, true));
        onNote = onCh = -1; ons = 0;
        for (auto& m : so.msgs) if (m.isNoteOn()) { ++ons; onNote = m.getNoteNumber(); onCh = m.getChannel(); }
        CHECK (ons == 1 && onNote == 72 && onCh == 5, "split: C# +1 oct snapped should be C on ch 5 (got %d on ch %d)", onNote, onCh);
        so = run (sp, note (61, false));
        offs = 0;
        for (auto& m : so.msgs) if (m.isNoteOff() && m.getNoteNumber() == 72 && m.getChannel() == 5) ++offs;
        CHECK (offs == 1, "split: snapped note should turn off on ch 5");

        // left hand chord family: 9THS under the split
        sp.ui.leftRow = 6;
        sp.applyUiState();
        so = run (sp, note (48, true));
        sn = onsOf (so);
        bool hasNinth = false;
        for (int i = 0; i < sn.size(); ++i) { hasNinth |= sn[i] % 12 == 2; CHECK ((pcMask (makeChord (0, "maj9")) >> (sn[i] % 12)) & 1, "split: 9THS family C should be Cmaj9"); }
        CHECK (hasNinth, "split: 9THS family chord should have the 9th");
        run (sp, note (48, false));

        // PADS mode: the octave left of the split plays pads 13-24
        sp.ui.keysMode = 1;
        sp.ui.padBank = 1;
        sp.applyUiState();
        so = run (sp, note (48, true));
        sn = onsOf (so);
        const auto pad13 = sp.ui.palette[12].chord;
        CHECK (sn.size() >= 3, "split pads: key 48 should play pad 13");
        for (int i = 0; i < sn.size(); ++i) CHECK ((pcMask (pad13) >> (sn[i] % 12)) & 1, "split pads: note %d not in pad 13", sn[i]);
        run (sp, note (48, false));

        // learn the split point from the next key
        sp.splitLearnArmed.store (true);
        const auto before = sp.splitLearnCount.load();
        so = run (sp, note (55, true));
        int any = 0;
        for (auto& m : so.msgs) if (m.isNoteOn()) ++any;
        CHECK (sp.splitLearned.load() == 55 && sp.splitLearnCount.load() == before + 1 && any == 0,
               "split learn: key 55 should be learned silently");
        run (sp, note (55, false));
        std::printf ("split keyboard: ok\n");

        // the editor with split on (screenshot)
        sp.ui.keysMode = 0; sp.ui.leftRow = -1; sp.ui.rightCh = 0; sp.ui.rightOct = 0; sp.ui.rightSnap = false; sp.ui.tab = 1;
        sp.ui.splitNote = 60; sp.ui.leftRow = 5;
        sp.applyUiState();
        std::unique_ptr<juce::AudioProcessorEditor> ed (sp.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_split.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
    }
    {
        // the BAND tab with more tracks, HOLD / RING and key strips
        p.addTrack();
        p.addTrack();
        p.setTrackValue (3, TpMode, (float) ModeHold);
        p.setTrackValue (7, TpMode, (float) ModeRing);
        p.trackKeys[2].store ((1 << 4) | (1 << 11));
        p.chordKeys.store (1 << 9);
        setParam (p, ids::bandSwing, 33.0f);
        p.ui.tab = 4;
        p.ui.theme = 0;
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_band_tracks.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
    }
    {
        // a fresh VESPER's BAND tab: every part off
        std::unique_ptr<juce::AudioProcessor> fb (createPluginFilter());
        auto& fp = dynamic_cast<VesperProcessor&> (*fb);
        fp.ui.tab = 4;
        std::unique_ptr<juce::AudioProcessorEditor> ed (fp.createEditor());
        ed->setVisible (true);
        for (int i = 0; i < 6; ++i) juce::MessageManager::getInstance()->runDispatchLoopUntil (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_band_off.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
    }
    std::printf (failures == 0 ? "PROCESSOR TESTS PASSED\n" : "%d FAILURES\n", failures);
    return failures == 0 ? 0 : 1;
}
