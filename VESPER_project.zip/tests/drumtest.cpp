// Developer test (Linux compile check only): VESPER DRUMS end to end with a made-up drum folder.
#include "../drums/DrumProcessor.h"
#include "../drums/DrumEditor.h"

#include <juce_gui_basics/juce_gui_basics.h>
#include <cstdio>

using namespace drums;

static int failures = 0;
#define CHECK(c, ...) do { if (! (c)) { ++failures; std::printf ("FAIL: "); std::printf (__VA_ARGS__); std::printf ("\n"); } } while (0)

static void writeWav (const juce::File& f, double freq, double seconds, bool noise)
{
    f.getParentDirectory().createDirectory();
    juce::WavAudioFormat wav;
    f.deleteFile();
    std::unique_ptr<juce::OutputStream> os (f.createOutputStream().release());
    std::unique_ptr<juce::AudioFormatWriter> w (wav.createWriterFor (os.get(), 44100.0, 1, 16, {}, 0));
    if (w == nullptr) return;
    os.release();
    const int n = (int) (seconds * 44100.0);
    juce::AudioBuffer<float> b (1, n);
    juce::Random r (42);
    for (int i = 0; i < n; ++i)
    {
        const float env = std::exp (-3.0f * (float) i / (float) n);
        const float v = noise ? r.nextFloat() * 2.0f - 1.0f : std::sin (2.0f * juce::MathConstants<float>::pi * (float) freq * (float) i / 44100.0f);
        b.setSample (0, i, 0.8f * env * v);
    }
    w->writeFromAudioSampleBuffer (b, 0, n);
}

struct Head : public juce::AudioPlayHead
{
    double ppq = 0;
    bool playing = false, rec = false;
    juce::Optional<PositionInfo> getPosition() const override
    {
        PositionInfo i;
        i.setBpm (120.0);
        i.setIsPlaying (playing);
        i.setIsRecording (rec);
        i.setPpqPosition (ppq);
        return i;
    }
};

static float runBlocks (DrumProcessor& p, Head& h, std::vector<std::pair<int, int>> notes, int blocks)   // (block, note)
{
    float energy = 0.0f;
    for (int b = 0; b < blocks; ++b)
    {
        juce::AudioBuffer<float> buf (2, 512);
        juce::MidiBuffer m;
        for (auto& nn : notes) if (nn.first == b) m.addEvent (juce::MidiMessage::noteOn (10, nn.second, (juce::uint8) 110), 100);
        p.processBlock (buf, m);
        energy += buf.getRMSLevel (0, 0, 512) + buf.getRMSLevel (1, 0, 512);
        h.ppq += 512.0 / 22050.0;
    }
    return energy;
}

static void pump (int ms) { juce::MessageManager::getInstance()->runDispatchLoopUntil (ms); }

int main()
{
    juce::ScopedJuceInitialiser_GUI gui;

    // 1. telling sounds apart by name
    struct Case { const char* file; const char* folder; int cat; };
    const Case cases[] = {
        { "Kick 01.wav", "", CatKick },            { "BD_Punchy.wav", "", CatKick },        { "Hard 3.wav", "Kicks", CatKick },
        { "Snare Tight.wav", "", CatSnare },       { "SD_04.wav", "", CatSnare },            { "Clap 2.wav", "", CatClap },
        { "FingerSnap.wav", "", CatSnap },         { "Rimshot 1.wav", "", CatRim },          { "HH closed 01.wav", "", CatClosedHat },
        { "OH 1.wav", "", CatOpenHat },            { "Open Hat 3.wav", "", CatOpenHat },     { "HiHat_7.wav", "", CatClosedHat },
        { "OpenHat02.wav", "", CatOpenHat },       { "Ride 1.wav", "", CatRide },            { "Crash 1.wav", "", CatCrash },
        { "Tom Low.wav", "", CatTom },             { "Conga Hi.wav", "", CatPerc },          { "Shaker 3.wav", "", CatShaker },
        { "Tamb.wav", "", CatTambourine },         { "808 Long C.wav", "", Cat808 },         { "Riser 1.wav", "", CatFx },
        { "Vox Chop 2.wav", "", CatVox },          { "Something.wav", "Misc", CatOther },    { "Loop 3.wav", "Hats", CatClosedHat },
        { "Bass Drum 2.wav", "", CatKick },        { "Cowbell.wav", "", CatPerc } };
    for (const auto& c : cases)
    {
        juce::StringArray folders;
        if (*c.folder) folders.add (c.folder);
        const int got = categorize (c.file, folders);
        CHECK (got == c.cat, "'%s' (in '%s') should be %s, got %s", c.file, c.folder, catName (c.cat), catName (got));
    }
    CHECK ((genreTags ("Snare 1", { "Snares", "Trap Kit Vol 2" }) >> 6) & 1u, "a Trap Kit folder should tag trap");
    CHECK ((genreTags ("Kick", { "90s Boom Bap" }) >> 5) & 1u, "boom bap = hip-hop");
    CHECK ((genreTags ("Shaker", { "Afrobeats Pack" }) >> 12) & 1u, "afrobeats tag");

    // 2. a made-up drum folder
    const auto root = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("vdrum_test_drums");
    root.deleteRecursively();
    writeWav (root.getChildFile ("Trap Kit/Kicks/Kick 1.wav"), 55, 0.4, false);
    writeWav (root.getChildFile ("Trap Kit/Kicks/Kick 2.wav"), 60, 0.4, false);
    writeWav (root.getChildFile ("Trap Kit/Kicks/Kick 3.wav"), 65, 0.4, false);
    writeWav (root.getChildFile ("Trap Kit/Snares/Snare Tight.wav"), 200, 0.2, true);
    writeWav (root.getChildFile ("Trap Kit/Claps/Clap 1.wav"), 1000, 0.2, true);
    writeWav (root.getChildFile ("Trap Kit/Hats/HH closed 01.wav"), 8000, 0.05, true);
    writeWav (root.getChildFile ("Trap Kit/Hats/OH 1.wav"), 7000, 1.2, true);
    writeWav (root.getChildFile ("Trap Kit/808s/808 Long.wav"), 45, 1.5, false);
    writeWav (root.getChildFile ("Boom Bap Kit/BD_02.wav"), 70, 0.3, false);
    writeWav (root.getChildFile ("Boom Bap Kit/SD_04.wav"), 220, 0.2, true);
    writeWav (root.getChildFile ("Boom Bap Kit/Rim 1.wav"), 900, 0.1, true);
    writeWav (root.getChildFile ("Lofi/Perc/Conga Hi.wav"), 400, 0.3, false);
    writeWav (root.getChildFile ("Lofi/Perc/Shaker 3.wav"), 6000, 0.1, true);
    writeWav (root.getChildFile ("Lofi/Perc/Tamb.wav"), 5000, 0.2, true);
    writeWav (root.getChildFile ("Lofi/Cymbals/Ride 1.wav"), 4000, 1.0, true);
    writeWav (root.getChildFile ("Lofi/Cymbals/Crash 1.wav"), 3500, 1.5, true);
    writeWav (root.getChildFile ("Lofi/Toms/Tom Low.wav"), 110, 0.4, false);
    writeWav (root.getChildFile ("FX/Riser 1.wav"), 300, 1.0, true);
    writeWav (root.getChildFile ("Misc/Something.wav"), 300, 0.2, false);
    juce::File (root.getChildFile ("Misc/notes.txt")).replaceWithText ("not a sound");

    std::unique_ptr<juce::AudioProcessor> base (createPluginFilter());
    auto& p = dynamic_cast<DrumProcessor&> (*base);
    p.setPlayConfigDetails (0, 2, 44100.0, 512);
    p.prepareToPlay (44100.0, 512);
    Head head;
    p.setPlayHead (&head);
    p.library.scan ({ root.getFullPathName() });
    for (int i = 0; i < 200 && p.library.scanning(); ++i) pump (20);
    pump (500);   // the timer builds a kit once the scan lands
    std::printf ("library: %d sounds (kick %d, snare %d, closed hat %d, open hat %d, 808 %d, other %d)\n", p.library.size(),
                 p.library.count (CatKick), p.library.count (CatSnare), p.library.count (CatClosedHat), p.library.count (CatOpenHat),
                 p.library.count (Cat808), p.library.count (CatOther));
    CHECK (p.library.size() == 19, "19 sounds in the folder (got %d)", p.library.size());
    CHECK (p.library.count (CatKick) == 4 && p.library.count (CatSnare) == 2 && p.library.count (CatOpenHat) == 1, "categories");

    // 3. trap kit from the folder: the kick pad holds a trap kick
    p.setGenre (6);
    int trapKicks = 0;
    for (int i = 0; i < 20; ++i) { p.buildKit (6, false); if (p.kit().pads[0].path.contains ("Trap Kit")) ++trapKicks; }
    CHECK (trapKicks >= 12, "TRAP: kicks should mostly come from the Trap Kit folder (%d of 20)", trapKicks);
    int filled = 0;
    for (int i = 0; i < numPads; ++i) if (p.padSample (i) != nullptr) ++filled;
    CHECK (filled == numPads, "every pad should get a sound (fallbacks for missing kinds), got %d", filled);

    // 4. it plays: VESPER's kick note, and a cowbell note lands on PERC 1
    float e = runBlocks (p, head, { { 0, 36 } }, 10);
    CHECK (e > 1.0f, "kick should make sound (%f)", e);
    const auto before = p.padHits[12].load();
    runBlocks (p, head, { { 0, 56 } }, 2);
    CHECK (p.padHits[12].load() == before + 1, "cowbell (56) should play PERC 1");

    // 5. choke: a closed hat cuts the long open hat off
    runBlocks (p, head, {}, 200);
    const float openAlone = runBlocks (p, head, { { 0, 46 } }, 60);
    runBlocks (p, head, {}, 200);
    const float choked = runBlocks (p, head, { { 0, 46 }, { 4, 42 } }, 60);
    std::printf ("open hat alone %.2f, choked by the closed hat %.2f\n", openAlone, choked);
    CHECK (choked < openAlone * 0.4f, "the closed hat should choke the open hat");

    // 6. DICE gives another kick; < > steps through them
    const auto k0 = p.kit().pads[0].path;
    p.dicePad (0, false);
    CHECK (p.kit().pads[0].path != k0 && p.kit().pads[0].path.isNotEmpty(), "DICE should change the kick");
    const auto k1 = p.kit().pads[0].path;
    p.stepPad (0, 1);
    CHECK (p.kit().pads[0].path != k1, "> should move to the next kick");
    p.stepPad (0, -1);
    CHECK (p.kit().pads[0].path == k1, "< should come back");

    // 7. lock + DICE KIT
    auto s0 = p.kit().pads[0];
    s0.locked = true;
    p.setPadSettings (0, s0);
    for (int i = 0; i < 5; ++i) p.diceAll();
    CHECK (p.kit().pads[0].path == k1, "a locked pad stays put on DICE KIT");

    // 8. kits: save as the trap default, change genre, come back
    s0.locked = false;
    p.setPadSettings (0, s0);
    auto snare = p.kit().pads[1];
    snare.tune = 3.5f;
    snare.decay = 0.4f;
    p.setPadSettings (1, snare);
    const auto kf = p.saveKit ("Test Trap Kit", true);
    CHECK (kf.existsAsFile() && defaultKitFor (6) == kf, "save + default for TRAP");
    const auto savedKick = p.kit().pads[0].path;
    p.setGenre (5);
    p.setGenre (6);
    CHECK (p.kit().pads[0].path == savedKick && std::abs (p.kit().pads[1].tune - 3.5f) < 0.01f && p.kit().name == "Test Trap Kit",
           "TRAP should bring back its default kit");

    // 9. the project remembers everything
    juce::MemoryBlock state;
    p.getStateInformation (state);
    std::unique_ptr<juce::AudioProcessor> b2 (createPluginFilter());
    auto& p2 = dynamic_cast<DrumProcessor&> (*b2);
    p2.setStateInformation (state.getData(), (int) state.getSize());
    CHECK (p2.kit().pads[0].path == savedKick && std::abs (p2.kit().pads[1].decay - 0.4f) < 0.01f && p2.padSample (1) != nullptr && p2.genre() == 6,
           "state should restore the kit and sounds");

    // 10. follows VESPER's genre (VESPER writes this file)
    const auto link = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("VESPER").getChildFile ("drum-link.xml");
    link.getParentDirectory().createDirectory();
    link.replaceWithText ("<VESPER_LINK genre=\"9\" groove=\"3\" time=\"0\"/>");
    pump (1200);
    CHECK (p.genre() == 9, "should follow VESPER to LO-FI (genre %d)", p.genre());
    CHECK (p.vesperAround(), "VESPER LINKED light");
    p.follow = false;
    link.replaceWithText ("<VESPER_LINK genre=\"11\" groove=\"3\" time=\"1\"/>");
    pump (1200);
    CHECK (p.genre() == 9, "FOLLOW off: stays put");
    p.follow = true;
    p.setGenre (6);

    // 11. recording: each pad's MIDI on C5, every pad as its own track, SAVE PADS folder
    runBlocks (p, head, {}, 1);   // earlier auditions out of the way
    head.ppq = 0.0;
    head.playing = true;
    head.rec = true;
    std::vector<std::pair<int, int>> beat;
    for (int b = 0; b < 4; ++b) { beat.push_back ({ b * 43, 36 }); beat.push_back ({ b * 43 + 21, 38 }); }
    for (int b = 0; b < 16; ++b) beat.push_back ({ b * 11, 42 });
    runBlocks (p, head, beat, 180);
    head.rec = false;
    runBlocks (p, head, {}, 2);
    std::printf ("recorded %d hits (kick %d, snare %d, hat %d)\n", p.recordedHits(), p.recordedHitsOn (0), p.recordedHitsOn (1), p.recordedHitsOn (4));
    CHECK (p.recordedHitsOn (0) == 4 && p.recordedHitsOn (1) == 4 && p.recordedHitsOn (4) == 16, "every hit recorded per pad");
    {
        const auto f = p.exportPad (0);
        juce::FileInputStream in (f);
        juce::MidiFile mf;
        CHECK (in.openedOk() && mf.readFrom (in) && mf.getNumTracks() == 1, "kick MIDI file");
        int ons = 0, onC5 = 0;
        if (mf.getNumTracks() > 0)
            for (auto* ev : *mf.getTrack (0)) if (ev->message.isNoteOn()) { ++ons; if (ev->message.getNoteNumber() == 60) ++onC5; }
        CHECK (ons == 4 && onC5 == 4, "kick pad MIDI: 4 hits on C5 (%d, %d)", ons, onC5);
    }
    {
        const auto f = p.exportAll();
        juce::FileInputStream in (f);
        juce::MidiFile mf;
        CHECK (in.openedOk() && mf.readFrom (in) && mf.getNumTracks() == 3, "all pads: one track per pad that played (%d)", mf.getNumTracks());
    }
    {
        const auto dir = p.savePadsFolder();
        const auto mids = dir.findChildFiles (juce::File::findFiles, false, "*.mid");
        const auto wavs = dir.findChildFiles (juce::File::findFiles, false, "*.wav");
        CHECK (mids.size() == 4 && wavs.size() == 3, "SAVE PADS: 3 pads + all (%d MIDI), 3 sounds (%d)", mids.size(), wavs.size());
        dir.deleteRecursively();
    }

    // 12. the editor
    {
        p.selectedPad = 6;
        std::unique_ptr<juce::AudioProcessorEditor> ed (p.createEditor());
        ed->setVisible (true);
        p.hitPad (0, 120);
        p.hitPad (4, 90);
        runBlocks (p, head, {}, 1);
        for (int i = 0; i < 4; ++i) pump (40);
        auto img = ed->createComponentSnapshot (ed->getLocalBounds(), true, 1.0f);
        juce::File out ("/tmp/claude-0/shot_drums.png");
        out.deleteFile();
        juce::FileOutputStream os (out);
        juce::PNGImageFormat png;
        png.writeImageToStream (img, os);
        std::printf ("editor -> %s (%dx%d)\n", out.getFullPathName().toRawUTF8(), img.getWidth(), img.getHeight());
    }
    p.setPlayHead (nullptr);
    kitsFolder().deleteRecursively();
    link.deleteFile();
    root.deleteRecursively();

    std::printf (failures == 0 ? "DRUM TESTS PASSED\n" : "%d FAILURES\n", failures);
    return failures == 0 ? 0 : 1;
}
